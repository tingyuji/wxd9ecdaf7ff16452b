var e = require("../../common/vendor.js"),
  r = {};if (!Array) {
  e.resolveComponent("layout-no-bar-uni")();
}var s = e._export_sfc(r, [["render", function (e, r) {
  return {};
}], ["__scopeId", "data-v-432d3950"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/pages/clause/clause.vue"]]);wx.createPage(s);