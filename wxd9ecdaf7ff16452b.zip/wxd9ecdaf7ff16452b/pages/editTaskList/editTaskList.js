var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var e = function e(_e, a, t) {
  return new Promise(function (n, l) {
    var r = function r(e) {
        try {
          s(t.next(e));
        } catch (a) {
          l(a);
        }
      },
      o = function o(e) {
        try {
          s(t.throw(e));
        } catch (a) {
          l(a);
        }
      },
      s = function s(e) {
        return e.done ? n(e.value) : Promise.resolve(e.value).then(r, o);
      };
    s((t = t.apply(_e, a)).next());
  });
};var a = require("../../common/vendor.js"),
  t = require("../index/modules/useBadyHook.js"),
  n = require("../../api/api.js");if (!Array) {
  a.resolveComponent("layout-no-bar-uni")();
}Math || (l + s + o + r)();var l = function l() {
    return "../../components/Loading/loading.js";
  },
  r = function r() {
    return "../../components/SelectModal/index.js";
  },
  o = function o() {
    return "../../components/ConfirmTipModal/index.js";
  },
  s = function s() {
    return "../../components/TemplateTaskEntry/index.js";
  },
  i = a.defineComponent({
    __name: "editTaskList",
    setup: function setup(l) {
      var _this = this;
      var _t$useBabyHooks = t.useBabyHooks(),
        r = _t$useBabyHooks.currentSelectBaby,
        o = _t$useBabyHooks.babyList,
        s = _t$useBabyHooks.allMemberList,
        i = _t$useBabyHooks.getMemberList,
        u = a.ref(),
        d = a.ref(""),
        v = a.ref(),
        c = a.ref(),
        f = a.ref(""),
        m = a.ref(!1),
        p = function p() {
          o.value.length < 2 || v.value.showModal();
        },
        k = function k(a) {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
            var e, t;
            return _regeneratorRuntime2().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  r.value = a;
                  _context.next = 3;
                  return n.apiGetTaskTemplateList();
                case 3:
                  e = _context.sent;
                  t = [];
                  "ok" === e.result && e.data ? (e.data.forEach(function (e) {
                    var a;
                    e.member === (null == (a = r.value) ? void 0 : a.id) && t.push(e);
                  }), u.value = t) : u.value = [], v.value.closeModal();
                case 6:
                case "end":
                  return _context.stop();
              }
            }, _callee);
          }));
        },
        T = function T(e) {
          d.value = e.task.id, f.value = "确认要删除该任务吗？", c.value.showModal();
        },
        h = function h(e) {
          a.index.navigateTo({
            url: "/pages/editTask/editTask?id=".concat(e.task.id)
          });
        },
        y = function y() {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
            var e;
            return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
              while (1) switch (_context2.prev = _context2.next) {
                case 0:
                  if (!m.value) {
                    _context2.next = 2;
                    break;
                  }
                  return _context2.abrupt("return");
                case 2:
                  m.value = !0;
                  _context2.next = 5;
                  return n.apiDelTaskTemplate(d.value);
                case 5:
                  _context2.next = 7;
                  return n.apiGetTaskTemplateList();
                case 7:
                  e = _context2.sent;
                  "ok" === e.result && e.data ? u.value = e.data : u.value = [], m.value = !1;
                case 9:
                case "end":
                  return _context2.stop();
              }
            }, _callee2);
          }));
        },
        b = function b() {},
        g = function g() {
          var e;
          a.index.navigateTo({
            url: "/pages/editTask/editTask?memberId=".concat(null == (e = r.value) ? void 0 : e.id)
          });
        };
      return a.onShow(function () {
        return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3() {
          var e, a;
          return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
            while (1) switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return i();
              case 2:
                _context3.next = 4;
                return n.apiGetTaskTemplateList();
              case 4:
                e = _context3.sent;
                a = [];
                "ok" === e.result && e.data ? (e.data.forEach(function (e) {
                  var t;
                  e.member === (null == (t = r.value) ? void 0 : t.id) && a.push(e);
                }), u.value = a) : u.value = [];
              case 7:
              case "end":
                return _context3.stop();
            }
          }, _callee3);
        }));
      }), function (e, t) {
        var n, l;
        return a.e({
          a: a.unref(m)
        }, (a.unref(m), {}), {
          b: null == (n = a.unref(r)) ? void 0 : n.avatar,
          c: a.t(null == (l = a.unref(r)) ? void 0 : l.name),
          d: a.unref(o).length > 1
        }, (a.unref(o).length, {}), {
          e: a.o(p),
          f: a.unref(u) && a.unref(u).length > 0
        }, a.unref(u) && a.unref(u).length > 0 ? {
          g: a.f(a.unref(u), function (e, t, n) {
            return {
              a: a.o(T, t),
              b: a.o(h, t),
              c: "a1339d56-2-" + n + ",a1339d56-0",
              d: a.p({
                task: e,
                member: (l = e.member || "", s.value.find(function (e) {
                  return e.id === l;
                }))
              }),
              e: t
            };
            var l;
          })
        } : {}, {
          h: a.o(g),
          i: a.sr(c, "a1339d56-3,a1339d56-0", {
            k: "confirmTipModalRef"
          }),
          j: a.o(y),
          k: a.o(b),
          l: a.p({
            content: a.unref(f),
            cancelText: "取消",
            confirmText: "删除"
          }),
          m: a.sr(v, "a1339d56-4,a1339d56-0", {
            k: "selectBabyRef"
          }),
          n: a.o(k),
          o: a.p({
            "select-list": a.unref(o)
          })
        });
      };
    }
  }),
  u = a._export_sfc(i, [["__scopeId", "data-v-a1339d56"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/pages/editTaskList/editTaskList.vue"]]);wx.createPage(u);