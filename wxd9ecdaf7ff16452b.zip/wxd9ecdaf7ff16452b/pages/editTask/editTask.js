var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var e = function e(_e, l, o) {
  return new Promise(function (n, a) {
    var t = function t(e) {
        try {
          i(o.next(e));
        } catch (l) {
          a(l);
        }
      },
      u = function u(e) {
        try {
          i(o.throw(e));
        } catch (l) {
          a(l);
        }
      },
      i = function i(e) {
        return e.done ? n(e.value) : Promise.resolve(e.value).then(t, u);
      };
    i((o = o.apply(_e, l)).next());
  });
};var l = require("../../common/vendor.js"),
  o = require("../../common/utils.js"),
  n = require("../index/modules/useBadyHook.js"),
  a = require("../../api/api.js");if (!Array) {
  (l.resolveComponent("wd-input") + l.resolveComponent("layout-no-bar-uni"))();
}Math || (t + function () {
  return "../../node-modules/wot-design-uni/components/wd-input/wd-input.js";
} + u + i)();var t = function t() {
    return "../../components/Loading/loading.js";
  },
  u = function u() {
    return "../../components/SetDateModal/index.js";
  },
  i = function i() {
    return "../../components/SetWeekModal/index.js";
  },
  r = l.defineComponent({
    __name: "editTask",
    setup: function setup(t) {
      var _this = this;
      var u = l.ref(!1),
        i = l.ref(1),
        r = l.ref(""),
        s = l.ref(""),
        v = l.ref(),
        d = l.ref(),
        c = l.ref(),
        _n$useBabyHooks = n.useBabyHooks(),
        f = _n$useBabyHooks.allMemberList,
        m = _n$useBabyHooks.getMemberList,
        p = l.ref(["天", "一", "二", "三", "四", "五", "六"]),
        h = l.ref(""),
        w = l.ref(),
        y = function y() {
          c.value && (i.value <= 1 ? l.index.showToast({
            icon: "none",
            title: "个数不能小于1"
          }) : i.value--);
        },
        k = function k() {
          c.value && i.value++;
        },
        x = function x() {
          v.value.showModal(null, r.value);
        },
        T = function T(l) {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
            return _regeneratorRuntime2().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  r.value = l;
                case 1:
                case "end":
                  return _context.stop();
              }
            }, _callee);
          }));
        },
        b = function b() {
          if (!c.value) return void (h.value = "");
          if (7 === c.value.cycleMode.length) return void (h.value = "每天");
          var e = "";
          for (var _l = 0; _l < p.value.length; _l++) c.value.cycleMode.includes(_l) && (e += "" === e ? "星期" + p.value[_l] : "、" + p.value[_l]);
          h.value = e;
        },
        g = function g() {
          c.value && d.value.showModal(c.value.cycleMode.slice());
        },
        M = function M(e) {
          c.value && (c.value.cycleMode = e.weeks, b());
        },
        C = function C() {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
            var _o$checkStr, e, n, t, v, d;
            return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
              while (1) switch (_context2.prev = _context2.next) {
                case 0:
                  if (!(u.value || !c.value)) {
                    _context2.next = 2;
                    break;
                  }
                  return _context2.abrupt("return");
                case 2:
                  if (!(i.value <= 0)) {
                    _context2.next = 4;
                    break;
                  }
                  return _context2.abrupt("return", void l.index.showToast({
                    icon: "none",
                    title: "个数不能小于1"
                  }));
                case 4:
                  if (!(s.value.length <= 0)) {
                    _context2.next = 6;
                    break;
                  }
                  return _context2.abrupt("return", void l.index.showToast({
                    icon: "none",
                    title: "请输入任务内容"
                  }));
                case 6:
                  _o$checkStr = o.checkStr(s.value), e = _o$checkStr.numberCount, n = _o$checkStr.spaceCount, t = _o$checkStr.chineseCount, v = _o$checkStr.englishCount, d = _o$checkStr.otherCount;
                  if (!(e > 0)) {
                    _context2.next = 11;
                    break;
                  }
                  l.index.showToast({
                    icon: "none",
                    title: "任务内容中不能有数字"
                  });
                  _context2.next = 36;
                  break;
                case 11:
                  if (!(n > 0)) {
                    _context2.next = 15;
                    break;
                  }
                  l.index.showToast({
                    icon: "none",
                    title: "任务内容中不能有空格"
                  });
                  _context2.next = 36;
                  break;
                case 15:
                  if (!(d > 0)) {
                    _context2.next = 19;
                    break;
                  }
                  l.index.showToast({
                    icon: "none",
                    title: "任务内容中不能有特殊字符"
                  });
                  _context2.next = 36;
                  break;
                case 19:
                  if (!(2 * t + v > 40)) {
                    _context2.next = 23;
                    break;
                  }
                  l.index.showToast({
                    icon: "none",
                    title: "最多输入20个字符"
                  });
                  _context2.next = 36;
                  break;
                case 23:
                  u.value = !0;
                  c.value.time = r.value;
                  c.value.content = s.value;
                  c.value.flowerCount = i.value;
                  if (!c.value.id) {
                    _context2.next = 32;
                    break;
                  }
                  _context2.next = 30;
                  return a.apiSetTaskTemplateInfo(c.value);
                case 30:
                  _context2.next = 34;
                  break;
                case 32:
                  _context2.next = 34;
                  return a.apiAddTaskTemplate(c.value);
                case 34:
                  u.value = !1;
                  l.index.navigateBack({
                    delta: 1
                  });
                case 36:
                case "end":
                  return _context2.stop();
              }
            }, _callee2);
          }));
        };
      return l.onLoad(function (l) {
        return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3() {
          var _e2;
          return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
            while (1) switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return m();
              case 2:
                c.value = {
                  id: "",
                  member: "",
                  content: "",
                  time: "00:00",
                  flowerCount: 1,
                  flowerType: 1,
                  cycleMode: []
                };
                if (!l) {
                  _context3.next = 10;
                  break;
                }
                if (!(l.memberId && (c.value.member = l.memberId), l.id)) {
                  _context3.next = 9;
                  break;
                }
                _context3.next = 7;
                return a.apiGetTaskTemplate(l.id);
              case 7:
                _e2 = _context3.sent;
                "ok" === _e2.result && (c.value = _e2.data);
              case 9:
                c.value && c.value.member && (w.value = f.value.find(function (e) {
                  var l;
                  return e.id === (null == (l = c.value) ? void 0 : l.member);
                }));
              case 10:
                r.value = c.value.time, s.value = c.value.content, i.value = c.value.flowerCount, b();
              case 11:
              case "end":
                return _context3.stop();
            }
          }, _callee3);
        }));
      }), function (e, o) {
        return l.e({
          a: l.unref(u)
        }, (l.unref(u), {}), {
          b: l.o(function (e) {
            return l.isRef(s) ? s.value = e : null;
          }),
          c: l.p({
            type: "text",
            placeholder: "输入内容",
            maxlength: 20,
            size: "large",
            "no-border": "false",
            clearable: !0,
            modelValue: l.unref(s)
          }),
          d: l.unref(i),
          e: l.o(function (e) {
            return l.isRef(i) ? i.value = e.detail.value : null;
          }),
          f: l.o(y),
          g: l.o(k),
          h: l.t(l.unref(r)),
          i: l.o(x),
          j: l.t(l.unref(h)),
          k: l.o(g),
          l: l.o(C),
          m: l.sr(v, "7594ce11-3,7594ce11-0", {
            k: "setDateModalRef"
          }),
          n: l.o(T),
          o: l.p({
            title: "时间",
            type: "time"
          }),
          p: l.sr(d, "7594ce11-4,7594ce11-0", {
            k: "setWeekModalRef"
          }),
          q: l.o(M)
        });
      };
    }
  }),
  s = l._export_sfc(r, [["__scopeId", "data-v-7594ce11"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/pages/editTask/editTask.vue"]]);wx.createPage(s);