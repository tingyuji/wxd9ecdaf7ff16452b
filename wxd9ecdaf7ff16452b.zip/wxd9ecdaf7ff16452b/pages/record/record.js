var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var e = function e(_e, o, n) {
  return new Promise(function (r, a) {
    var l = function l(e) {
        try {
          s(n.next(e));
        } catch (o) {
          a(o);
        }
      },
      t = function t(e) {
        try {
          s(n.throw(e));
        } catch (o) {
          a(o);
        }
      },
      s = function s(e) {
        return e.done ? r(e.value) : Promise.resolve(e.value).then(l, t);
      };
    s((n = n.apply(_e, o)).next());
  });
};var o = require("../../common/vendor.js"),
  n = require("../../api/api.js"),
  r = require("../index/modules/useBadyHook.js");if (!Array) {
  o.resolveComponent("layout-no-bar-uni")();
}Math || (a + l)();var a = function a() {
    return "../../components/RecordCard/index.js";
  },
  l = function l() {
    return "../../components/SelectModal/index.js";
  },
  t = o.defineComponent({
    __name: "record",
    setup: function setup(a) {
      var _this = this;
      var l = o.ref(),
        t = o.ref(),
        s = o.ref(),
        _r$useBabyHooks = r.useBabyHooks(),
        u = _r$useBabyHooks.currentSelectBaby,
        i = _r$useBabyHooks.babyList,
        c = _r$useBabyHooks.allMemberList,
        d = _r$useBabyHooks.getMemberList,
        f = function f() {
          var e;
          t.value = [], null == (e = s.value) || e.flowerLogs.forEach(function (e) {
            var o, n;
            e.target.name === (null == (o = u.value) ? void 0 : o.role.name) && (null == (n = t.value) || n.push(e));
          });
        },
        v = function v() {
          i.value.length < 2 || l.value.showModal();
        },
        m = function m(e) {
          u.value = e, l.value.closeModal(), f();
        },
        h = function h(o) {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
            return _regeneratorRuntime2().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                case "end":
                  return _context.stop();
              }
            }, _callee);
          }));
        },
        p = function p(o) {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
            return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
              while (1) switch (_context2.prev = _context2.next) {
                case 0:
                  _context2.next = 2;
                  return y();
                case 2:
                  f();
                case 3:
                case "end":
                  return _context2.stop();
              }
            }, _callee2);
          }));
        },
        y = function y() {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3() {
            var e;
            return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
              while (1) switch (_context3.prev = _context3.next) {
                case 0:
                  s.value = {
                    id: "",
                    family: "",
                    name: "",
                    avatar: "",
                    role: {
                      id: "",
                      name: "",
                      avatar: "",
                      type: "parent"
                    },
                    flowerList: 0,
                    checkIn: !1,
                    flowerLogs: []
                  };
                  _context3.next = 3;
                  return n.apiGetMemberBySelf();
                case 3:
                  e = _context3.sent;
                  "ok" === e.result && e.data ? s.value = e.data : o.index.showToast({
                    icon: "none",
                    title: "系统错误"
                  });
                case 5:
                case "end":
                  return _context3.stop();
              }
            }, _callee3);
          }));
        };
      return o.onShow(function () {
        return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee4() {
          return _regeneratorRuntime2().wrap(function _callee4$(_context4) {
            while (1) switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return d();
              case 2:
                _context4.next = 4;
                return y();
              case 4:
                f();
              case 5:
              case "end":
                return _context4.stop();
            }
          }, _callee4);
        }));
      }), function (e, n) {
        var r, a;
        return o.e({
          a: null == (r = o.unref(u)) ? void 0 : r.avatar,
          b: o.t(null == (a = o.unref(u)) ? void 0 : a.role.name),
          c: o.unref(i).length > 1
        }, (o.unref(i).length, {}), {
          d: o.o(v),
          e: o.f(o.unref(t), function (e, n, r) {
            return {
              a: o.o(p, n),
              b: o.o(h, n),
              c: "247036e8-1-" + r + ",247036e8-0",
              d: o.p({
                log: e,
                "show-initiator": !1
              }),
              e: n
            };
          }),
          f: o.sr(l, "247036e8-2,247036e8-0", {
            k: "selectBabyRef"
          }),
          g: o.o(m),
          h: o.p({
            "select-list": o.unref(i)
          })
        });
      };
    }
  }),
  s = o._export_sfc(t, [["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/pages/record/record.vue"]]);wx.createPage(s);