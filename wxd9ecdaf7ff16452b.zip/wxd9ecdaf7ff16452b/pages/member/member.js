var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var e = function e(_e, a, t) {
  return new Promise(function (l, r) {
    var n = function n(e) {
        try {
          i(t.next(e));
        } catch (a) {
          r(a);
        }
      },
      u = function u(e) {
        try {
          i(t.throw(e));
        } catch (a) {
          r(a);
        }
      },
      i = function i(e) {
        return e.done ? l(e.value) : Promise.resolve(e.value).then(n, u);
      };
    i((t = t.apply(_e, a)).next());
  });
};var a = require("../../common/vendor.js"),
  t = require("../../api/api.js"),
  l = require("../../common/utils.js");if (!Array) {
  (a.resolveComponent("wd-skeleton") + a.resolveComponent("layout-no-bar-uni"))();
}Math || (r + function () {
  return "../../node-modules/wot-design-uni/components/wd-skeleton/wd-skeleton.js";
} + n)();var r = function r() {
    return "../../components/Loading/loading.js";
  },
  n = function n() {
    return "../../components/SetDateModal/index.js";
  },
  u = a.defineComponent({
    __name: "member",
    setup: function setup(r) {
      var _this = this;
      var n = a.ref(!1),
        u = a.ref(!0),
        i = a.ref(""),
        o = a.ref(""),
        d = a.ref(),
        v = a.ref(0),
        s = a.ref(0),
        f = a.ref(),
        m = a.ref(),
        p = function p() {
          u.value || a.index.navigateTo({
            url: "/pages/editFamily/editFamily"
          });
        },
        h = function h() {
          u.value || a.index.navigateTo({
            url: "/pages/editName/editName?memberId=".concat(i.value)
          });
        },
        c = function c() {
          if (u.value || !f.value) return;
          var e = null;
          e = "" === f.value.birthday ? new Date() : new Date(f.value.birthday), d.value.showModal(e);
        },
        w = function w(a) {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
            var e, r;
            return _regeneratorRuntime2().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  if (!(n.value || !f.value)) {
                    _context.next = 2;
                    break;
                  }
                  return _context.abrupt("return");
                case 2:
                  n.value = !0;
                  _context.next = 5;
                  return t.apiSetMemberBirthday(f.value.id, a);
                case 5:
                  e = _context.sent;
                  if (!("ok" !== e.result || !e.data)) {
                    _context.next = 8;
                    break;
                  }
                  return _context.abrupt("return", void (n.value = !1));
                case 8:
                  _context.next = 10;
                  return t.apiGetFamilyMember(i.value);
                case 10:
                  r = _context.sent;
                  "ok" === r.result && r.data && (f.value = r.data, o.value = l.getAvatar(r.data.avatar)), n.value = !1;
                case 12:
                case "end":
                  return _context.stop();
              }
            }, _callee);
          }));
        },
        x = function x() {
          f.value && "" !== f.value.uid && a.index.setClipboardData({
            data: f.value.uid,
            success: function success() {
              a.index.showToast({
                icon: "none",
                title: "复制成功"
              });
            },
            fail: function fail() {
              a.index.showToast({
                icon: "none",
                title: "复制失败"
              });
            }
          });
        };
      return a.onLoad(function (e) {
        e && e.memberId ? i.value = e.memberId : a.index.navigateBack({
          delta: 1
        });
      }), a.onShow(function () {
        return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
          var e, a, r, n, d;
          return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
            while (1) switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return t.apiGetFamilyMember(i.value);
              case 2:
                n = _context2.sent;
                if (!("ok" === n.result && n.data && (f.value = n.data, o.value = l.getAvatar(n.data.avatar)), "child" === (null == (e = f.value) ? void 0 : e.role.type))) {
                  _context2.next = 7;
                  break;
                }
                u.value = !1;
                _context2.next = 20;
                break;
              case 7:
                if (!("" === (null == (a = f.value) ? void 0 : a.uid))) {
                  _context2.next = 11;
                  break;
                }
                u.value = !1;
                _context2.next = 20;
                break;
              case 11:
                _context2.next = 13;
                return t.apiGetMemberBySelf();
              case 13:
                _context2.t0 = _context2.sent.data.uid;
                _context2.t1 = null == (r = f.value) ? void 0 : r.uid;
                if (!(_context2.t0 === _context2.t1)) {
                  _context2.next = 19;
                  break;
                }
                u.value = !1;
                _context2.next = 20;
                break;
              case 19:
                u.value = !0;
              case 20:
                (function () {
                  if (!f.value) return v.value = 0, void (s.value = 0);
                  var e = 0,
                    a = 0;
                  f.value.flowerList.forEach(function (t) {
                    1 === t.flowerType && (e = t.flowerCount), 2 === t.flowerType && (a = t.flowerCount);
                  }), v.value = e, s.value = a;
                })();
                _context2.next = 23;
                return t.apiGetFamily();
              case 23:
                d = _context2.sent;
                "ok" === d.result && d.data && (m.value = d.data);
              case 25:
              case "end":
                return _context2.stop();
            }
          }, _callee2);
        }));
      }), function (e, t) {
        var l, r, i, y, g, b, k, M, _, j;
        return a.e({
          a: a.unref(n)
        }, (a.unref(n), {}), {
          b: a.t(null == (l = a.unref(m)) ? void 0 : l.name),
          c: !a.unref(u)
        }, (a.unref(u), {}), {
          d: a.o(p),
          e: a.t(null == (r = a.unref(f)) ? void 0 : r.role.name),
          f: a.unref(o),
          g: a.t(null == (i = a.unref(f)) ? void 0 : i.name),
          h: !a.unref(u)
        }, (a.unref(u), {}), {
          i: a.o(h),
          j: "" === (null == (y = a.unref(f)) ? void 0 : y.birthday)
        }, "" === (null == (g = a.unref(f)) ? void 0 : g.birthday) ? a.e({
          k: a.unref(u)
        }, (a.unref(u), {})) : {
          l: a.t(null == (b = a.unref(f)) ? void 0 : b.birthday)
        }, {
          m: !a.unref(u)
        }, (a.unref(u), {}), {
          n: a.o(c),
          o: a.t(null == (k = a.unref(f)) ? void 0 : k.uid),
          p: "" !== (null == (M = a.unref(f)) ? void 0 : M.uid)
        }, (null == (_ = a.unref(f)) || _.uid, {}), {
          q: a.o(x),
          r: a.t(a.unref(v)),
          s: a.t(a.unref(s)),
          t: a.p({
            loading: !(null == (j = a.unref(m)) ? void 0 : j.name),
            "custom-style": {
              marginTop: "20rpx"
            },
            "row-col": [{
              width: "750rpx",
              height: "100rpx"
            }, {
              width: "750rpx",
              height: "100rpx"
            }, {
              width: "750rpx",
              height: "100rpx"
            }, {
              width: "750rpx",
              height: "100rpx"
            }, {
              width: "750rpx",
              height: "100rpx"
            }, {
              width: "750rpx",
              height: "100rpx"
            }, {
              width: "750rpx",
              height: "100rpx"
            }]
          }),
          v: a.sr(d, "afe8e14b-3,afe8e14b-0", {
            k: "setBirthdayModalRef"
          }),
          w: a.o(w),
          x: a.p({
            title: "设置生日",
            "min-date": new Date(1900, 0, 1),
            "max-date": new Date()
          })
        });
      };
    }
  }),
  i = a._export_sfc(u, [["__scopeId", "data-v-afe8e14b"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/pages/member/member.vue"]]);wx.createPage(i);