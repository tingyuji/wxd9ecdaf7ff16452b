var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var e = function e(_e, i, t) {
  return new Promise(function (n, a) {
    var l = function l(e) {
        try {
          r(t.next(e));
        } catch (i) {
          a(i);
        }
      },
      o = function o(e) {
        try {
          r(t.throw(e));
        } catch (i) {
          a(i);
        }
      },
      r = function r(e) {
        return e.done ? n(e.value) : Promise.resolve(e.value).then(l, o);
      };
    r((t = t.apply(_e, i)).next());
  });
};var i = require("../../common/vendor.js"),
  t = require("../../api/api.js"),
  n = require("../index/modules/useBadyHook.js"),
  a = require("../../utils/index.js");if (!Array) {
  (i.resolveComponent("wd-skeleton") + i.resolveComponent("layout-default-uni"))();
}Math || (l + function () {
  return "../../node-modules/wot-design-uni/components/wd-skeleton/wd-skeleton.js";
} + o + r + u + d)();var l = function l() {
    return "../../components/Loading/loading.js";
  },
  o = function o() {
    return "../../components/MemberEntry/index.js";
  },
  r = function r() {
    return "../../components/AddMemberModal/index.js";
  },
  d = function d() {
    return "../../components/InviteMemberModal/index.js";
  },
  u = function u() {
    return "../../components/ConfirmTipModal/index.js";
  },
  s = "../../static/images/",
  v = i.defineComponent({
    __name: "user",
    setup: function setup(l) {
      var _this = this;
      var o = i.ref(0),
        r = i.ref(""),
        d = i.ref(0),
        u = i.ref(""),
        v = i.ref(),
        c = i.ref(""),
        m = i.ref(),
        f = i.ref({
          code: "",
          role: 0
        }),
        p = i.ref(!1),
        h = i.ref(),
        g = i.ref(),
        b = i.ref(),
        _n$useBabyHooks = n.useBabyHooks(),
        x = _n$useBabyHooks.allMemberList,
        y = _n$useBabyHooks.getMemberList,
        w = _n$useBabyHooks.getMemberFlowerCount,
        M = i.ref([]),
        k = i.ref([]),
        _ = i.ref([]),
        T = [[{
          width: "100%",
          height: "100rpx"
        }], [{
          width: "100%",
          height: "100rpx"
        }]],
        F = function F(t) {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
            return _regeneratorRuntime2().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  if (i.index.$emit("hideMember", {
                    id: ""
                  }), "getFlower" === t) i.index.navigateTo({
                    url: "/pages/activity/activity"
                  });
                case 1:
                case "end":
                  return _context.stop();
              }
            }, _callee);
          }));
        },
        j = function j(n) {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
            var e, _e2;
            return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
              while (1) switch (_context2.prev = _context2.next) {
                case 0:
                  if (!p.value) {
                    _context2.next = 2;
                    break;
                  }
                  return _context2.abrupt("return");
                case 2:
                  if (n.currentSelect) {
                    _context2.next = 4;
                    break;
                  }
                  return _context2.abrupt("return", void i.index.showToast({
                    icon: "none",
                    title: "请选择角色"
                  }));
                case 4:
                  p.value = !0;
                  _context2.next = 7;
                  return t.apiAddFamilyMember(n.currentSelect.label, n.currentSelect.icon.replace(s, ""), Number(n.currentSelect.key)).finally(function () {
                    p.value = !1;
                  });
                case 7:
                  e = _context2.sent;
                  if (!("ok" === e.result && e.data)) {
                    _context2.next = 20;
                    break;
                  }
                  i.index.showToast({
                    icon: "none",
                    title: "添加角色成功"
                  });
                  _context2.next = 12;
                  return y();
                case 12:
                  h.value.handleCloseAddMember();
                  M.value = x.value.filter(function (e) {
                    var i;
                    return e.id !== (null == (i = g.value) ? void 0 : i.id);
                  });
                  _context2.next = 16;
                  return t.apiGetFlowersSetting();
                case 16:
                  _e2 = _context2.sent;
                  "ok" === _e2.result && _e2.data && (d.value = _e2.data);
                  _context2.next = 21;
                  break;
                case 20:
                  i.index.showToast({
                    icon: "none",
                    title: e.data
                  });
                case 21:
                case "end":
                  return _context2.stop();
              }
            }, _callee2);
          }));
        },
        S = a.debounce(function () {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3() {
            var e, _i;
            return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
              while (1) switch (_context3.prev = _context3.next) {
                case 0:
                  i.index.$emit("hideMember", {
                    id: ""
                  });
                  _context3.next = 3;
                  return t.apiGetFamilyRoleList("all");
                case 3:
                  e = _context3.sent;
                  if ("ok" === e.result && e.data) {
                    {
                      _i = e.data;
                      k.value = [], _i.forEach(function (e) {
                        x.value.some(function (i) {
                          return i.role.id === e.id;
                        }) || k.value.push({
                          key: e.id,
                          label: e.name,
                          icon: s + e.avatar
                        });
                      });
                    }
                    0 !== k.value.length ? h.value.showModal() : i.index.showToast({
                      icon: "none",
                      title: "无可加入的角色"
                    });
                  } else i.index.showToast({
                    icon: "none",
                    title: e.data
                  });
                case 5:
                case "end":
                  return _context3.stop();
              }
            }, _callee3);
          }));
        }),
        G = function G(e) {
          f.value.code = e.code, f.value.role = e.role;
        },
        $ = function $(i) {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee4() {
            return _regeneratorRuntime2().wrap(function _callee4$(_context4) {
              while (1) switch (_context4.prev = _context4.next) {
                case 0:
                case "end":
                  return _context4.stop();
              }
            }, _callee4);
          }));
        },
        C = a.debounce(function () {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee5() {
            var e;
            return _regeneratorRuntime2().wrap(function _callee5$(_context5) {
              while (1) switch (_context5.prev = _context5.next) {
                case 0:
                  i.index.$emit("hideMember", {
                    id: ""
                  });
                  _context5.next = 3;
                  return t.apiGetFamilyRoleList("parent");
                case 3:
                  e = _context5.sent.data;
                  _.value = [], e.forEach(function (e) {
                    var i = x.value.find(function (i) {
                      return i.role.id === e.id;
                    });
                    i ? "" === i.uid && _.value.push({
                      key: e.id,
                      label: e.name,
                      icon: s + e.avatar
                    }) : _.value.push({
                      key: e.id,
                      label: e.name,
                      icon: s + e.avatar
                    });
                  }), 0 !== _.value.length ? m.value.showModal(_.value) : i.index.showToast({
                    icon: "none",
                    title: "无可邀请的角色"
                  });
                case 5:
                case "end":
                  return _context5.stop();
              }
            }, _callee5);
          }));
        }),
        L = function L(i) {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee6() {
            var e;
            return _regeneratorRuntime2().wrap(function _callee6$(_context6) {
              while (1) switch (_context6.prev = _context6.next) {
                case 0:
                  u.value = i.id;
                  e = x.value.find(function (e) {
                    return e.id === i.id;
                  });
                  c.value = "确认要删除家庭成员“" + (null == e ? void 0 : e.name) + "”吗？", v.value.showModal();
                case 3:
                case "end":
                  return _context6.stop();
              }
            }, _callee6);
          }));
        },
        A = function A() {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee7() {
            var e;
            return _regeneratorRuntime2().wrap(function _callee7$(_context7) {
              while (1) switch (_context7.prev = _context7.next) {
                case 0:
                  _context7.next = 2;
                  return t.apiDelFamilyMember(u.value);
                case 2:
                  _context7.next = 4;
                  return y();
                case 4:
                  M.value = x.value.filter(function (e) {
                    var i;
                    return e.id !== (null == (i = g.value) ? void 0 : i.id);
                  });
                  _context7.next = 7;
                  return t.apiGetFlowersSetting();
                case 7:
                  e = _context7.sent;
                  "ok" === e.result && e.data && (d.value = e.data);
                case 9:
                case "end":
                  return _context7.stop();
              }
            }, _callee7);
          }));
        },
        B = function B() {},
        I = function I() {
          i.index.$emit("hideMember", {
            id: ""
          }), i.index.navigateTo({
            url: "/pages/editFamily/editFamily"
          });
        },
        q = function q(e) {
          i.index.$emit("hideMember", {
            id: ""
          });
        },
        R = function R() {
          var e;
          i.index.navigateTo({
            url: "/pages/member/member?memberId=".concat(null == (e = g.value) ? void 0 : e.id)
          });
        };
      return i.onShareAppMessage(function (i) {
        return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee8() {
          var e, i, n, a, l, _e3, _o;
          return _regeneratorRuntime2().wrap(function _callee8$(_context8) {
            while (1) switch (_context8.prev = _context8.next) {
              case 0:
                n = "轻松培养娃娃养成良好习惯", a = "../../static/images/invitation_bg1.png", l = "/pages/index/index?uid=".concat(null == (e = g.value) ? void 0 : e.uid);
                if (!("" !== f.value.code)) {
                  _context8.next = 9;
                  break;
                }
                _context8.next = 4;
                return t.apiCreateInvitation(f.value.role, f.value.code);
              case 4:
                _e3 = _context8.sent;
                _context8.next = 7;
                return t.apiGetInvitation(_e3.data);
              case 7:
                _o = _context8.sent;
                "ok" === _e3.result && _e3.data && (n = _o.data.title, a = "../../static/images/invitation_bg2.png", l = "/pages/index/index?uid=".concat(null == (i = g.value) ? void 0 : i.uid, "&invitationId=").concat(_e3.data)), f.value.role = 0, f.value.code = "";
              case 9:
                return _context8.abrupt("return", {
                  title: n,
                  imageUrl: a,
                  path: l
                });
              case 10:
              case "end":
                return _context8.stop();
            }
          }, _callee8);
        }));
      }), i.onShow(function () {
        return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee9() {
          var e, i, n;
          return _regeneratorRuntime2().wrap(function _callee9$(_context9) {
            while (1) switch (_context9.prev = _context9.next) {
              case 0:
                _context9.next = 2;
                return y();
              case 2:
                _context9.next = 4;
                return t.apiGetMemberBySelf();
              case 4:
                e = _context9.sent;
                "ok" === e.result && e.data && (g.value = e.data, o.value = w(g.value.id, 1), r.value = s + g.value.role.avatar, M.value = x.value.filter(function (e) {
                  var i;
                  return e.id !== (null == (i = g.value) ? void 0 : i.id);
                }));
                _context9.next = 8;
                return t.apiGetFlowersSetting();
              case 8:
                i = _context9.sent;
                "ok" === i.result && i.data && (d.value = i.data);
                _context9.next = 12;
                return t.apiGetFamily();
              case 12:
                n = _context9.sent;
                "ok" === n.result && n.data && (b.value = n.data);
              case 14:
              case "end":
                return _context9.stop();
            }
          }, _callee9);
        }));
      }), function (e, t) {
        var n, a, l, u, s;
        return i.e({
          a: i.unref(p)
        }, (i.unref(p), {}), {
          b: i.unref(r),
          c: i.p({
            loading: !i.unref(r),
            theme: "avatar"
          }),
          d: i.t(null == (n = i.unref(g)) ? void 0 : n.name),
          e: i.t(null == (a = i.unref(g)) ? void 0 : a.role.name),
          f: i.p({
            loading: !(null == (l = i.unref(g)) ? void 0 : l.name),
            "custom-style": {
              marginLeft: "20rpx"
            },
            "row-col": [{
              width: "80rpx",
              height: "40rpx"
            }, {
              width: "40rpx",
              height: "40rpx"
            }]
          }),
          g: i.t(i.unref(o)),
          h: i.o(R),
          i: i.p({
            loading: !(null == (u = i.unref(g)) ? void 0 : u.role.name),
            "custom-style": {
              marginLeft: "32rpx"
            },
            "row-col": [{
              width: "80rpx",
              height: "40rpx"
            }]
          }),
          j: i.t(null == (s = i.unref(b)) ? void 0 : s.name),
          k: i.o(I),
          l: i.p({
            loading: !i.unref(b),
            "row-col": [{
              width: "80rpx",
              height: "40rpx"
            }]
          }),
          m: i.f(i.unref(M), function (e, t, n) {
            var a, l;
            return {
              a: t,
              b: i.o(L, t),
              c: "99b0ba47-7-" + n + ",99b0ba47-6",
              d: i.p({
                member: e,
                count: i.unref(w)(e.id, 1),
                index: t,
                length: i.unref(M).length,
                isSlide: (null == (a = i.unref(b)) ? void 0 : a.createdBy) === (null == (l = i.unref(g)) ? void 0 : l.uid)
              })
            };
          }),
          n: i.o(function () {
            return i.unref(S) && i.unref(S).apply(void 0, arguments);
          }),
          o: i.o(function () {
            return i.unref(C) && i.unref(C).apply(void 0, arguments);
          }),
          p: i.n(i.unref(M).length > 0 ? "" : "rounded-t-_a_24rpx_a_"),
          q: i.p({
            loading: !i.unref(b),
            "custom-style": {
              width: "100%",
              marginBottom: "0"
            },
            "row-col": T
          }),
          r: i.t(i.unref(d)),
          s: i.o(function (e) {
            return F("getFlower");
          }),
          t: i.p({
            loading: !i.unref(b),
            "custom-style": {
              marginTop: "22rpx"
            },
            "row-col": [{
              width: "100%",
              height: "120rpx"
            }]
          }),
          v: i.p({
            loading: !i.unref(b),
            "custom-style": {
              marginTop: "22rpx"
            },
            "row-col": [{
              width: "100%",
              height: "100rpx"
            }]
          }),
          w: i.o(q),
          x: i.sr(h, "99b0ba47-10,99b0ba47-0", {
            k: "addMemberModalRef"
          }),
          y: i.o(j),
          z: i.p({
            title: "添加成员",
            "member-list": i.unref(k),
            "is-show-input": !1
          }),
          A: i.sr(v, "99b0ba47-11,99b0ba47-0", {
            k: "confirmTipModalRef"
          }),
          B: i.o(A),
          C: i.o(B),
          D: i.p({
            content: i.unref(c),
            cancelText: "取消",
            confirmText: "删除"
          }),
          E: i.sr(m, "99b0ba47-12,99b0ba47-0", {
            k: "inviteMemberModalRef"
          }),
          F: i.o(G),
          G: i.o($),
          H: i.p({
            "member-list": i.unref(_)
          })
        });
      };
    }
  });v.__runtimeHooks = 2;var c = i._export_sfc(v, [["__scopeId", "data-v-99b0ba47"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/pages/user/user.vue"]]);wx.createPage(c);