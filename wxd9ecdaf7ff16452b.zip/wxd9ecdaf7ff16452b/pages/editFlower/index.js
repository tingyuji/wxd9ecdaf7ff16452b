var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var e = function e(_e, n, a) {
  return new Promise(function (o, l) {
    var t = function t(e) {
        try {
          i(a.next(e));
        } catch (n) {
          l(n);
        }
      },
      u = function u(e) {
        try {
          i(a.throw(e));
        } catch (n) {
          l(n);
        }
      },
      i = function i(e) {
        return e.done ? o(e.value) : Promise.resolve(e.value).then(t, u);
      };
    i((a = a.apply(_e, n)).next());
  });
};var n = require("../../common/vendor.js"),
  a = require("../../api/api.js"),
  o = require("../index/modules/useBadyHook.js");if (!Array) {
  n.resolveComponent("layout-no-bar-uni")();
}Math || (t + l)();var l = function l() {
    return "../../components/SelectModal/index.js";
  },
  t = function t() {
    return "../../components/Loading/loading.js";
  },
  u = n.defineComponent({
    __name: "index",
    setup: function setup(l) {
      var _this = this;
      var t = n.ref(!1),
        u = n.ref(1),
        i = n.ref(),
        r = n.ref(1),
        s = n.ref(),
        v = n.ref(),
        d = n.ref(),
        f = n.ref(),
        c = n.ref(),
        h = n.ref(!1),
        _o$useBabyHooks = o.useBabyHooks(),
        w = _o$useBabyHooks.currentSelectBaby,
        p = _o$useBabyHooks.babyList,
        b = _o$useBabyHooks.allMemberList,
        m = _o$useBabyHooks.getMemberList,
        x = _o$useBabyHooks.getMemberFlowerCount,
        g = function g(e) {
          d.value ? n.index.showToast({
            icon: "none",
            title: "不能修改类型"
          }) : (r.value = e, i.value = "");
        },
        y = function y() {
          (function () {
            if (!i.value) return n.index.showToast({
              icon: "none",
              title: "请输入原因"
            }), !1;
            if (i.value.length < 2) return n.index.showToast({
              icon: "none",
              title: "原因至少2个字"
            }), !1;
            if (!u.value) return n.index.showToast({
              icon: "none",
              title: "请输入个数"
            }), !1;
            var e = Number(u.value);
            return Number.isInteger(e) ? !(e <= 0 && (n.index.showToast({
              icon: "none",
              title: "请输入正数"
            }), 1)) : (n.index.showToast({
              icon: "none",
              title: "请输入整数"
            }), !1);
          })() && (d.value ? E() : T());
        },
        _ = function _() {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
            var e, a;
            return _regeneratorRuntime2().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  if (!d.value) {
                    _context.next = 2;
                    break;
                  }
                  return _context.abrupt("return", void n.index.showToast({
                    icon: "none",
                    title: "不能修改个数"
                  }));
                case 2:
                  a = Number(u.value) + 1;
                  1 === r.value && x((null == (e = v.value) ? void 0 : e.id) || "", 1) < a ? n.index.showToast({
                    icon: "none",
                    title: "赠与者鲜花个数不足"
                  }) : u.value = a;
                case 4:
                case "end":
                  return _context.stop();
              }
            }, _callee);
          }));
        },
        k = function k() {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
            var e;
            return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
              while (1) switch (_context2.prev = _context2.next) {
                case 0:
                  if (!d.value) {
                    _context2.next = 2;
                    break;
                  }
                  return _context2.abrupt("return", void n.index.showToast({
                    icon: "none",
                    title: "不能修改个数"
                  }));
                case 2:
                  e = Number(u.value) - 1;
                  e <= 0 ? n.index.showToast({
                    icon: "none",
                    title: "鲜花个数不能小于1"
                  }) : u.value = e;
                case 4:
                case "end":
                  return _context2.stop();
              }
            }, _callee2);
          }));
        },
        T = function T() {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3() {
            var e, o, l, t, s, d, _e2, _a;
            return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
              while (1) switch (_context3.prev = _context3.next) {
                case 0:
                  if (!h.value) {
                    _context3.next = 2;
                    break;
                  }
                  return _context3.abrupt("return");
                case 2:
                  t = Number(u.value);
                  if (!(1 === r.value && x((null == (e = v.value) ? void 0 : e.id) || "", 1) < t)) {
                    _context3.next = 5;
                    break;
                  }
                  return _context3.abrupt("return", void n.index.showToast({
                    icon: "none",
                    title: "赠与者鲜花个数不足"
                  }));
                case 5:
                  s = {
                    event: i.value,
                    initiator: (null == (o = v.value) ? void 0 : o.id) || "",
                    behavior: r.value,
                    target: null == (l = w.value) ? void 0 : l.id,
                    flowerCount: t
                  };
                  h.value = !0;
                  _context3.next = 9;
                  return a.apiAddFlowerLog(s).finally(function () {
                    h.value = !1;
                  });
                case 9:
                  d = _context3.sent;
                  if ("ok" === d.result && d.data) {
                    if (1 === r.value) {
                      _e2 = n.index.createInnerAudioContext(), _a = Math.random();
                      _e2.src = _a < .5 ? "/static/audios/obtainflower1.mp3" : "/static/audios/obtainflower2.mp3", _e2.autoplay = !1, _e2.stop(), _e2.play();
                    }
                    n.index.navigateBack({
                      delta: 1
                    });
                  } else n.index.showToast({
                    icon: "none",
                    title: d.data
                  });
                case 11:
                case "end":
                  return _context3.stop();
              }
            }, _callee3);
          }));
        },
        E = function E() {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee4() {
            var e, o;
            return _regeneratorRuntime2().wrap(function _callee4$(_context4) {
              while (1) switch (_context4.prev = _context4.next) {
                case 0:
                  if (!h.value) {
                    _context4.next = 2;
                    break;
                  }
                  return _context4.abrupt("return");
                case 2:
                  h.value = !0;
                  _context4.next = 5;
                  return a.apiSetFlowerLog((null == (e = d.value) ? void 0 : e.id) || "", i.value).finally(function () {
                    h.value = !1;
                  });
                case 5:
                  o = _context4.sent;
                  "ok" === o.result && o.data ? (n.index.showToast({
                    icon: "none",
                    title: "编辑记录成功"
                  }), n.index.navigateBack({
                    delta: 1
                  })) : n.index.showToast({
                    icon: "none",
                    title: o.data
                  });
                case 7:
                case "end":
                  return _context4.stop();
              }
            }, _callee4);
          }));
        },
        F = function F() {
          d.value || p.value.length < 2 || s.value.showModal();
        },
        M = function M(e) {
          w.value = e, L(), s.value.closeModal();
        },
        L = function L() {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee5() {
            var e, n;
            return _regeneratorRuntime2().wrap(function _callee5$(_context5) {
              while (1) switch (_context5.prev = _context5.next) {
                case 0:
                  if (!(f.value = [], c.value = [], !w.value)) {
                    _context5.next = 2;
                    break;
                  }
                  return _context5.abrupt("return");
                case 2:
                  _context5.next = 4;
                  return a.apiGetEventSettings("addFlowersEvents", w.value.id);
                case 4:
                  e = _context5.sent;
                  _context5.next = 7;
                  return a.apiGetEventSettings("delFlowersEvents", w.value.id);
                case 7:
                  n = _context5.sent;
                  "ok" === e.result && e.data && e.data.forEach(function (e) {
                    var n;
                    null == (n = f.value) || n.push(e);
                  }), "ok" === n.result && n.data && n.data.forEach(function (e) {
                    var n;
                    null == (n = c.value) || n.push(e);
                  });
                case 9:
                case "end":
                  return _context5.stop();
              }
            }, _callee5);
          }));
        };
      return n.onLoad(function (n) {
        return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee6() {
          var e, _e3;
          return _regeneratorRuntime2().wrap(function _callee6$(_context6) {
            while (1) switch (_context6.prev = _context6.next) {
              case 0:
                _context6.next = 2;
                return m();
              case 2:
                L();
                _context6.next = 5;
                return a.apiGetMemberBySelf();
              case 5:
                e = _context6.sent;
                if (!("ok" === e.result && e.data && (v.value = e.data), t.value = !1, n && n.logId)) {
                  _context6.next = 11;
                  break;
                }
                _context6.next = 9;
                return a.apiGetFlowerLog(n.logId);
              case 9:
                _e3 = _context6.sent;
                "ok" === _e3.result && _e3.data && (d.value = _e3.data, i.value = d.value.event, u.value = d.value.flowerCount, r.value = d.value.behavior, w.value = p.value.find(function (e) {
                  var n;
                  return e.role.name === (null == (n = d.value) ? void 0 : n.target.name);
                }), t.value = !0);
              case 11:
              case "end":
                return _context6.stop();
            }
          }, _callee6);
        }));
      }), function (e, a) {
        var o, l;
        return n.e({
          a: n.unref(h)
        }, (n.unref(h), {}), {
          b: null == (o = n.unref(w)) ? void 0 : o.avatar,
          c: n.t(null == (l = n.unref(w)) ? void 0 : l.name),
          d: !n.unref(d) && n.unref(p).length > 1
        }, (!n.unref(d) && n.unref(p).length, {}), {
          e: n.o(F),
          f: n.n(1 === n.unref(r) ? "color-black" : "color-grey"),
          g: 1 === n.unref(r)
        }, (n.unref(r), {}), {
          h: n.o(function (e) {
            return g(1);
          }),
          i: n.n(2 === n.unref(r) ? "color-black" : "color-grey"),
          j: 2 === n.unref(r)
        }, (n.unref(r), {}), {
          k: n.o(function (e) {
            return g(2);
          }),
          l: n.unref(t),
          m: n.unref(u),
          n: n.o(function (e) {
            return n.isRef(u) ? u.value = e.detail.value : null;
          }),
          o: n.o(k),
          p: n.o(_),
          q: n.unref(i),
          r: n.o(function (e) {
            return n.isRef(i) ? i.value = e.detail.value : null;
          }),
          s: n.f(1 === n.unref(r) ? n.unref(f) : n.unref(c), function (e, a, o) {
            return {
              a: n.t(e),
              b: n.n(n.unref(i) === e ? " color-_a_EF5D56" : " color-_a_323233"),
              c: n.n(n.unref(i) === e ? "bg-_a_FDEEEE" : "bg-_a_f6f6f6"),
              d: e,
              e: n.o(function (n) {
                return a = e, void (i.value = a);
                var a;
              }, e)
            };
          }),
          t: n.o(y),
          v: n.sr(s, "555dbea1-2,555dbea1-0", {
            k: "selectBabyRef"
          }),
          w: n.o(M),
          x: n.p({
            "select-list": n.unref(p)
          })
        });
      };
    }
  }),
  i = n._export_sfc(u, [["__scopeId", "data-v-555dbea1"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/pages/editFlower/index.vue"]]);wx.createPage(i);