var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var e = function e(_e, n, t) {
  return new Promise(function (o, a) {
    var i = function i(e) {
        try {
          u(t.next(e));
        } catch (n) {
          a(n);
        }
      },
      r = function r(e) {
        try {
          u(t.throw(e));
        } catch (n) {
          a(n);
        }
      },
      u = function u(e) {
        return e.done ? o(e.value) : Promise.resolve(e.value).then(i, r);
      };
    u((t = t.apply(_e, n)).next());
  });
};var n = require("../../common/vendor.js"),
  t = require("../../common/utils.js"),
  o = require("../../api/api.js");if (!Array) {
  (n.resolveComponent("wd-input") + n.resolveComponent("layout-no-bar-uni"))();
}Math || (a + function () {
  return "../../node-modules/wot-design-uni/components/wd-input/wd-input.js";
})();var a = function a() {
    return "../../components/Loading/loading.js";
  },
  i = n.defineComponent({
    __name: "editName",
    setup: function setup(a) {
      var _this = this;
      var i = n.ref(),
        r = n.ref(!1),
        u = n.ref(),
        l = function l() {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
            var _t$checkStr, e, a, l, s, d;
            return _regeneratorRuntime2().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  if (!(r.value || !u.value)) {
                    _context.next = 2;
                    break;
                  }
                  return _context.abrupt("return");
                case 2:
                  if (i.value) {
                    _context.next = 4;
                    break;
                  }
                  return _context.abrupt("return", void n.index.showToast({
                    icon: "none",
                    title: "请输入新名字"
                  }));
                case 4:
                  _t$checkStr = t.checkStr(i.value), e = _t$checkStr.numberCount, a = _t$checkStr.spaceCount, l = _t$checkStr.chineseCount, s = _t$checkStr.englishCount, d = _t$checkStr.otherCount;
                  if (!(e > 0)) {
                    _context.next = 9;
                    break;
                  }
                  n.index.showToast({
                    icon: "none",
                    title: "名字中不能有数字"
                  });
                  _context.next = 26;
                  break;
                case 9:
                  if (!(a > 0)) {
                    _context.next = 13;
                    break;
                  }
                  n.index.showToast({
                    icon: "none",
                    title: "名字中不能有空格"
                  });
                  _context.next = 26;
                  break;
                case 13:
                  if (!(d > 0)) {
                    _context.next = 17;
                    break;
                  }
                  n.index.showToast({
                    icon: "none",
                    title: "名字中不能有特殊字符"
                  });
                  _context.next = 26;
                  break;
                case 17:
                  if (!(2 * l + s > 20)) {
                    _context.next = 21;
                    break;
                  }
                  n.index.showToast({
                    icon: "none",
                    title: "名字过长"
                  });
                  _context.next = 26;
                  break;
                case 21:
                  r.value = !0;
                  _context.next = 24;
                  return o.apiSetMemberName(u.value.id, i.value);
                case 24:
                  r.value = !1;
                  n.index.navigateBack({
                    delta: 1
                  });
                case 26:
                case "end":
                  return _context.stop();
              }
            }, _callee);
          }));
        };
      return n.onLoad(function (t) {
        return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
          var e;
          return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
            while (1) switch (_context2.prev = _context2.next) {
              case 0:
                if (!(!t || !t.memberId)) {
                  _context2.next = 2;
                  break;
                }
                return _context2.abrupt("return", void n.index.navigateBack({
                  delta: 1
                }));
              case 2:
                _context2.next = 4;
                return o.apiGetFamilyMember(t.memberId);
              case 4:
                e = _context2.sent;
                "ok" === e.result && e.data && (i.value = e.data.name, u.value = e.data);
              case 6:
              case "end":
                return _context2.stop();
            }
          }, _callee2);
        }));
      }), function (e, t) {
        return n.e({
          a: n.unref(r)
        }, (n.unref(r), {}), {
          b: n.o(function (e) {
            return n.isRef(i) ? i.value = e : null;
          }),
          c: n.p({
            type: "text",
            maxlength: 30,
            placeholder: "设置名称",
            "no-border": "true",
            clearable: !0,
            modelValue: n.unref(i)
          }),
          d: n.n(n.unref(i) ? "opacity-100" : "opacity-50"),
          e: n.o(l)
        });
      };
    }
  }),
  r = n._export_sfc(i, [["__scopeId", "data-v-7bbb6019"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/pages/editName/editName.vue"]]);wx.createPage(r);