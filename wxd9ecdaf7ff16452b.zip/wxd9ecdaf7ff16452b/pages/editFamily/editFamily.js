var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var e = function e(_e, n, o) {
  return new Promise(function (t, a) {
    var i = function i(e) {
        try {
          s(o.next(e));
        } catch (n) {
          a(n);
        }
      },
      l = function l(e) {
        try {
          s(o.throw(e));
        } catch (n) {
          a(n);
        }
      },
      s = function s(e) {
        return e.done ? t(e.value) : Promise.resolve(e.value).then(i, l);
      };
    s((o = o.apply(_e, n)).next());
  });
};var n = require("../../common/vendor.js"),
  o = require("../../api/api.js"),
  t = require("../../common/utils.js");if (!Array) {
  (n.resolveComponent("wd-input") + n.resolveComponent("layout-no-bar-uni"))();
}Math || (a + function () {
  return "../../node-modules/wot-design-uni/components/wd-input/wd-input.js";
})();var a = function a() {
    return "../../components/Loading/loading.js";
  },
  i = n.defineComponent({
    __name: "editFamily",
    setup: function setup(a) {
      var _this = this;
      var i = n.ref(),
        l = n.ref(!1),
        s = function s() {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
            var _t$checkStr, e, a, s, r, u;
            return _regeneratorRuntime2().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  if (!l.value) {
                    _context.next = 2;
                    break;
                  }
                  return _context.abrupt("return");
                case 2:
                  if (i.value) {
                    _context.next = 4;
                    break;
                  }
                  return _context.abrupt("return", void n.index.showToast({
                    icon: "none",
                    title: "请输入新名字"
                  }));
                case 4:
                  _t$checkStr = t.checkStr(i.value), e = _t$checkStr.numberCount, a = _t$checkStr.spaceCount, s = _t$checkStr.chineseCount, r = _t$checkStr.englishCount, u = _t$checkStr.otherCount;
                  if (!(e > 0)) {
                    _context.next = 9;
                    break;
                  }
                  n.index.showToast({
                    icon: "none",
                    title: "名字中不能有数字"
                  });
                  _context.next = 26;
                  break;
                case 9:
                  if (!(a > 0)) {
                    _context.next = 13;
                    break;
                  }
                  n.index.showToast({
                    icon: "none",
                    title: "名字中不能有空格"
                  });
                  _context.next = 26;
                  break;
                case 13:
                  if (!(u > 0)) {
                    _context.next = 17;
                    break;
                  }
                  n.index.showToast({
                    icon: "none",
                    title: "名字中不能有特殊字符"
                  });
                  _context.next = 26;
                  break;
                case 17:
                  if (!(2 * s + r > 30)) {
                    _context.next = 21;
                    break;
                  }
                  n.index.showToast({
                    icon: "none",
                    title: "名字过长"
                  });
                  _context.next = 26;
                  break;
                case 21:
                  l.value = !0;
                  _context.next = 24;
                  return o.apiSetFamilyInfo(i.value);
                case 24:
                  l.value = !1;
                  n.index.navigateBack({
                    delta: 1
                  });
                case 26:
                case "end":
                  return _context.stop();
              }
            }, _callee);
          }));
        };
      return n.onLoad(function (n) {
        return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
          var e;
          return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
            while (1) switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return o.apiGetFamily();
              case 2:
                e = _context2.sent;
                "ok" === e.result && e.data && (i.value = e.data.name);
              case 4:
              case "end":
                return _context2.stop();
            }
          }, _callee2);
        }));
      }), function (e, o) {
        return n.e({
          a: n.unref(l)
        }, (n.unref(l), {}), {
          b: n.o(function (e) {
            return n.isRef(i) ? i.value = e : null;
          }),
          c: n.p({
            type: "text",
            maxlength: 40,
            placeholder: "设置名称",
            "no-border": "true",
            clearable: !0,
            modelValue: n.unref(i)
          }),
          d: n.n(n.unref(i) ? "opacity-100" : "opacity-50"),
          e: n.o(s)
        });
      };
    }
  }),
  l = n._export_sfc(i, [["__scopeId", "data-v-fc73738b"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/pages/editFamily/editFamily.vue"]]);wx.createPage(l);