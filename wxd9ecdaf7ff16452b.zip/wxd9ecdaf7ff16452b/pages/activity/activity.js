var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var e = function e(_e, t, a) {
  return new Promise(function (n, o) {
    var r = function r(e) {
        try {
          l(a.next(e));
        } catch (t) {
          o(t);
        }
      },
      i = function i(e) {
        try {
          l(a.throw(e));
        } catch (t) {
          o(t);
        }
      },
      l = function l(e) {
        return e.done ? n(e.value) : Promise.resolve(e.value).then(r, i);
      };
    l((a = a.apply(_e, t)).next());
  });
};var t = require("../../common/vendor.js"),
  a = require("../../api/api.js");if (!Array) {
  t.resolveComponent("layout-no-bar-uni")();
}Math || n();var n = function n() {
    return "../../components/Loading/loading.js";
  },
  o = t.defineComponent({
    __name: "activity",
    setup: function setup(n) {
      var _this = this;
      var o = t.ref(!1),
        r = t.ref(!1),
        i = t.ref(0),
        l = t.ref(),
        s = function s() {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
            var e, n, i;
            return _regeneratorRuntime2().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  if (!(o.value || r.value)) {
                    _context.next = 2;
                    break;
                  }
                  return _context.abrupt("return");
                case 2:
                  r.value = !0;
                  _context.next = 5;
                  return a.apiObtainFlowers((null == (e = l.value) ? void 0 : e.id) || "").finally(function () {
                    r.value = !1;
                  });
                case 5:
                  n = _context.sent;
                  i = t.index.createInnerAudioContext();
                  i.src = "/static/audios/addflower.mp3", i.autoplay = !1, i.stop(), i.play(), "ok" === n.result && n.data ? (o.value = !0, t.index.showToast({
                    icon: "none",
                    title: "领取成功"
                  })) : t.index.showToast({
                    icon: "none",
                    title: n.data
                  });
                case 8:
                case "end":
                  return _context.stop();
              }
            }, _callee);
          }));
        };
      return t.onShow(function () {
        return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
          var e, t;
          return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
            while (1) switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return a.apiGetMemberBySelf();
              case 2:
                e = _context2.sent;
                "ok" === e.result && e.data && (l.value = e.data, o.value = l.value.checkIn);
                _context2.next = 6;
                return a.apiGetFlowersSetting();
              case 6:
                t = _context2.sent;
                "ok" === t.result && t.data && (i.value = t.data);
              case 8:
              case "end":
                return _context2.stop();
            }
          }, _callee2);
        }));
      }), function (e, a) {
        return t.e({
          a: t.unref(r)
        }, (t.unref(r), {}), {
          b: t.unref(o)
        }, t.unref(o) ? {
          c: t.o(s)
        } : {
          d: t.t(t.unref(i)),
          e: t.o(s)
        });
      };
    }
  }),
  r = t._export_sfc(o, [["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/pages/activity/activity.vue"]]);wx.createPage(r);