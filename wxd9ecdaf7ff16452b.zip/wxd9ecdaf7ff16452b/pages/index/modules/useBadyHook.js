var _regeneratorRuntime2 = require("../../../@babel/runtime/helpers/regeneratorRuntime");var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  r = Object.defineProperties,
  t = Object.getOwnPropertyDescriptors,
  a = Object.getOwnPropertySymbols,
  l = Object.prototype.hasOwnProperty,
  o = Object.prototype.propertyIsEnumerable,
  n = function n(r, t, a) {
    return t in r ? e(r, t, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: a
    }) : r[t] = a;
  };var i = require("../../../api/api.js"),
  u = require("../../../common/vendor.js"),
  s = u.ref();exports.useBabyHooks = function () {
  var e = u.ref([]),
    v = u.ref([]);
  return {
    currentSelectBaby: s,
    babyList: e,
    getMemberList: function getMemberList() {
      return u = exports, c = null, p = /*#__PURE__*/_regeneratorRuntime2().mark(function p() {
        var u, c, _r;
        return _regeneratorRuntime2().wrap(function p$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return i.apiGetFamilyMemberList();
            case 2:
              c = _context.sent;
              if ("ok" === c.result && c.data) if (v.value = c.data, e.value = [], c.data.forEach(function (i) {
                var u, s, v;
                "parent" !== i.role.type && (null == (u = e.value) || u.push((s = function (e, r) {
                  for (var t in r || (r = {})) l.call(r, t) && n(e, t, r[t]);
                  if (a) {
                    var _iterator = _createForOfIteratorHelper2(a(r)),
                      _step;
                    try {
                      for (_iterator.s(); !(_step = _iterator.n()).done;) {
                        var t = _step.value;
                        o.call(r, t) && n(e, t, r[t]);
                      }
                    } catch (err) {
                      _iterator.e(err);
                    } finally {
                      _iterator.f();
                    }
                  }
                  return e;
                }({}, i), v = {
                  avatar: "../../static/images/" + i.avatar
                }, r(s, t(v)))));
              }), null == (u = e.value) ? void 0 : u.length) {
                if (s.value) {
                  _r = e.value.find(function (e) {
                    var r;
                    return e.id === (null == (r = s.value) ? void 0 : r.id);
                  });
                  s.value = _r;
                } else s.value = e.value[0];
              } else s.value = void 0;
            case 4:
            case "end":
              return _context.stop();
          }
        }, p);
      }), new Promise(function (e, r) {
        var t = function t(e) {
            try {
              l(p.next(e));
            } catch (t) {
              r(t);
            }
          },
          a = function a(e) {
            try {
              l(p.throw(e));
            } catch (t) {
              r(t);
            }
          },
          l = function l(r) {
            return r.done ? e(r.value) : Promise.resolve(r.value).then(t, a);
          };
        l((p = p.apply(u, c)).next());
      });
      var u, c, p;
    },
    allMemberList: v,
    getMemberFlowerCount: function getMemberFlowerCount(e, r) {
      var t = 0;
      return v.value.forEach(function (a) {
        a.id === e && a.flowerList.forEach(function (e) {
          e.flowerType === r && (t = e.flowerCount);
        });
      }), t;
    }
  };
};