var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _createForOfIteratorHelper2 = require("../../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  l = Object.defineProperties,
  a = Object.getOwnPropertyDescriptors,
  n = Object.getOwnPropertySymbols,
  t = Object.prototype.hasOwnProperty,
  i = Object.prototype.propertyIsEnumerable,
  o = function o(l, a, n) {
    return a in l ? e(l, a, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: n
    }) : l[a] = n;
  },
  u = function u(e, l, a) {
    return new Promise(function (n, t) {
      var i = function i(e) {
          try {
            u(a.next(e));
          } catch (l) {
            t(l);
          }
        },
        o = function o(e) {
          try {
            u(a.throw(e));
          } catch (l) {
            t(l);
          }
        },
        u = function u(e) {
          return e.done ? n(e.value) : Promise.resolve(e.value).then(i, o);
        };
      u((a = a.apply(e, l)).next());
    });
  };var r = require("../../common/vendor.js"),
  s = require("../../api/api.js"),
  d = require("./modules/useBadyHook.js");require("../../store/index.js");var v = require("../../common/utils.js"),
  c = require("../../utils/index.js"),
  f = require("../../store/user.js");if (!Array) {
  r.resolveComponent("layout-default-uni")();
}Math || (y + p + g + h + m)();var h = function h() {
    return "../../components/AddMemberModal/index.js";
  },
  m = function m() {
    return "../../components/SelectModal/index.js";
  },
  p = function p() {
    return "../../components/RecordCard/index.js";
  },
  g = function g() {
    return "../../components/InstanceTaskEntry/index.js";
  },
  y = function y() {
    return "../../components/Loading/loading.js";
  },
  b = "../../static/images/",
  w = r.defineComponent((x = function (e, l) {
    for (var a in l || (l = {})) t.call(l, a) && o(e, a, l[a]);
    if (n) {
      var _iterator = _createForOfIteratorHelper2(n(l)),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var a = _step.value;
          i.call(l, a) && o(e, a, l[a]);
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
    return e;
  }({}, {
    name: "Home"
  }), l(x, a({
    __name: "index",
    setup: function setup(e) {
      var _this = this;
      var l = r.ref([]),
        a = r.ref(),
        n = r.ref(),
        t = r.ref(!1),
        i = r.ref(!1),
        o = r.ref(),
        h = r.ref(0),
        m = r.ref(""),
        p = r.ref(1),
        g = r.ref(),
        _f$useUserStore = f.useUserStore(),
        y = _f$useUserStore.setCurrentFamily,
        w = _f$useUserStore.isAccessTokenValid,
        _r$storeToRefs = r.storeToRefs(f.useUserStore()),
        x = _r$storeToRefs.currentFamily,
        _d$useBabyHooks = d.useBabyHooks(),
        k = _d$useBabyHooks.currentSelectBaby,
        _ = _d$useBabyHooks.babyList,
        j = _d$useBabyHooks.getMemberList,
        I = _d$useBabyHooks.allMemberList,
        M = _d$useBabyHooks.getMemberFlowerCount,
        T = function T(e) {
          return u(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
            var l;
            return _regeneratorRuntime2().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  _context.t0 = i.value;
                  if (_context.t0) {
                    _context.next = 17;
                    break;
                  }
                  i.value = !0;
                  if (!((null == (l = e.task) ? void 0 : l.finish) && 0 !== e.task.finish)) {
                    _context.next = 8;
                    break;
                  }
                  _context.next = 6;
                  return s.apiResetTask(e.task.id);
                case 6:
                  _context.next = 10;
                  break;
                case 8:
                  _context.next = 10;
                  return s.apiFinishTask(e.task.id);
                case 10:
                  _context.next = 12;
                  return j();
                case 12:
                  F();
                  P();
                  _context.next = 16;
                  return L();
                case 16:
                  i.value = !1;
                case 17:
                case "end":
                  return _context.stop();
              }
            }, _callee);
          }));
        },
        C = function C(e) {
          p.value !== e && (p.value = e);
        },
        L = function L() {
          return u(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
            var e;
            return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
              while (1) switch (_context2.prev = _context2.next) {
                case 0:
                  if (k.value) {
                    _context2.next = 2;
                    break;
                  }
                  return _context2.abrupt("return");
                case 2:
                  _context2.next = 4;
                  return s.apiGetTaskInstanceList(k.value.id);
                case 4:
                  e = _context2.sent;
                  "ok" === e.result && (g.value = e.data);
                case 6:
                case "end":
                  return _context2.stop();
              }
            }, _callee2);
          }));
        },
        S = function S(e) {
          return u(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3() {
            return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
              while (1) switch (_context3.prev = _context3.next) {
                case 0:
                case "end":
                  return _context3.stop();
              }
            }, _callee3);
          }));
        },
        $ = function $(e) {
          return u(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee4() {
            return _regeneratorRuntime2().wrap(function _callee4$(_context4) {
              while (1) switch (_context4.prev = _context4.next) {
                case 0:
                  _context4.next = 2;
                  return j();
                case 2:
                  F();
                  P();
                case 4:
                case "end":
                  return _context4.stop();
              }
            }, _callee4);
          }));
        },
        q = function q(e) {
          return u(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee5() {
            var l;
            return _regeneratorRuntime2().wrap(function _callee5$(_context5) {
              while (1) switch (_context5.prev = _context5.next) {
                case 0:
                  if (!i.value) {
                    _context5.next = 2;
                    break;
                  }
                  return _context5.abrupt("return");
                case 2:
                  if (e.currentSelect) {
                    _context5.next = 4;
                    break;
                  }
                  return _context5.abrupt("return", void r.index.showToast({
                    icon: "none",
                    title: "请选择角色"
                  }));
                case 4:
                  i.value = !0;
                  _context5.next = 7;
                  return s.apiAddFamilyMember(e.currentSelect.label, e.currentSelect.icon.replace(b, ""), Number(e.currentSelect.key)).finally(function () {
                    i.value = !1;
                  });
                case 7:
                  l = _context5.sent;
                  if (!("ok" === l.result && l.data)) {
                    _context5.next = 15;
                    break;
                  }
                  r.index.showToast({
                    icon: "none",
                    title: "添加角色成功"
                  });
                  _context5.next = 12;
                  return j();
                case 12:
                  a.value.handleCloseAddMember();
                  _context5.next = 16;
                  break;
                case 15:
                  r.index.showToast({
                    icon: "none",
                    title: l.data
                  });
                case 16:
                case "end":
                  return _context5.stop();
              }
            }, _callee5);
          }));
        },
        O = c.debounce(function () {
          return u(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee6() {
            var e, _a;
            return _regeneratorRuntime2().wrap(function _callee6$(_context6) {
              while (1) switch (_context6.prev = _context6.next) {
                case 0:
                  if (!t.value) {
                    _context6.next = 2;
                    break;
                  }
                  return _context6.abrupt("return");
                case 2:
                  t.value = !0;
                  _context6.next = 5;
                  return s.apiGetFamilyRoleList("all").finally(function () {
                    t.value = !1;
                  });
                case 5:
                  e = _context6.sent;
                  if ("ok" === e.result && e.data) {
                    {
                      _a = e.data;
                      l.value = [], _a.forEach(function (e) {
                        I.value.some(function (l) {
                          return l.role.id === e.id;
                        }) || l.value.push({
                          key: e.id,
                          label: e.name,
                          icon: b + e.avatar
                        });
                      });
                    }
                    0 !== l.value.length ? a.value.showModal() : r.index.showToast({
                      icon: "none",
                      title: "无可加入的角色"
                    });
                  } else r.index.showToast({
                    icon: "none",
                    title: e.data
                  });
                case 7:
                case "end":
                  return _context6.stop();
              }
            }, _callee6);
          }));
        }),
        A = function A() {
          _.value.length < 2 || (r.index.$emit("hideButtons", {
            id: ""
          }), n.value.showModal());
        },
        B = function B(e) {
          return u(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee7() {
            return _regeneratorRuntime2().wrap(function _callee7$(_context7) {
              while (1) switch (_context7.prev = _context7.next) {
                case 0:
                  k.value = e;
                  n.value.closeModal();
                  F();
                  P();
                  _context7.next = 6;
                  return L();
                case 6:
                case "end":
                  return _context7.stop();
              }
            }, _callee7);
          }));
        },
        F = function F() {
          var e, l, a;
          o.value = [], k && (null == (e = k.value) ? void 0 : e.flowersLogs) && 0 !== (null == (l = k.value) ? void 0 : l.flowersLogs.length) && (null == (a = k.value) || a.flowersLogs.forEach(function (e) {
            (function (e) {
              var l, a;
              var n = !1;
              var _v$getDateInfo = v.getDateInfo(e.createdAt || 0),
                t = _v$getDateInfo.year,
                i = _v$getDateInfo.month,
                u = _v$getDateInfo.week;
              null == (l = o.value) || l.forEach(function (l) {
                l.year === t && l.month === i && l.week === u && (2 === e.behavior ? l.flowerCount -= e.flowerCount : l.flowerCount += e.flowerCount, l.flowersLogs.push(e), n = !0);
              }), n || null == (a = o.value) || a.push({
                year: t,
                month: i,
                week: u,
                flowerCount: 2 === e.behavior ? -e.flowerCount : e.flowerCount,
                flowersLogs: [e]
              });
            })(e);
          }));
        },
        P = function P() {
          k.value ? h.value = M(k.value.id, 1) : h.value = 0;
        },
        E = function E(e) {
          r.index.$emit("hideButtons", {
            id: ""
          });
        },
        R = function R() {
          var e = "";
          e = "" === U.value.uid ? "/pages/login/login" : "" === U.value.invitationId ? "/pages/login/login?uid=".concat(U.value.uid) : "/pages/login/login?uid=".concat(U.value.uid, "&invitationId=").concat(U.value.invitationId), r.index.navigateTo({
            url: e
          }), U.value.uid = "", U.value.invitationId = "";
        };
      r.onShareAppMessage(function () {
        return u(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee8() {
          return _regeneratorRuntime2().wrap(function _callee8$(_context8) {
            while (1) switch (_context8.prev = _context8.next) {
              case 0:
                return _context8.abrupt("return", {
                  title: "轻松培养娃娃养成良好习惯",
                  imageUrl: "../../static/images/invitation_bg1.png",
                  path: "/pages/index/index?uid=".concat(m.value)
                });
              case 1:
              case "end":
                return _context8.stop();
            }
          }, _callee8);
        }));
      }), r.onShareTimeline(function () {
        return console.log("currentUid", m.value), {
          title: "小红花成长日记帮助孩子养成良好的行为习惯",
          imageUrl: "../../static/images/invitation_bg1.png",
          query: "uid=".concat(m.value)
        };
      });
      var U = r.ref({
        uid: "",
        invitationId: ""
      });
      return r.onShow(function () {
        return u(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee9() {
          var e, l;
          return _regeneratorRuntime2().wrap(function _callee9$(_context9) {
            while (1) switch (_context9.prev = _context9.next) {
              case 0:
                if (!(console.log("home_start"), !w())) {
                  _context9.next = 2;
                  break;
                }
                return _context9.abrupt("return", void R());
              case 2:
                _context9.next = 4;
                return s.apiGetFamily();
              case 4:
                e = _context9.sent;
                if (!("ok" !== e.result || null === e.data)) {
                  _context9.next = 7;
                  break;
                }
                return _context9.abrupt("return", void R());
              case 7:
                y(e.data);
                _context9.next = 10;
                return v.openJoin(U.value.invitationId, e.data.id);
              case 10:
                U.value.uid = "";
                U.value.invitationId = "";
                _context9.next = 14;
                return j();
              case 14:
                F();
                P();
                _context9.next = 18;
                return s.apiGetMemberBySelf();
              case 18:
                l = _context9.sent;
                "ok" === l.result && l.data && (m.value = l.data.uid);
                _context9.next = 22;
                return L();
              case 22:
              case "end":
                return _context9.stop();
            }
          }, _callee9);
        }));
      }), r.onLoad(function (e) {
        U.value.uid = "", U.value.invitationId = "", e && (e.uid && (U.value.uid = e.uid), e.invitationId && (U.value.invitationId = e.invitationId));
      }), function (e, t) {
        var u, s, d, v, c, f, m, y, b, w, j, I, M, L, F, P, R;
        return r.e({
          a: i.value
        }, (i.value, {}), {
          b: r.t(null == (u = r.unref(x)) ? void 0 : u.name),
          c: null == (s = r.unref(_)) ? void 0 : s.length
        }, (null == (d = r.unref(_)) ? void 0 : d.length) ? r.e({
          d: null == (v = r.unref(k)) ? void 0 : v.avatar,
          e: r.t(null == (c = r.unref(k)) ? void 0 : c.name),
          f: (null == (f = r.unref(_)) ? void 0 : f.length) > 1
        }, (null == (m = r.unref(_)) || m.length, {}), {
          g: r.o(A),
          h: r.t(h.value)
        }) : {}, {
          i: null == (y = r.unref(_)) ? void 0 : y.length
        }, (null == (b = r.unref(_)) ? void 0 : b.length) ? {
          j: r.n("text-_a_36rpx_a_ mb-_a_10rpx_a_ ".concat(1 === p.value && "font-500")),
          k: r.n("active ".concat(1 === p.value && "active-tab")),
          l: r.o(function (e) {
            return C(1);
          }),
          m: r.n("text-_a_36rpx_a_ mb-_a_10rpx_a_ ".concat(2 === p.value && "font-500")),
          n: r.n("active ".concat(2 === p.value && "active-tab")),
          o: r.o(function (e) {
            return C(2);
          })
        } : {}, {
          p: !(null == (w = r.unref(_)) ? void 0 : w.length)
        }, (null == (j = r.unref(_)) ? void 0 : j.length) ? r.e({
          r: 1 === p.value && !(null == (I = o.value) ? void 0 : I.length) || 2 === p.value && !(null == (M = g.value) ? void 0 : M.length)
        }, 1 === p.value && !(null == (L = o.value) ? void 0 : L.length) || 2 === p.value && !(null == (F = g.value) ? void 0 : F.length) ? r.e({
          s: 1 === p.value
        }, (p.value, {})) : r.e({
          t: 1 === p.value
        }, 1 === p.value ? {
          v: r.f(o.value, function (e, l, a) {
            return {
              a: r.t(e.month),
              b: r.t(e.week),
              c: r.t(e.flowerCount),
              d: r.f(e.flowersLogs, function (e, l, n) {
                return {
                  a: r.o($, l),
                  b: r.o(S, l),
                  c: "83a5a03c-2-" + a + "-" + n + ",83a5a03c-0",
                  d: r.p({
                    log: e,
                    "show-initiator": !0
                  }),
                  e: l
                };
              }),
              e: l
            };
          })
        } : {
          w: r.f(g.value, function (e, l, a) {
            return {
              a: r.o(T, l),
              b: "83a5a03c-3-" + a + ",83a5a03c-0",
              c: r.p({
                task: e,
                member: r.unref(k)
              }),
              d: l
            };
          })
        })) : {
          q: r.o(function () {
            return r.unref(O) && r.unref(O).apply(void 0, arguments);
          })
        }, {
          x: (null == (P = r.unref(_)) ? void 0 : P.length) && 2 === p.value
        }, (null == (R = r.unref(_)) ? void 0 : R.length) && 2 === p.value ? {
          y: r.o(function (e) {
            r.index.navigateTo({
              url: "/pages/editTaskList/editTaskList"
            });
          })
        } : {}, {
          z: r.o(E),
          A: r.sr(a, "83a5a03c-4,83a5a03c-0", {
            k: "addMemberModalRef"
          }),
          B: r.o(q),
          C: r.p({
            title: "添加成员",
            "member-list": l.value,
            "is-show-input": !1
          }),
          D: r.sr(n, "83a5a03c-5,83a5a03c-0", {
            k: "selectBabyRef"
          }),
          E: r.o(B),
          F: r.p({
            "select-list": r.unref(_)
          })
        });
      };
    }
  }))));var x;w.__runtimeHooks = 6;var k = r._export_sfc(w, [["__scopeId", "data-v-83a5a03c"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/pages/index/index.vue"]]);wx.createPage(k);