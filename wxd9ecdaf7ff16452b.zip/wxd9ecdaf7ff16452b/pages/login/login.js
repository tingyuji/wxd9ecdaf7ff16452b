var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var e = function e(_e, n, i) {
  return new Promise(function (t, o) {
    var a = function a(e) {
        try {
          u(i.next(e));
        } catch (n) {
          o(n);
        }
      },
      l = function l(e) {
        try {
          u(i.throw(e));
        } catch (n) {
          o(n);
        }
      },
      u = function u(e) {
        return e.done ? t(e.value) : Promise.resolve(e.value).then(a, l);
      };
    u((i = i.apply(_e, n)).next());
  });
};var n = require("../../common/vendor.js");require("../../store/index.js");var i = require("../../api/api.js"),
  t = require("../../common/utils.js"),
  o = require("../../store/user.js");if (!Array) {
  n.resolveComponent("layout-no-bar-uni")();
}Math || (u + a + l)();var a = function a() {
    return "../../components/AddMemberModal/index.js";
  },
  l = function l() {
    return "../../components/ConfirmClauseModal/index.js";
  },
  u = function u() {
    return "../../components/Loading/loading.js";
  },
  s = n.defineComponent({
    __name: "login",
    setup: function setup(a) {
      var _this = this;
      var l = n.ref([{
          key: "mother",
          label: "妈妈",
          icon: ""
        }]),
        _o$useUserStore = o.useUserStore(),
        u = _o$useUserStore.setAccessToken,
        s = _o$useUserStore.isAccessTokenValid,
        r = n.ref(!1),
        d = n.ref(!1),
        c = n.ref(!1),
        v = n.ref(""),
        f = n.ref({
          iv: "",
          encdata: ""
        }),
        p = n.ref(),
        h = n.ref(),
        m = n.ref({
          uid: "",
          invitationId: ""
        }),
        x = function x(t) {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
            var e;
            return _regeneratorRuntime2().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  if (!r.value) {
                    _context.next = 2;
                    break;
                  }
                  return _context.abrupt("return");
                case 2:
                  if (t.inputValue) {
                    _context.next = 4;
                    break;
                  }
                  return _context.abrupt("return", void n.index.showToast({
                    icon: "none",
                    title: "请输入家庭名字"
                  }));
                case 4:
                  if (t.currentSelect) {
                    _context.next = 6;
                    break;
                  }
                  return _context.abrupt("return", void n.index.showToast({
                    icon: "none",
                    title: "请选择角色"
                  }));
                case 6:
                  r.value = !0;
                  _context.next = 9;
                  return i.apiCreateFamily(t.inputValue, t.currentSelect.label, Number(t.currentSelect.key)).finally(function () {
                    r.value = !1;
                  });
                case 9:
                  e = _context.sent;
                  "ok" === e.result && e.data ? (n.index.showToast({
                    icon: "none",
                    title: "创建成功"
                  }), p.value.handleCloseAddMember(), n.index.switchTab({
                    url: "/pages/index/index"
                  })) : n.index.showToast({
                    icon: "none",
                    title: e.data
                  });
                case 11:
                case "end":
                  return _context.stop();
              }
            }, _callee);
          }));
        },
        g = function g(i) {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
            return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
              while (1) switch (_context2.prev = _context2.next) {
                case 0:
                  d.value = i, d.value && n.index.showToast({
                    icon: "none",
                    title: "授权成功"
                  });
                case 1:
                case "end":
                  return _context2.stop();
              }
            }, _callee2);
          }));
        },
        y = function y() {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3() {
            var e, _n;
            return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
              while (1) switch (_context3.prev = _context3.next) {
                case 0:
                  _context3.next = 2;
                  return i.apiGetFamily();
                case 2:
                  e = _context3.sent;
                  if (!("ok" === e.result && e.data)) {
                    _context3.next = 7;
                    break;
                  }
                  _n = e.data;
                  if (!(null != _n)) {
                    _context3.next = 7;
                    break;
                  }
                  return _context3.abrupt("return", (c.value = !0, _n.id));
                case 7:
                  return _context3.abrupt("return", (c.value = !1, ""));
                case 8:
                case "end":
                  return _context3.stop();
              }
            }, _callee3);
          }));
        },
        w = function w() {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee4() {
            var e, _n2;
            return _regeneratorRuntime2().wrap(function _callee4$(_context4) {
              while (1) switch (_context4.prev = _context4.next) {
                case 0:
                  _context4.next = 2;
                  return i.apiGetFamilyRoleList("parent");
                case 2:
                  e = _context4.sent;
                  if ("ok" === e.result && e.data) {
                    _n2 = e.data;
                    l.value.splice(0, l.value.length), _n2.forEach(function (e) {
                      l.value.push({
                        key: e.id,
                        label: e.name,
                        icon: "/static/images/" + e.avatar
                      });
                    }), p.value.showModal();
                  } else n.index.showToast({
                    icon: "none",
                    title: e.data
                  });
                case 4:
                case "end":
                  return _context4.stop();
              }
            }, _callee4);
          }));
        },
        k = function k() {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee5() {
            var e;
            return _regeneratorRuntime2().wrap(function _callee5$(_context5) {
              while (1) switch (_context5.prev = _context5.next) {
                case 0:
                  if (!r.value) {
                    _context5.next = 2;
                    break;
                  }
                  return _context5.abrupt("return");
                case 2:
                  if (d.value) {
                    _context5.next = 4;
                    break;
                  }
                  return _context5.abrupt("return", void h.value.showModal());
                case 4:
                  if (s()) {
                    _context5.next = 6;
                    break;
                  }
                  return _context5.abrupt("return", void b());
                case 6:
                  _context5.next = 8;
                  return y();
                case 8:
                  e = _context5.sent;
                  _context5.next = 11;
                  return t.openJoin(m.value.invitationId, e);
                case 11:
                  if (!_context5.sent) {
                    _context5.next = 15;
                    break;
                  }
                  m.value.invitationId = "";
                  _context5.next = 21;
                  break;
                case 15:
                  if (!(!0 === c.value)) {
                    _context5.next = 19;
                    break;
                  }
                  n.index.switchTab({
                    url: "/pages/index/index"
                  });
                  _context5.next = 21;
                  break;
                case 19:
                  _context5.next = 21;
                  return w();
                case 21:
                case "end":
                  return _context5.stop();
              }
            }, _callee5);
          }));
        },
        b = function b() {
          c.value = !1, r.value = !0, n.index.login({
            provider: "weixin",
            success: function success(e) {
              var n = e.code;
              console.log("login code:", n), r.value = !1, I(n);
            },
            fail: function fail(e) {
              console.log("login fail:", e), r.value = !1;
            }
          });
        },
        I = function I(i) {
          r.value = !0, n.index.getUserInfo({
            success: function success(n) {
              return e(this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee6() {
                return _regeneratorRuntime2().wrap(function _callee6$(_context6) {
                  while (1) switch (_context6.prev = _context6.next) {
                    case 0:
                      f.value.iv = n.iv;
                      f.value.encdata = n.encryptedData;
                      console.log("profileInfo", JSON.stringify(f.value));
                      _context6.next = 5;
                      return T(i);
                    case 5:
                      r.value = !1;
                    case 6:
                    case "end":
                      return _context6.stop();
                  }
                }, _callee6);
              }));
            },
            fail: function fail(e) {
              console.log("get user info fail:", e), r.value = !1;
            }
          });
        },
        T = function T(o) {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee7() {
            var e, a;
            return _regeneratorRuntime2().wrap(function _callee7$(_context7) {
              while (1) switch (_context7.prev = _context7.next) {
                case 0:
                  if (f.value.iv) {
                    _context7.next = 2;
                    break;
                  }
                  return _context7.abrupt("return");
                case 2:
                  _context7.next = 4;
                  return i.apiLogin({
                    iv: f.value.iv,
                    encdata: f.value.encdata,
                    code: o,
                    wxapp: "flowers",
                    os: "mobile"
                  });
                case 4:
                  e = _context7.sent;
                  if (!("ok" !== e.result)) {
                    _context7.next = 7;
                    break;
                  }
                  return _context7.abrupt("return");
                case 7:
                  u(e.data.token), v.value = e.data.name + "的家庭";
                  _context7.next = 10;
                  return i.apiLoginFlowers(m.value.uid);
                case 10:
                  _context7.t0 = _context7.sent.result;
                  if (!("ok" !== _context7.t0)) {
                    _context7.next = 13;
                    break;
                  }
                  return _context7.abrupt("return");
                case 13:
                  n.index.showToast({
                    icon: "none",
                    title: "授权成功"
                  }), m.value.uid = "";
                  _context7.next = 16;
                  return y();
                case 16:
                  a = _context7.sent;
                  _context7.next = 19;
                  return t.openJoin(m.value.invitationId, a);
                case 19:
                  if (!_context7.sent) {
                    _context7.next = 23;
                    break;
                  }
                  m.value.invitationId = "";
                  _context7.next = 24;
                  break;
                case 23:
                  "" !== a && n.index.switchTab({
                    url: "/pages/index/index"
                  });
                case 24:
                case "end":
                  return _context7.stop();
              }
            }, _callee7);
          }));
        };
      return n.onLoad(function (i) {
        return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee8() {
          return _regeneratorRuntime2().wrap(function _callee8$(_context8) {
            while (1) switch (_context8.prev = _context8.next) {
              case 0:
                d.value = !1, n.index.getSetting({
                  success: function success(e) {
                    d.value = e.authSetting["scope.userInfo"];
                  }
                }), i && (i.uid && (m.value.uid = i.uid), i.invitationId && (m.value.invitationId = i.invitationId));
              case 1:
              case "end":
                return _context8.stop();
            }
          }, _callee8);
        }));
      }), function (e, i) {
        return n.e({
          a: n.unref(r)
        }, (n.unref(r), {}), {
          b: !n.unref(d)
        }, n.unref(d) ? n.e({
          c: !n.unref(s)()
        }, n.unref(s)() ? n.e({
          d: "" !== n.unref(m).invitationId
        }, "" !== n.unref(m).invitationId ? {} : n.e({
          e: !n.unref(c)
        }, (n.unref(c), {}))) : {}) : {}, {
          f: n.o(k),
          g: n.sr(p, "05a54d40-2,05a54d40-0", {
            k: "addMemberModalRef"
          }),
          h: n.o(x),
          i: n.p({
            title: "创建家庭",
            inputStr: n.unref(v),
            "member-list": n.unref(l),
            "is-show-input": !0
          }),
          j: n.sr(h, "05a54d40-3,05a54d40-0", {
            k: "confirmClauseModalRef"
          }),
          k: n.o(g),
          l: n.p({
            title: "确认协议"
          })
        });
      };
    }
  }),
  r = n._export_sfc(s, [["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/pages/login/login.vue"]]);wx.createPage(r);