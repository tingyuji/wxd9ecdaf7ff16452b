var _createForOfIteratorHelper2 = require("../../@babel/runtime/helpers/createForOfIteratorHelper");var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var e = function e(_e, n, o) {
  return new Promise(function (a, i) {
    var t = function t(e) {
        try {
          r(o.next(e));
        } catch (n) {
          i(n);
        }
      },
      l = function l(e) {
        try {
          r(o.throw(e));
        } catch (n) {
          i(n);
        }
      },
      r = function r(e) {
        return e.done ? a(e.value) : Promise.resolve(e.value).then(t, l);
      };
    r((o = o.apply(_e, n)).next());
  });
};var n = require("../../common/vendor.js"),
  o = require("../../api/api.js");if (!Array) {
  (n.resolveComponent("wd-password-input") + n.resolveComponent("wd-number-keyboard") + n.resolveComponent("layout-no-bar-uni"))();
}Math || (a + function () {
  return "../../node-modules/wot-design-uni/components/wd-password-input/wd-password-input.js";
} + function () {
  return "../../node-modules/wot-design-uni/components/wd-number-keyboard/wd-number-keyboard.js";
})();var a = function a() {
    return "../../components/Loading/loading.js";
  },
  i = n.defineComponent({
    __name: "join",
    setup: function setup(a) {
      var _this = this;
      var i = n.ref(!1),
        t = n.ref(""),
        l = n.ref(""),
        r = n.ref(""),
        u = n.ref(!1),
        s = n.ref(""),
        d = n.ref(),
        v = n.ref(),
        f = function f() {
          return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
            var e;
            return _regeneratorRuntime2().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  if (!(i.value || !v.value)) {
                    _context.next = 2;
                    break;
                  }
                  return _context.abrupt("return");
                case 2:
                  if (!(t.value.length < 6)) {
                    _context.next = 4;
                    break;
                  }
                  return _context.abrupt("return", void n.index.showToast({
                    icon: "none",
                    title: "请输入完整的邀请码"
                  }));
                case 4:
                  i.value = !0;
                  _context.next = 7;
                  return o.apiJoinFamily(v.value.id, t.value).finally(function () {
                    i.value = !1;
                  });
                case 7:
                  e = _context.sent;
                  "ok" === e.result && (!0 === e.data ? (n.index.showToast({
                    icon: "none",
                    title: "加入成功"
                  }), n.index.switchTab({
                    url: "/pages/index/index"
                  })) : n.index.showToast({
                    icon: "none",
                    title: "加入失败，请检查邀请码"
                  }));
                case 9:
                case "end":
                  return _context.stop();
              }
            }, _callee);
          }));
        };
      return n.onLoad(function (a) {
        return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
          var e, i, t, u, f, _iterator, _step, _n;
          return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
            while (1) switch (_context2.prev = _context2.next) {
              case 0:
                if (!(!a || !a.invitationId)) {
                  _context2.next = 2;
                  break;
                }
                return _context2.abrupt("return", void n.index.navigateBack({
                  delta: 1
                }));
              case 2:
                _context2.next = 4;
                return o.apiGetInvitation(a.invitationId);
              case 4:
                i = _context2.sent;
                if (!("ok" !== i.result)) {
                  _context2.next = 7;
                  break;
                }
                return _context2.abrupt("return", void n.index.navigateBack({
                  delta: 1
                }));
              case 7:
                v.value = i.data;
                t = v.value.title.split(" ");
                l.value = t[0], r.value = t.slice(1).join(" ");
                _context2.next = 12;
                return o.apiGetFamilyRoleList("all");
              case 12:
                u = _context2.sent;
                if (!("ok" !== u.result)) {
                  _context2.next = 15;
                  break;
                }
                return _context2.abrupt("return", void n.index.navigateBack({
                  delta: 1
                }));
              case 15:
                f = u.data;
                _iterator = _createForOfIteratorHelper2(f);
                _context2.prev = 17;
                _iterator.s();
              case 19:
                if ((_step = _iterator.n()).done) {
                  _context2.next = 26;
                  break;
                }
                _n = _step.value;
                if (!(Number(_n.id) === (null == (e = v.value) ? void 0 : e.inviterRole))) {
                  _context2.next = 24;
                  break;
                }
                d.value = _n, s.value = "../../static/images/" + _n.avatar;
                return _context2.abrupt("break", 26);
              case 24:
                _context2.next = 19;
                break;
              case 26:
                _context2.next = 31;
                break;
              case 28:
                _context2.prev = 28;
                _context2.t0 = _context2["catch"](17);
                _iterator.e(_context2.t0);
              case 31:
                _context2.prev = 31;
                _iterator.f();
                return _context2.finish(31);
              case 34:
                d.value || n.index.navigateBack({
                  delta: 1
                });
              case 35:
              case "end":
                return _context2.stop();
            }
          }, _callee2, null, [[17, 28, 31, 34]]);
        }));
      }), n.onShow(function () {
        return e(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3() {
          return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
            while (1) switch (_context3.prev = _context3.next) {
              case 0:
              case "end":
                return _context3.stop();
            }
          }, _callee3);
        }));
      }), function (e, o) {
        return n.e({
          a: n.unref(i)
        }, (n.unref(i), {}), {
          b: n.unref(s),
          c: n.t(n.unref(l)),
          d: n.t(n.unref(r)),
          e: n.o(function (e) {
            return u.value = !0;
          }),
          f: n.o(function (e) {
            return n.isRef(t) ? t.value = e : null;
          }),
          g: n.p({
            length: 6,
            mask: !1,
            focused: n.unref(u),
            modelValue: n.unref(t)
          }),
          h: n.o(f),
          i: n.o(function (e) {
            return u.value = !1;
          }),
          j: n.o(function (e) {
            return n.isRef(t) ? t.value = e : null;
          }),
          k: n.o(function (e) {
            return n.isRef(u) ? u.value = e : null;
          }),
          l: n.p({
            maxlength: 6,
            modelValue: n.unref(t),
            visible: n.unref(u)
          })
        });
      };
    }
  }),
  t = n._export_sfc(i, [["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/pages/join/join.vue"]]);wx.createPage(t);