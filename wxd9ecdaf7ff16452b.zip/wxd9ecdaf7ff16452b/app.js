Object.defineProperty(exports, Symbol.toStringTag, {
  value: "Module"
});var e = require("./common/vendor.js"),
  o = require("./store/index.js"),
  t = require("./store/user.js"),
  r = require("./store/tabbar.js"),
  n = require("./interceptors/route.js"),
  s = require("./interceptors/request.js"),
  u = require("./interceptors/prototype.js");Math;var p = e.defineComponent({
    __name: "App",
    setup: function setup(o) {
      var n = t.useUserStore(),
        s = r.useTabbarStore();
      return e.onLaunch(function () {
        console.log("App Launch");
        var o = e.index.getAccountInfoSync();
        n.setEnvVersion(o.miniProgram.envVersion), s.setCurrentTab("home"), e.index.setNavigationBarColor({
          frontColor: "#000000",
          backgroundColor: "#e74c3c",
          animation: {
            duration: 200,
            timingFunc: "easeIn"
          }
        });
      }), e.onShow(function () {
        console.log("App Show");
      }), e.onHide(function () {
        console.log("App Hide");
      }), function () {};
    }
  }),
  c = e._export_sfc(p, [["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/App.vue"]]);function a() {
  var t = e.createSSRApp(c);
  return t.use(o.store), t.use(n.routeInterceptor), t.use(s.requestInterceptor), t.use(u.prototypeInterceptor), t.component("layout-default-uni", i), t.component("layout-no-bar-uni", l), t.component("layout-no-bottom-uni", m), {
    app: t
  };
}var i = function i() {
    return "./layouts/default.js";
  },
  l = function l() {
    return "./layouts/noBar.js";
  },
  m = function m() {
    return "./layouts/noBottom.js";
  };a().app.mount("#app"), exports.createApp = a;