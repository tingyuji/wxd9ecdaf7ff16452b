var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var e = require("../../common/vendor.js"),
  t = e.defineComponent({
    __name: "index",
    props: {
      task: {},
      member: {}
    },
    emits: ["delete", "openEdit"],
    setup: function setup(t, _ref) {
      var _this = this;
      var a = _ref.emit;
      var l = t,
        n = e.ref(!1),
        u = a,
        r = e.ref(0),
        v = e.ref(280),
        o = e.ref(.6),
        s = e.ref(0),
        c = e.ref(0),
        i = e.ref(0),
        f = e.ref(!1),
        h = e.ref(0),
        d = e.ref(200),
        k = e.ref(0),
        m = e.ref(!1),
        p = function p(e) {
          if (k.value = e, m.value) return;
          m.value = !0;
          var t = function t() {
            if (!m.value) return;
            var e = 0;
            e = k.value < 0 ? Math.max(k.value, r.value - 4) : Math.min(k.value, r.value + 4), r.value = e, r.value === k.value ? m.value = !1 : setTimeout(t, 5);
          };
          t();
        },
        g = function g(e, t) {
          if (t) return void (e <= -o.value ? (p(-v.value), h.value = -1) : (p(0), h.value = 0));
          if (h.value === e) return;
          h.value = e;
          var a = e * v.value,
            l = s.value + a;
          l <= -v.value ? r.value = -v.value : r.value = l >= 0 ? 0 : l;
        },
        x = function x(t) {
          n.value = !0, c.value = t.touches[0].clientX, i.value = t.touches[0].clientY, s.value = r.value, f.value = !0, e.index.$emit("hideTemplateTask", {
            id: l.task.id
          });
        },
        M = function M(e) {
          if (!f.value) return;
          var t = b(e.touches[0].clientY, i.value),
            a = t / b(e.touches[0].clientX, c.value);
          if (a > 1 || a < -1 || t < -80 || t > 80) return f.value = !1, void g(0, !0);
          var l = e.touches[0].clientX,
            n = _(l);
          g(n, !1);
        },
        T = function T(e) {
          var t = e.changedTouches[0].clientX;
          var a = _(t);
          t === c.value && (a = s.value === -v.value ? -1 : 0), g(a, !0), n.value = !1, f.value = !1;
        },
        b = function b(e, t) {
          var a = e >= c.value ? 1 : -1;
          return a *= e * t >= 0 ? Math.abs(e - t) : Math.abs(e) + Math.abs(t), a;
        },
        _ = function _(e) {
          if (!f.value) return 0;
          var t = e >= c.value ? 1 : -1;
          return e * c.value >= 0 ? t *= Math.abs(e - c.value) : t *= Math.abs(e) + Math.abs(c.value), t <= -d.value ? -1 : t >= d.value ? 1 : t / d.value;
        },
        w = e.ref(["天", "一", "二", "三", "四", "五", "六"]),
        y = function y() {
          if (0 === l.task.cycleMode.length) return "不重复";
          if (7 === l.task.cycleMode.length) return "每天";
          var e = "";
          for (var _t = 0; _t < w.value.length; _t++) l.task.cycleMode.includes(_t) && (e += "" === e ? "星期" + w.value[_t] : "/" + w.value[_t]);
          return e;
        },
        X = function X() {
          f.value || (r.value = 0, u("openEdit", {
            task: l.task
          }));
        },
        $ = function $() {
          return e = _this, t = null, a = /*#__PURE__*/_regeneratorRuntime2().mark(function a() {
            return _regeneratorRuntime2().wrap(function a$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  f.value || (r.value = 0, u("delete", {
                    task: l.task
                  }));
                case 1:
                case "end":
                  return _context.stop();
              }
            }, a);
          }), new Promise(function (l, n) {
            var u = function u(e) {
                try {
                  v(a.next(e));
                } catch (t) {
                  n(t);
                }
              },
              r = function r(e) {
                try {
                  v(a.throw(e));
                } catch (t) {
                  n(t);
                }
              },
              v = function v(e) {
                return e.done ? l(e.value) : Promise.resolve(e.value).then(u, r);
              };
            v((a = a.apply(e, t)).next());
          });
          var e, t, a;
        },
        C = function C(e) {
          e.id !== l.task.id && 0 !== h.value && g(1, !0);
        };
      return e.onMounted(function () {
        e.index.$on("hideTemplateTask", C);
      }), e.onUnmounted(function () {
        e.index.$off("hideTemplateTask", C);
      }), function (t, a) {
        return e.e({
          a: e.t(t.task.content),
          b: e.t(t.task.time),
          c: e.t(y()),
          d: e.t(t.task.flowerCount),
          e: e.unref(r) < 0
        }, e.unref(r) < 0 ? {
          f: e.o(X),
          g: e.o($)
        } : {}, {
          h: t.task.content.length > 0 && t.task.content.length <= 14 ? 1 : "",
          i: t.task.content.length > 14 && t.task.content.length <= 28 ? 1 : "",
          j: t.task.content.length > 28 && t.task.content.length <= 42 ? 1 : "",
          k: t.task.content.length > 42 && t.task.content.length <= 56 ? 1 : "",
          l: "translateX(".concat(e.unref(r), "rpx)"),
          m: e.o(x),
          n: e.o(M),
          o: e.o(T)
        });
      };
    }
  }),
  a = e._export_sfc(t, [["__scopeId", "data-v-fdb0c4f4"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/components/TemplateTaskEntry/index.vue"]]);wx.createComponent(a);