var e = {};var o = require("../../common/vendor.js")._export_sfc(e, [["render", function (e, o) {
  return {};
}], ["__scopeId", "data-v-e8dd6f1a"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/components/Loading/loading.vue"]]);wx.createComponent(o);