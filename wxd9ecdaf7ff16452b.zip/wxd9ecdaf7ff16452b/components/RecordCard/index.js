var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var e = require("../../common/vendor.js"),
  t = require("../../api/api.js"),
  l = require("../../common/utils.js"),
  o = e.defineComponent({
    __name: "index",
    props: {
      log: {},
      showInitiator: {
        type: Boolean
      }
    },
    emits: ["delete", "openEdit"],
    setup: function setup(o, _ref) {
      var _this = this;
      var a = _ref.emit;
      var n = o,
        u = e.ref(0),
        i = e.ref(280),
        r = e.ref(.6),
        v = e.ref(0),
        s = e.ref(0),
        g = e.ref(0),
        d = e.ref(!1),
        c = e.ref(0),
        h = e.ref(200),
        f = e.ref(!1),
        m = a,
        p = e.ref(0),
        w = e.ref(!1),
        x = function x(e) {
          if (p.value = e, w.value) return;
          w.value = !0;
          var t = function t() {
            if (!w.value) return;
            var e = 0;
            e = p.value < 0 ? Math.max(p.value, u.value - 4) : Math.min(p.value, u.value + 4), u.value = e, u.value === p.value ? w.value = !1 : setTimeout(t, 5);
          };
          t();
        },
        b = function b(e, t) {
          if (t) return void (e <= -r.value ? (x(-i.value), c.value = -1) : (x(0), c.value = 0));
          if (c.value === e) return;
          c.value = e;
          var l = e * i.value,
            o = v.value + l;
          o <= -i.value ? u.value = -i.value : u.value = o >= 0 ? 0 : o;
        },
        _ = function _(t) {
          3 !== n.log.behavior && (f.value = !0, s.value = t.touches[0].clientX, g.value = t.touches[0].clientY, v.value = u.value, d.value = !0, e.index.$emit("hideButtons", {
            id: n.log.id
          }));
        },
        M = function M(e) {
          if (!d.value) return;
          var t = y(e.touches[0].clientY, g.value),
            l = t / y(e.touches[0].clientX, s.value);
          if (l > 1 || l < -1 || t < -80 || t > 80) return d.value = !1, void b(0, !0);
          var o = e.touches[0].clientX,
            a = $(o);
          b(a, !1);
        },
        T = function T(e) {
          var t = e.changedTouches[0].clientX;
          var l = $(t);
          t === s.value && (l = v.value === -i.value ? -1 : 0), b(l, !0), f.value = !1, d.value = !1;
        },
        y = function y(e, t) {
          var l = e >= s.value ? 1 : -1;
          return l *= e * t >= 0 ? Math.abs(e - t) : Math.abs(e) + Math.abs(t), l;
        },
        $ = function $(e) {
          if (!d.value) return 0;
          var t = e >= s.value ? 1 : -1;
          return e * s.value >= 0 ? t *= Math.abs(e - s.value) : t *= Math.abs(e) + Math.abs(s.value), t <= -h.value ? -1 : t >= h.value ? 1 : t / h.value;
        },
        C = function C() {
          3 !== n.log.behavior ? (e.index.navigateTo({
            url: "/pages/editFlower/index?logId=".concat(n.log.id)
          }), u.value = 0, m("openEdit", {
            logValue: n.log
          })) : e.index.showToast({
            icon: "none",
            title: "签到记录不能编辑"
          });
        },
        X = function X() {
          return l = _this, o = null, a = /*#__PURE__*/_regeneratorRuntime2().mark(function a() {
            var l;
            return _regeneratorRuntime2().wrap(function a$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  if (!f.value) {
                    _context.next = 2;
                    break;
                  }
                  return _context.abrupt("return");
                case 2:
                  if (!(3 === n.log.behavior)) {
                    _context.next = 4;
                    break;
                  }
                  return _context.abrupt("return", void e.index.showToast({
                    icon: "none",
                    title: "签到记录不能删除"
                  }));
                case 4:
                  f.value = !0;
                  _context.next = 7;
                  return t.apiDelFlowerLog(n.log.id).finally(function () {
                    f.value = !1;
                  });
                case 7:
                  l = _context.sent;
                  "ok" === l.result && l.data ? (e.index.showToast({
                    icon: "none",
                    title: "撤销成功"
                  }), u.value = 0, m("delete", {
                    logValue: n.log
                  })) : e.index.showToast({
                    icon: "none",
                    title: l.data
                  });
                case 9:
                case "end":
                  return _context.stop();
              }
            }, a);
          }), new Promise(function (e, t) {
            var n = function n(e) {
                try {
                  i(a.next(e));
                } catch (l) {
                  t(l);
                }
              },
              u = function u(e) {
                try {
                  i(a.throw(e));
                } catch (l) {
                  t(l);
                }
              },
              i = function i(t) {
                return t.done ? e(t.value) : Promise.resolve(t.value).then(n, u);
              };
            i((a = a.apply(l, o)).next());
          });
          var l, o, a;
        },
        j = function j(e) {
          e.id !== n.log.id && 0 !== c.value && b(1, !0);
        };
      return e.onMounted(function () {
        e.index.$on("hideButtons", j);
      }), e.onUnmounted(function () {
        e.index.$off("hideButtons", j);
      }), function (t, o) {
        return e.e({
          a: e.t(t.log.event),
          b: e.t(2 === t.log.behavior ? "-".concat(t.log.flowerCount) : "+".concat(t.log.flowerCount)),
          c: 1 === t.log.behavior ? "../../static/images/flower_fill.png" : "../../static/images/flower_grey.png",
          d: e.t(t.showInitiator ? t.log.initiator.name : t.log.target.name),
          e: e.t(e.unref(l.formatTime)(t.log.createdAt || 0)),
          f: e.unref(u) < 0
        }, e.unref(u) < 0 ? {
          g: e.o(C),
          h: e.o(X)
        } : {}, {
          i: t.log.event.length > 0 && t.log.event.length <= 14 ? 1 : "",
          j: t.log.event.length > 14 && t.log.event.length <= 28 ? 1 : "",
          k: t.log.event.length > 28 && t.log.event.length <= 42 ? 1 : "",
          l: t.log.event.length > 42 && t.log.event.length <= 56 ? 1 : "",
          m: "translateX(".concat(e.unref(u), "rpx)"),
          n: e.o(_),
          o: e.o(M),
          p: e.o(T)
        });
      };
    }
  }),
  a = e._export_sfc(o, [["__scopeId", "data-v-37ff3dd6"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/components/RecordCard/index.vue"]]);wx.createComponent(a);