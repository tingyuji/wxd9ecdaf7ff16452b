var e = require("../../common/vendor.js");if (!Array) {
  e.resolveComponent("wd-popup")();
}Math;var n = e.defineComponent({
    __name: "index",
    props: {
      content: {},
      cancelText: {},
      confirmText: {}
    },
    emits: ["cancel", "confirm"],
    setup: function setup(n, _ref) {
      var o = _ref.expose,
        c = _ref.emit;
      var t = c,
        r = e.ref(!1),
        l = function l() {
          t("cancel"), r.value = !1;
        };
      return o({
        showModal: function showModal() {
          r.value = !0;
        }
      }), function (n, o) {
        return e.e({
          a: e.t(n.content),
          b: n.cancelText
        }, n.cancelText ? {
          c: e.t(n.cancelText),
          d: e.n(n.confirmText ? "w-_a_320rpx_a_" : "w-full"),
          e: e.o(function (e) {
            return t("cancel"), void (r.value = !1);
          })
        } : {}, {
          f: n.cancelText && n.confirmText
        }, (n.cancelText && n.confirmText, {}), {
          g: n.confirmText
        }, n.confirmText ? {
          h: e.t(n.confirmText),
          i: e.n(n.cancelText ? "w-_a_320rpx_a_" : "w-full"),
          j: e.o(function (e) {
            return t("confirm"), void (r.value = !1);
          })
        } : {}, {
          k: e.o(l),
          l: e.o(function (n) {
            return e.isRef(r) ? r.value = n : null;
          }),
          m: e.p({
            "custom-style": "border-radius: 24rpx",
            position: "center",
            modelValue: e.unref(r)
          })
        });
      };
    }
  }),
  o = e._export_sfc(n, [["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/components/ConfirmTipModal/index.vue"]]);wx.createComponent(o);