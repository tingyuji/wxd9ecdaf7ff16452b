require("../../@babel/runtime/helpers/Arrayincludes");var e = require("../../common/vendor.js");if (!Array) {
  e.resolveComponent("wd-popup")();
}Math;var o = e.defineComponent({
    __name: "index",
    emits: ["confirm"],
    setup: function setup(o, _ref) {
      var r = _ref.expose,
        n = _ref.emit;
      var u = e.ref(["星期天", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"]),
        t = n,
        s = e.ref(!1),
        l = e.ref(),
        a = function a() {
          t("confirm", {
            weeks: l.value
          }), i();
        },
        i = function i() {
          s.value = !1;
        };
      return r({
        showModal: function showModal(e) {
          l.value = e, s.value = !0;
        }
      }), function (o, r) {
        return {
          a: e.f(e.unref(u), function (o, r, n) {
            var u, t;
            return e.e({
              a: e.t(o),
              b: null == (u = e.unref(l)) ? void 0 : u.includes(r)
            }, (null == (t = e.unref(l)) || t.includes(r), {}), {
              c: r,
              d: e.o(function (e) {
                return o = r, void (l.value && (l.value.includes(o) ? l.value = l.value.filter(function (e) {
                  return e !== o;
                }) : l.value.push(o)));
                var o;
              }, r)
            });
          }),
          b: e.o(a),
          c: e.o(i),
          d: e.o(function (o) {
            return e.isRef(s) ? s.value = o : null;
          }),
          e: e.p({
            "custom-style": "border-top-left-radius: 24rpx;border-top-right-radius: 24rpx",
            position: "bottom",
            modelValue: e.unref(s)
          })
        };
      };
    }
  }),
  r = e._export_sfc(o, [["__scopeId", "data-v-e819a22b"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/components/SetWeekModal/index.vue"]]);wx.createComponent(r);