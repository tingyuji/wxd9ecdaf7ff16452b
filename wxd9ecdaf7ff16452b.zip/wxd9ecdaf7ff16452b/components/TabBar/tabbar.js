var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var e = require("../../common/vendor.js"),
  r = require("../../common/assets.js");require("../../store/index.js");var t = require("../../pages/index/modules/useBadyHook.js"),
  s = require("../../store/tabbar.js"),
  n = e.defineComponent({
    __name: "tabbar",
    setup: function setup(n) {
      var _this = this;
      var _t$useBabyHooks = t.useBabyHooks(),
        o = _t$useBabyHooks.babyList,
        i = _t$useBabyHooks.getMemberList,
        _s$useTabbarStore = s.useTabbarStore(),
        a = _s$useTabbarStore.setCurrentTab,
        _e$storeToRefs = e.storeToRefs(s.useTabbarStore()),
        u = _e$storeToRefs.currentTab,
        d = function d(r) {
          switch (e.index.$emit("hideButtons", {
            id: ""
          }), e.index.$emit("hideMember", {
            id: ""
          }), a(r), r) {
            case "home":
              e.index.switchTab({
                url: "/pages/index/index"
              });
              break;
            case "user":
              e.index.switchTab({
                url: "/pages/user/user"
              });
          }
        },
        c = function c() {
          return r = _this, t = null, s = /*#__PURE__*/_regeneratorRuntime2().mark(function s() {
            return _regeneratorRuntime2().wrap(function s$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  _context.next = 2;
                  return i();
                case 2:
                  o.value && 0 !== o.value.length ? (e.index.$emit("hideButtons", {
                    id: ""
                  }), e.index.$emit("hideMember", {
                    id: ""
                  }), e.index.navigateTo({
                    url: "/pages/editFlower/index"
                  })) : e.index.showToast({
                    icon: "none",
                    title: "请先添加宝宝"
                  });
                case 3:
                case "end":
                  return _context.stop();
              }
            }, s);
          }), new Promise(function (e, n) {
            var o = function o(e) {
                try {
                  a(s.next(e));
                } catch (r) {
                  n(r);
                }
              },
              i = function i(e) {
                try {
                  a(s.throw(e));
                } catch (r) {
                  n(r);
                }
              },
              a = function a(r) {
                return r.done ? e(r.value) : Promise.resolve(r.value).then(o, i);
              };
            a((s = s.apply(r, t)).next());
          });
          var r, t, s;
        };
      return function (t, s) {
        return {
          a: "home" === e.unref(u) ? e.unref(r.homeActive) : e.unref(r.homeUnactive),
          b: e.o(function (e) {
            return d("home");
          }),
          c: e.o(c),
          d: "user" === e.unref(u) ? e.unref(r.userActive) : e.unref(r.userUnactive),
          e: e.o(function (e) {
            return d("user");
          })
        };
      };
    }
  }),
  o = e._export_sfc(n, [["__scopeId", "data-v-4cd2a24b"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/components/TabBar/tabbar.vue"]]);wx.createComponent(o);