var e = require("../../common/vendor.js");if (!Array) {
  (e.resolveComponent("wd-datetime-picker-view") + e.resolveComponent("wd-popup"))();
}Math || (function () {
  return "../../node-modules/wot-design-uni/components/wd-datetime-picker-view/wd-datetime-picker-view.js";
} + function () {
  return "../../node-modules/wot-design-uni/components/wd-popup/wd-popup.js";
})();var t = e.defineComponent({
    __name: "index",
    props: {
      type: {},
      title: {},
      minDate: {},
      maxDate: {}
    },
    emits: ["confirm"],
    setup: function setup(t, _ref) {
      var o = _ref.expose,
        n = _ref.emit;
      var a = t,
        i = n,
        p = e.ref(0),
        l = e.ref(""),
        r = e.ref(!1),
        s = function s() {
          r.value = !1;
        },
        m = function m() {
          var e = "";
          if ("time" === a.type) e = l.value;else {
            var _t = new Date(p.value);
            e = _t.getFullYear() + "-" + (_t.getMonth() + 1).toString().padStart(2, "0") + "-" + _t.getDate().toString().padStart(2, "0");
          }
          i("confirm", e), s();
        };
      return o({
        showModal: function showModal(e, t) {
          e && (p.value = e.getTime()), t && (l.value = t), r.value = !0;
        }
      }), function (t, o) {
        return e.e({
          a: e.t(t.title),
          b: "time" === t.type
        }, "time" === t.type ? {
          c: e.o(function (t) {
            return e.isRef(l) ? l.value = t : null;
          }),
          d: e.p({
            type: "time",
            label: "时分",
            modelValue: e.unref(l)
          })
        } : {
          e: e.o(function (t) {
            return e.isRef(p) ? p.value = t : null;
          }),
          f: e.p({
            type: "date",
            label: "年月日",
            minDate: t.minDate,
            maxDate: t.maxDate,
            modelValue: e.unref(p)
          })
        }, {
          g: e.o(m),
          h: e.o(s),
          i: e.o(function (t) {
            return e.isRef(r) ? r.value = t : null;
          }),
          j: e.p({
            "custom-style": "border-top-left-radius: 24rpx;border-top-right-radius: 24rpx",
            position: "bottom",
            modelValue: e.unref(r)
          })
        });
      };
    }
  }),
  o = e._export_sfc(t, [["__scopeId", "data-v-9e097d50"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/components/SetDateModal/index.vue"]]);wx.createComponent(o);