var e = require("../../common/vendor.js");if (!Array) {
  (e.resolveComponent("wd-password-input") + e.resolveComponent("wd-number-keyboard") + e.resolveComponent("wd-popup"))();
}Math || (function () {
  return "../../node-modules/wot-design-uni/components/wd-password-input/wd-password-input.js";
} + function () {
  return "../../node-modules/wot-design-uni/components/wd-number-keyboard/wd-number-keyboard.js";
} + function () {
  return "../../node-modules/wot-design-uni/components/wd-popup/wd-popup.js";
})();var o = e.defineComponent({
    __name: "index",
    emits: ["valueChange", "ok"],
    setup: function setup(o, _ref) {
      var n = _ref.expose,
        u = _ref.emit;
      var r = e.ref(),
        l = u,
        t = e.ref(),
        s = e.ref(""),
        a = e.ref(!1),
        d = e.ref(!1),
        i = function i() {
          d.value = !1, l("valueChange", {
            code: "",
            role: 0
          });
        },
        p = function p() {
          if (!t.value) return void e.index.showToast({
            icon: "none",
            title: "请选择角色"
          });
          if (s.value.length < 6) return void e.index.showToast({
            icon: "none",
            title: "请输入完整的邀请码"
          });
          var o = parseInt(t.value.key, 0);
          l("ok", {
            code: s.value,
            role: o
          }), d.value = !1;
        };
      return n({
        showModal: function showModal(e) {
          s.value = "", r.value = e, t.value = e[0], d.value = !0;
        }
      }), function (o, n) {
        return {
          a: e.f(e.unref(r), function (o, n, u) {
            return e.e({
              a: e.n(e.unref(t) === o && "border-primary"),
              b: o.icon,
              c: e.unref(t) === o
            }, (e.unref(t), {}), {
              d: e.t(o.label),
              e: o.key,
              f: e.o(function (n) {
                return function (o) {
                  if (o === t.value) return;
                  t.value = o, l("valueChange", {
                    code: s.value,
                    role: t.value.key
                  });
                  var n = e.index.createInnerAudioContext();
                  n.src = "/static/audios/selectmember.mp3", n.autoplay = !1, n.stop(), n.play();
                }(o);
              }, o.key)
            });
          }),
          b: e.o(function (e) {
            return a.value = !0;
          }),
          c: e.o(function (o) {
            return e.isRef(s) ? s.value = o : null;
          }),
          d: e.p({
            length: 6,
            mask: !1,
            focused: e.unref(a),
            modelValue: e.unref(s)
          }),
          e: !e.unref(t) || e.unref(s).length < 6 ? "" : "share",
          f: e.o(p),
          g: e.o(function (e) {
            return a.value = !1;
          }),
          h: e.o(function (o) {
            var n;
            return l("valueChange", {
              code: e.unref(s),
              role: null == (n = e.unref(t)) ? void 0 : n.key
            });
          }),
          i: e.o(function (o) {
            return e.isRef(s) ? s.value = o : null;
          }),
          j: e.o(function (o) {
            return e.isRef(a) ? a.value = o : null;
          }),
          k: e.p({
            maxlength: 6,
            modelValue: e.unref(s),
            visible: e.unref(a)
          }),
          l: e.o(i),
          m: e.o(function (o) {
            return e.isRef(d) ? d.value = o : null;
          }),
          n: e.p({
            "custom-style": "border-top-left-radius: 24rpx;border-top-right-radius: 24rpx",
            position: "bottom",
            modelValue: e.unref(d)
          })
        };
      };
    }
  }),
  n = e._export_sfc(o, [["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/components/InviteMemberModal/index.vue"]]);wx.createComponent(n);