var e = require("../../common/vendor.js");if (!Array) {
  e.resolveComponent("wd-popup")();
}Math;var o = e.defineComponent({
    __name: "index",
    props: {
      selectList: {}
    },
    emits: ["ok"],
    setup: function setup(o, _ref) {
      var t = _ref.expose,
        s = _ref.emit;
      var r = e.ref(!1),
        n = s,
        a = function a() {
          r.value = !1;
        };
      return t({
        showModal: function showModal() {
          r.value = !0;
        },
        closeModal: a
      }), function (o, t) {
        return {
          a: e.f(o.selectList, function (o, t, s) {
            return {
              a: o.avatar,
              b: e.t(o.name),
              c: o.id,
              d: e.o(function (e) {
                return function (e) {
                  n("ok", e);
                }(o);
              }, o.id)
            };
          }),
          b: e.o(a),
          c: e.o(a),
          d: e.o(function (o) {
            return e.isRef(r) ? r.value = o : null;
          }),
          e: e.p({
            "custom-style": "border-top-left-radius: 24rpx;border-top-right-radius: 24rpx",
            position: "bottom",
            modelValue: e.unref(r)
          })
        };
      };
    }
  }),
  t = e._export_sfc(o, [["__scopeId", "data-v-abb2b8c3"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/components/SelectModal/index.vue"]]);wx.createComponent(t);