var e = require("../../common/vendor.js");if (!Array) {
  e.resolveComponent("wd-popup")();
}Math;var o = e.defineComponent({
    __name: "index",
    props: {
      title: {}
    },
    emits: ["ok"],
    setup: function setup(o, _ref) {
      var s = _ref.expose,
        t = _ref.emit;
      var r = t,
        n = e.ref(!1),
        a = function a() {
          r("ok", !1), n.value = !1;
        },
        p = function p(e) {
          r("ok", e), n.value = !1;
        },
        l = function l() {
          e.index.navigateTo({
            url: "/pages/clause/clause"
          });
        };
      return s({
        showModal: function showModal() {
          n.value = !0;
        }
      }), function (o, s) {
        return {
          a: e.o(l),
          b: e.o(function (e) {
            return p(!1);
          }),
          c: e.o(function (e) {
            return p(!0);
          }),
          d: e.o(a),
          e: e.o(function (o) {
            return e.isRef(n) ? n.value = o : null;
          }),
          f: e.p({
            "custom-style": "border-top-left-radius: 24rpx;border-top-right-radius: 24rpx",
            position: "bottom",
            modelValue: e.unref(n)
          })
        };
      };
    }
  }),
  s = e._export_sfc(o, [["__scopeId", "data-v-5bdf912c"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/components/ConfirmClauseModal/index.vue"]]);wx.createComponent(s);