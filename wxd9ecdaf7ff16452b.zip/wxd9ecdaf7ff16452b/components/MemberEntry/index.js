var e = require("../../common/vendor.js"),
  a = require("../../common/utils.js"),
  u = e.defineComponent({
    __name: "index",
    props: {
      member: {},
      count: {},
      index: {},
      length: {},
      isSlide: {
        type: Boolean
      }
    },
    emits: ["delete"],
    setup: function setup(u, _ref) {
      var r = _ref.emit;
      var l = u,
        t = r,
        n = e.ref(0),
        v = e.ref(160),
        i = e.ref(.6),
        o = e.ref(0),
        m = e.ref(0),
        d = e.ref(!1),
        s = e.ref(0),
        f = e.ref(160),
        c = e.ref(0),
        b = e.ref(!1),
        x = function x(e) {
          if (c.value = e, b.value) return;
          b.value = !0;
          var a = function a() {
            if (!b.value) return;
            var e = 0;
            e = c.value < 0 ? Math.max(c.value, n.value - 3) : Math.min(c.value, n.value + 3), n.value = e, n.value === c.value ? b.value = !1 : setTimeout(a, 5);
          };
          a();
        },
        p = function p(e, a) {
          if (!l.isSlide) return;
          if (a) return void (e <= -i.value ? (s.value = -1, x(-v.value)) : (x(0), s.value = 0));
          if (s.value === e) return;
          s.value = e;
          var u = e * v.value,
            r = o.value + u;
          r <= -v.value ? n.value = -v.value : n.value = r >= 0 ? 0 : r;
        },
        h = function h(a) {
          m.value = a.touches[0].clientX, o.value = n.value, d.value = !0, b.value = !1, e.index.$emit("hideMember", {
            id: l.member.id
          });
        },
        _ = function _(e) {
          if (!d.value) return;
          var a = e.touches[0].clientX,
            u = g(a);
          p(u, !1);
        },
        M = function M(e) {
          var a = e.changedTouches[0].clientX;
          var u = g(a);
          a === m.value && (u = o.value === -v.value ? -1 : 0), p(u, !0), d.value = !1;
        },
        g = function g(e) {
          if (!d.value) return 0;
          var a = e >= m.value ? 1 : -1;
          return e * m.value >= 0 ? a *= Math.abs(e - m.value) : a *= Math.abs(e) + Math.abs(m.value), a <= -f.value ? -1 : a >= f.value ? 1 : a / f.value;
        },
        $ = function $() {
          l.isSlide && (t("delete", {
            id: l.member.id
          }), p(1, !0));
        },
        w = function w(e) {
          e.id !== l.member.id && 0 !== s.value && p(0, !0);
        },
        X = function X() {
          e.index.navigateTo({
            url: "/pages/member/member?memberId=".concat(l.member.id)
          });
        };
      return e.onMounted(function () {
        e.index.$on("hideMember", w);
      }), e.onUnmounted(function () {
        e.index.$off("hideMember", w);
      }), function (u, r) {
        return e.e({
          a: e.unref(a.getAvatar)(u.member.avatar),
          b: e.t(u.member.name),
          c: e.t(u.count),
          d: e.o(X),
          e: e.unref(n) < 0
        }, e.unref(n) < 0 ? {
          f: 0 === u.index ? "24rpx" : "0rpx",
          g: e.o($)
        } : {}, {
          h: "translateX(".concat(e.unref(n), "rpx)"),
          i: e.n(0 === u.index ? "rounded-t-_a_24rpx_a_" : ""),
          j: e.o(h),
          k: e.o(_),
          l: e.o(M)
        });
      };
    }
  }),
  r = e._export_sfc(u, [["__scopeId", "data-v-8a1dad9b"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/components/MemberEntry/index.vue"]]);wx.createComponent(r);