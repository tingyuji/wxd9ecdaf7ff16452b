var e = require("../../common/vendor.js"),
  o = require("../../common/utils.js");if (!Array) {
  e.resolveComponent("wd-popup")();
}Math;var t = e.defineComponent({
    __name: "index",
    props: {
      inputStr: {},
      memberList: {},
      title: {},
      isShowInput: {
        type: Boolean
      }
    },
    emits: ["ok"],
    setup: function setup(t, _ref) {
      var n = _ref.expose,
        r = _ref.emit;
      var s = t,
        i = e.ref(),
        u = e.ref(),
        l = r,
        a = e.ref(!1),
        p = function p() {
          a.value = !1;
        },
        c = function c() {
          (function () {
            if (!s.isShowInput) return !0;
            if (!u.value) return e.index.showToast({
              icon: "none",
              title: "请输入名字"
            }), !1;
            var _o$checkStr = o.checkStr(u.value),
              t = _o$checkStr.numberCount,
              n = _o$checkStr.spaceCount,
              r = _o$checkStr.chineseCount,
              i = _o$checkStr.englishCount,
              l = _o$checkStr.otherCount;
            return t > 0 ? (e.index.showToast({
              icon: "none",
              title: "名字中不能有数字"
            }), !1) : n > 0 ? (e.index.showToast({
              icon: "none",
              title: "名字中不能有空格"
            }), !1) : l > 0 ? (e.index.showToast({
              icon: "none",
              title: "名字中不能有特殊字符"
            }), !1) : !(2 * r + i > 30 && (e.index.showToast({
              icon: "none",
              title: "名字过长"
            }), 1));
          })() && l("ok", {
            inputValue: u.value,
            currentSelect: i.value
          });
        };
      return n({
        showModal: function showModal() {
          u.value = s.inputStr, a.value = !0;
        },
        handleCloseAddMember: p
      }), function (o, t) {
        return e.e({
          a: e.t(o.title),
          b: o.isShowInput
        }, o.isShowInput ? {
          c: e.unref(u),
          d: e.o(function (o) {
            return e.isRef(u) ? u.value = o.detail.value : null;
          })
        } : {}, {
          e: e.f(o.memberList, function (o, t, n) {
            return e.e({
              a: e.n(e.unref(i) === o && "border-primary"),
              b: o.icon,
              c: e.unref(i) === o
            }, (e.unref(i), {}), {
              d: e.t(o.label),
              e: o.key,
              f: e.o(function (t) {
                return function (o) {
                  i.value = o;
                  var t = e.index.createInnerAudioContext();
                  t.src = "/static/audios/selectmember.mp3", t.autoplay = !1, t.stop(), t.play();
                }(o);
              }, o.key)
            });
          }),
          f: e.o(c),
          g: e.o(p),
          h: e.o(function (o) {
            return e.isRef(a) ? a.value = o : null;
          }),
          i: e.p({
            "custom-style": "border-top-left-radius: 24rpx;border-top-right-radius: 24rpx",
            position: "bottom",
            modelValue: e.unref(a)
          })
        });
      };
    }
  }),
  n = e._export_sfc(t, [["__scopeId", "data-v-52bbea43"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/components/AddMemberModal/index.vue"]]);wx.createComponent(n);