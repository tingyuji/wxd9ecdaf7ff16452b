var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var e = require("../../common/vendor.js"),
  t = e.defineComponent({
    __name: "index",
    props: {
      task: {},
      member: {}
    },
    emits: ["click"],
    setup: function setup(t, _ref) {
      var _this = this;
      var n = _ref.emit;
      var s = t,
        o = n,
        a = function a() {
          return e = _this, t = null, n = /*#__PURE__*/_regeneratorRuntime2().mark(function n() {
            return _regeneratorRuntime2().wrap(function n$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  o("click", {
                    task: s.task
                  });
                case 1:
                case "end":
                  return _context.stop();
              }
            }, n);
          }), new Promise(function (s, o) {
            var a = function a(e) {
                try {
                  r(n.next(e));
                } catch (t) {
                  o(t);
                }
              },
              c = function c(e) {
                try {
                  r(n.throw(e));
                } catch (t) {
                  o(t);
                }
              },
              r = function r(e) {
                return e.done ? s(e.value) : Promise.resolve(e.value).then(a, c);
              };
            r((n = n.apply(e, t)).next());
          });
          var e, t, n;
        };
      return function (t, n) {
        return e.e({
          a: 1 === t.task.finish
        }, (t.task.finish, {}), {
          b: e.o(a),
          c: e.t(t.task.content),
          d: e.t(t.task.time),
          e: e.t(t.task.flowerCount),
          f: e.n(1 === t.task.finish ? "opacity-30" : "opacity-100")
        });
      };
    }
  }),
  n = e._export_sfc(t, [["__scopeId", "data-v-a7b6f7e1"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/components/InstanceTaskEntry/index.vue"]]);wx.createComponent(n);