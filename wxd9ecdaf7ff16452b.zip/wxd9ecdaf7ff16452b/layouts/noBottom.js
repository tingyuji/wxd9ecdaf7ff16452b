var o = require("../common/vendor.js");if (!Array) {
  o.resolveComponent("wd-toast")();
}Math || (function () {
  return "../node-modules/wot-design-uni/components/wd-toast/wd-toast.js";
} + e)();var e = function e() {
    return "../components/TabBar/tabbar.js";
  },
  t = o.defineComponent({
    __name: "noBottom",
    setup: function setup(o) {
      return function (o, e) {
        return {};
      };
    }
  }),
  s = o._export_sfc(t, [["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/layouts/noBottom.vue"]]);wx.createComponent(s);