var e = require("../common/vendor.js"),
  o = {};if (!Array) {
  (e.resolveComponent("wd-toast") + e.resolveComponent("wd-message-box"))();
}Math || (function () {
  return "../node-modules/wot-design-uni/components/wd-toast/wd-toast.js";
} + function () {
  return "../node-modules/wot-design-uni/components/wd-message-box/wd-message-box.js";
})();var s = e._export_sfc(o, [["render", function (e, o) {
  return {};
}], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/layouts/noBar.vue"]]);wx.createComponent(s);