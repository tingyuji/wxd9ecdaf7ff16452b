var e = require("../common/vendor.js");if (!Array) {
  (e.resolveComponent("wd-toast") + e.resolveComponent("wd-message-box"))();
}Math || (function () {
  return "../node-modules/wot-design-uni/components/wd-toast/wd-toast.js";
} + function () {
  return "../node-modules/wot-design-uni/components/wd-message-box/wd-message-box.js";
} + o)();var o = function o() {
    return "../components/TabBar/tabbar.js";
  },
  s = e.defineComponent({
    __name: "default",
    setup: function setup(e) {
      return function (e, o) {
        return {};
      };
    }
  }),
  t = e._export_sfc(s, [["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/src/layouts/default.vue"]]);wx.createComponent(t);