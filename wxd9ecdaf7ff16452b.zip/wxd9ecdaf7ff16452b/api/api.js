var t = require("../utils/http.js");exports.apiAddFamilyMember = function (e, a, i) {
  return t.http({
    url: "/add_family_member",
    method: "POST",
    data: {
      name: e,
      avatar: a,
      role: i
    }
  });
}, exports.apiAddFlowerLog = function (e) {
  return t.http({
    url: "/add_flowers_log",
    method: "POST",
    data: e
  });
}, exports.apiAddTaskTemplate = function (e) {
  return t.http({
    url: "/add_task_template",
    method: "POST",
    data: e
  });
}, exports.apiCheckInvitation = function (e) {
  return t.http({
    url: "/check_invitation",
    method: "POST",
    data: {
      id: e
    }
  });
}, exports.apiCreateFamily = function (e, a, i) {
  return t.http({
    url: "/create_family",
    method: "POST",
    data: {
      familyName: e,
      memberName: a,
      role: i
    }
  });
}, exports.apiCreateInvitation = function (e, a) {
  return t.http({
    url: "/create_invitation",
    method: "POST",
    data: {
      inviteeRole: e,
      code: a
    }
  });
}, exports.apiDelFamilyMember = function (e) {
  return t.http({
    url: "/del_family_member",
    method: "POST",
    data: {
      id: e
    }
  });
}, exports.apiDelFlowerLog = function (e) {
  return t.http({
    url: "/del_flowers_log",
    method: "POST",
    data: {
      id: e
    }
  });
}, exports.apiDelTaskTemplate = function (e) {
  return t.http({
    url: "/del_task_template",
    method: "POST",
    data: {
      id: e
    }
  });
}, exports.apiFinishTask = function (e) {
  return t.http({
    url: "/finish_task",
    method: "POST",
    data: {
      instanceId: e
    }
  });
}, exports.apiGetEventSettings = function (e, a) {
  return t.http({
    url: "/get_event_settings",
    method: "POST",
    data: {
      key: e,
      memberId: a
    }
  });
}, exports.apiGetFamily = function () {
  return t.http({
    url: "/get_family",
    method: "POST",
    data: {}
  });
}, exports.apiGetFamilyMember = function (e) {
  return t.http({
    url: "/get_family_member",
    method: "POST",
    data: {
      id: e
    }
  });
}, exports.apiGetFamilyMemberList = function () {
  return t.http({
    url: "/get_family_member_list",
    method: "POST",
    data: {}
  });
}, exports.apiGetFamilyRoleList = function (e) {
  return t.http({
    url: "/get_family_role_list",
    method: "POST",
    data: {
      roleType: e
    }
  });
}, exports.apiGetFlowerLog = function (e) {
  return t.http({
    url: "/get_flowers_log",
    method: "POST",
    data: {
      id: e
    }
  });
}, exports.apiGetFlowersSetting = function () {
  return t.http({
    url: "/get_flowers_setting",
    method: "POST",
    data: {}
  });
}, exports.apiGetInvitation = function (e) {
  return t.http({
    url: "/get_invitation",
    method: "POST",
    data: {
      id: e
    }
  });
}, exports.apiGetMemberBySelf = function () {
  return t.http({
    url: "/get_member_by_self",
    method: "POST",
    data: {}
  });
}, exports.apiGetTaskInstanceList = function (e) {
  return t.http({
    url: "/get_task_instance_list",
    method: "POST",
    data: {
      memberId: e
    }
  });
}, exports.apiGetTaskTemplate = function (e) {
  return t.http({
    url: "/get_task_template_by_id",
    method: "POST",
    data: {
      id: e
    }
  });
}, exports.apiGetTaskTemplateList = function () {
  return t.http({
    url: "/get_task_template_list",
    method: "POST",
    data: {}
  });
}, exports.apiJoinFamily = function (e, a) {
  return t.http({
    url: "/join_family",
    method: "POST",
    data: {
      invitationId: e,
      code: a
    }
  });
}, exports.apiLogin = function (e) {
  return t.http({
    url: "/auth_v2/auth_by_wechat_mp",
    method: "POST",
    data: e
  });
}, exports.apiLoginFlowers = function (e) {
  return t.http({
    url: "/login",
    method: "POST",
    data: {
      inviter: e
    }
  });
}, exports.apiObtainFlowers = function (e) {
  return t.http({
    url: "/obtain_flowers",
    method: "POST",
    data: {
      memberId: e
    }
  });
}, exports.apiResetTask = function (e) {
  return t.http({
    url: "/reset_task",
    method: "POST",
    data: {
      instanceId: e
    }
  });
}, exports.apiSetFamilyInfo = function (e) {
  return t.http({
    url: "/set_family_info",
    method: "POST",
    data: {
      name: e
    }
  });
}, exports.apiSetFlowerLog = function (e, a) {
  return t.http({
    url: "/set_flowers_log",
    method: "POST",
    data: {
      id: e,
      event: a
    }
  });
}, exports.apiSetMemberBirthday = function (e, a) {
  return t.http({
    url: "/set_member_birthday",
    method: "POST",
    data: {
      id: e,
      birthday: a
    }
  });
}, exports.apiSetMemberName = function (e, a) {
  return t.http({
    url: "/set_member_name",
    method: "POST",
    data: {
      id: e,
      name: a
    }
  });
}, exports.apiSetTaskTemplateInfo = function (e) {
  return t.http({
    url: "/set_task_template_info",
    method: "POST",
    data: e
  });
};