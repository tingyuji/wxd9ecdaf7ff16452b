var _regeneratorRuntime2 = require("../@babel/runtime/helpers/regeneratorRuntime");var _createForOfIteratorHelper2 = require("../@babel/runtime/helpers/createForOfIteratorHelper");var t = require("./vendor.js"),
  e = require("./assets.js"),
  n = require("../api/api.js");exports.checkStr = function (t) {
  var e = 0,
    n = 0,
    r = 0,
    o = 0,
    a = 0;
  var _iterator = _createForOfIteratorHelper2(t),
    _step;
  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var i = _step.value;
      /\d/.test(i) ? e++ : /\s/.test(i) ? n++ : /[\u4e00-\u9fa5]/.test(i) ? r++ : /[a-zA-Z]/.test(i) ? o++ : a++;
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }
  return {
    numberCount: e,
    spaceCount: n,
    chineseCount: r,
    englishCount: o,
    otherCount: a
  };
}, exports.formatTime = function (t) {
  var e = new Date(t),
    n = new Date().getFullYear(),
    r = e.getFullYear(),
    o = e.getMonth() + 1,
    a = e.getDate(),
    i = e.getHours(),
    s = e.getMinutes();
  var g;
  return g = r === n ? "".concat(o.toString().padStart(2, "0"), "/").concat(a.toString().padStart(2, "0"), " ").concat(i.toString().padStart(2, "0"), ":").concat(s.toString().padStart(2, "0")) : "".concat(r, "/").concat(o.toString().padStart(2, "0"), "/").concat(a.toString().padStart(2, "0"), " ").concat(i.toString().padStart(2, "0"), ":").concat(s.toString().padStart(2, "0")), g;
}, exports.getAvatar = function (t) {
  switch (t) {
    case "mother_icon.png":
      return e.motherIcon;
    case "father_icon.png":
    default:
      return e.fatherIcon;
    case "boy_icon.png":
      return e.boyIcon;
    case "girl_icon.png":
      return e.girlIcon;
  }
}, exports.getDateInfo = function (t) {
  var e = new Date(t),
    n = e.getFullYear(),
    r = e.getMonth() + 1,
    o = e.getDate(),
    a = new Date(n, e.getMonth() + 1, 0),
    i = a.getDay();
  if (i > 0 && o >= a.getDate() - i) {
    var _t = new Date(n, e.getMonth() + 1, 1);
    return {
      year: _t.getFullYear(),
      month: _t.getMonth() + 1,
      week: 1
    };
  }
  var s = new Date(n, e.getMonth(), 1).getDay();
  0 === s && (s = 7);
  return {
    year: n,
    month: r,
    week: Math.ceil((o + s - 1) / 7)
  };
}, exports.openJoin = function (e, r) {
  return o = exports, a = null, i = /*#__PURE__*/_regeneratorRuntime2().mark(function i() {
    var o;
    return _regeneratorRuntime2().wrap(function i$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          if (!("" === e)) {
            _context.next = 2;
            break;
          }
          return _context.abrupt("return", !1);
        case 2:
          _context.t0 = !1;
          _context.next = 5;
          return n.apiCheckInvitation(e);
        case 5:
          _context.t1 = _context.sent.data;
          if (!(_context.t0 === _context.t1)) {
            _context.next = 8;
            break;
          }
          return _context.abrupt("return", (t.index.showToast({
            icon: "none",
            title: "邀请已失效"
          }), !1));
        case 8:
          _context.next = 10;
          return n.apiGetInvitation(e);
        case 10:
          o = _context.sent;
          return _context.abrupt("return", r === o.data.family ? (t.index.showToast({
            icon: "none",
            title: "您已在该家庭中"
          }), !1) : (t.index.navigateTo({
            url: "/pages/join/join?invitationId=".concat(e)
          }), !0));
        case 12:
        case "end":
          return _context.stop();
      }
    }, i);
  }), new Promise(function (t, e) {
    var n = function n(t) {
        try {
          s(i.next(t));
        } catch (n) {
          e(n);
        }
      },
      r = function r(t) {
        try {
          s(i.throw(t));
        } catch (n) {
          e(n);
        }
      },
      s = function s(e) {
        return e.done ? t(e.value) : Promise.resolve(e.value).then(n, r);
      };
    s((i = i.apply(o, a)).next());
  });
  var o, a, i;
};