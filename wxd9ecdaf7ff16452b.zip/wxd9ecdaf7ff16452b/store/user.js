var e = require("../common/vendor.js"),
  s = e.defineStore("user", function () {
    var s = e.ref(),
      r = e.ref(),
      o = e.ref();
    return {
      accessToken: s,
      setAccessToken: function setAccessToken(e) {
        s.value = e;
      },
      isAccessTokenValid: function isAccessTokenValid() {
        return !!s.value && "" !== s.value;
      },
      currentFamily: o,
      setCurrentFamily: function setCurrentFamily(e) {
        o.value = e;
      },
      envVersion: r,
      setEnvVersion: function setEnvVersion(e) {
        r.value = e;
      }
    };
  }, {
    persist: {
      key: "user-storage",
      storage: localStorage,
      paths: ["accessToken"]
    }
  });exports.useUserStore = s;