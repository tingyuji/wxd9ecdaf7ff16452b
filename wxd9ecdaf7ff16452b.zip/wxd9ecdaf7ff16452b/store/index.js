var e = require("../common/vendor.js");require("./tabbar.js"), require("./user.js");var t = e.createPinia();t.use(e.createPersistedState({
  storage: {
    getItem: e.index.getStorageSync,
    setItem: e.index.setStorageSync
  }
})), exports.store = t;