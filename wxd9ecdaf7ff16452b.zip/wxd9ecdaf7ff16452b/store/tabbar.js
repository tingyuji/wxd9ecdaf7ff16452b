var e = require("../common/vendor.js"),
  r = e.defineStore("tabbar", function () {
    var r = e.ref("home");
    return {
      currentTab: r,
      setCurrentTab: function setCurrentTab(e) {
        r.value = e;
      }
    };
  }, {
    persist: !0
  });exports.useTabbarStore = r;