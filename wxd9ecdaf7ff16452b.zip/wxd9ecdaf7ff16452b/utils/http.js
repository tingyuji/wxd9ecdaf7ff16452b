var _createForOfIteratorHelper2 = require("../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  t = Object.defineProperties,
  r = Object.getOwnPropertyDescriptors,
  o = Object.getOwnPropertySymbols,
  s = Object.prototype.hasOwnProperty,
  n = Object.prototype.propertyIsEnumerable,
  a = function a(t, r, o) {
    return r in t ? e(t, r, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: o
    }) : t[r] = o;
  };var i = require("../common/vendor.js");require("../store/index.js");var l = require("../store/user.js"),
  u = function u() {
    var e = getCurrentPages();
    "pages/login/login" !== e[e.length - 1].route && i.index.navigateTo({
      url: "/pages/login/login"
    });
  };exports.http = function (e) {
  var _l$useUserStore = l.useUserStore(),
    c = _l$useUserStore.accessToken,
    d = _l$useUserStore.setAccessToken,
    p = _l$useUserStore.envVersion;
  return e.url && "/auth_v2/auth_by_wechat_mp" !== e.url && (e.url = "release" === p ? "/flowers-server" + e.url : "/flowers-server-test" + e.url), new Promise(function (l, c) {
    var p;
    i.index.request((p = function (e, t) {
      for (var r in t || (t = {})) s.call(t, r) && a(e, r, t[r]);
      if (o) {
        var _iterator = _createForOfIteratorHelper2(o(t)),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var r = _step.value;
            n.call(t, r) && a(e, r, t[r]);
          }
        } catch (err) {
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
      }
      return e;
    }({}, e), t(p, r({
      dataType: "json",
      success: function success(e) {
        if (e.statusCode >= 200 && e.statusCode < 300) {
          if ("ok" === e.data.result) return void l(e.data);
          if ("ERR_TOKEN_INVALID" === e.data.result) return i.index.showToast({
            icon: "none",
            title: "授权已失效，请重新授权"
          }), d(""), void u();
          i.index.showToast({
            icon: "none",
            title: e.data.data
          }), l(e.data);
        } else 401 === e.statusCode ? (d(""), u(), c(e)) : (i.index.showToast({
          icon: "none",
          title: "请求错误"
        }), c(e));
      },
      fail: function fail(e) {
        i.index.showToast({
          icon: "none",
          title: "网络错误，换个网络试试"
        }), d(""), u(), c(e);
      }
    }))));
  });
};