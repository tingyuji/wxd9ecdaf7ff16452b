var _toConsumableArray2 = require("../@babel/runtime/helpers/toConsumableArray");var _createForOfIteratorHelper2 = require("../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  t = Object.defineProperties,
  a = Object.getOwnPropertyDescriptors,
  i = Object.getOwnPropertySymbols,
  o = Object.prototype.hasOwnProperty,
  n = Object.prototype.propertyIsEnumerable,
  r = function r(t, a, i) {
    return a in t ? e(t, a, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: i
    }) : t[a] = i;
  },
  p = function p(e, t) {
    for (var a in t || (t = {})) o.call(t, a) && r(e, a, t[a]);
    if (i) {
      var _iterator = _createForOfIteratorHelper2(i(t)),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var a = _step.value;
          n.call(t, a) && r(e, a, t[a]);
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
    return e;
  },
  l = function l(e, i) {
    return t(e, a(i));
  };var s = [{
    path: "pages/index/index",
    type: "home",
    layout: "default",
    style: {
      navigationStyle: "custom",
      navigationBarTitleText: "首页"
    }
  }, {
    path: "pages/activity/activity",
    type: "page",
    layout: "noBar",
    style: {
      navigationBarTitleText: "领取小红花"
    }
  }, {
    path: "pages/clause/clause",
    type: "page",
    layout: "noBar",
    style: {
      navigationBarTitleText: "用户协议及隐私条款"
    }
  }, {
    path: "pages/editFamily/editFamily",
    type: "page",
    layout: "noBar",
    style: {
      navigationBarTitleText: "编辑家庭名称"
    }
  }, {
    path: "pages/editFlower/index",
    type: "page",
    layout: "noBar",
    style: {
      navigationBarTitleText: "记一笔"
    }
  }, {
    path: "pages/editName/editName",
    type: "page",
    layout: "noBar",
    style: {
      navigationBarTitleText: "编辑成员名称"
    }
  }, {
    path: "pages/editTask/editTask",
    type: "page",
    layout: "noBar",
    style: {
      navigationBarTitleText: "添加任务"
    }
  }, {
    path: "pages/editTaskList/editTaskList",
    type: "page",
    layout: "noBar",
    style: {
      navigationBarTitleText: "编辑任务"
    }
  }, {
    path: "pages/join/join",
    type: "page",
    layout: "noBar",
    style: {
      navigationBarTitleText: "小红花"
    }
  }, {
    path: "pages/login/login",
    type: "page",
    layout: "noBar",
    style: {
      navigationBarTitleText: "小红花"
    }
  }, {
    path: "pages/member/member",
    type: "page",
    layout: "noBar",
    style: {
      navigationBarTitleText: "个人信息"
    }
  }, {
    path: "pages/record/record",
    type: "page",
    layout: "noBar",
    style: {
      navigationBarTitleText: "成长记录"
    }
  }, {
    path: "pages/user/user",
    type: "page",
    layout: "default",
    style: {
      navigationBarTitleText: "个人中心",
      navigationStyle: "custom"
    }
  }],
  g = [],
  y = function y() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "needLogin";
    var t = _toConsumableArray2(s.filter(function (t) {
        return !e || t[e];
      }).map(function (e) {
        return l(p({}, e), {
          path: "/".concat(e.path)
        });
      })),
      a = [];
    g.forEach(function (t) {
      var i = t.root;
      Array.isArray(t.pages) && t.pages.filter(function (t) {
        return !e || t[e];
      }).forEach(function (e) {
        a.push(l(p({}, e), {
          path: "/".concat(i, "/").concat(e.path)
        }));
      });
    });
    var i = [].concat(_toConsumableArray2(t), a);
    return console.log("getAllPages by ".concat(e, " result: "), i), i;
  };y("needLogin").map(function (e) {
  return e.path;
}), exports.debounce = function (e) {
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 600;
  var a = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : !0;
  var i = null;
  return function () {
    for (var _len = arguments.length, o = new Array(_len), _key = 0; _key < _len; _key++) {
      o[_key] = arguments[_key];
    }
    var n = a && !i;
    null !== i && clearTimeout(i), i = setTimeout(function () {
      i = null, a || e.apply(void 0, o);
    }, t), n && e.apply(void 0, o);
  };
}, exports.getNeedLoginPages = function () {
  return y("needLogin").map(function (e) {
    return e.path;
  });
};