var t = require("../common/vendor.js");exports.sign = function (r, s) {
  var n = Object.keys(r).sort().filter(function (t) {
    return void 0 !== r[t] && "" !== r[t];
  }).map(function (t) {
    return "".concat(t, "=").concat(JSON.stringify(r[t]));
  }).join("&");
  return t.Md5.hashStr(n + s);
};