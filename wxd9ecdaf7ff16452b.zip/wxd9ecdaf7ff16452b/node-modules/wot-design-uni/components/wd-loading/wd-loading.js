var _createForOfIteratorHelper2 = require("../../../../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  t = Object.defineProperties,
  o = Object.getOwnPropertyDescriptors,
  s = Object.getOwnPropertySymbols,
  r = Object.prototype.hasOwnProperty,
  n = Object.prototype.propertyIsEnumerable,
  a = function a(t, o, s) {
    return o in t ? e(t, o, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: s
    }) : t[o] = s;
  };var i = require("../../../../common/vendor.js"),
  l = i.defineComponent((c = function (e, t) {
    for (var o in t || (t = {})) r.call(t, o) && a(e, o, t[o]);
    if (s) {
      var _iterator = _createForOfIteratorHelper2(s(t)),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var o = _step.value;
          n.call(t, o) && a(e, o, t[o]);
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
    return e;
  }({}, {
    name: "wd-loading",
    options: {
      virtualHost: !0,
      addGlobalClass: !0,
      styleIsolation: "shared"
    }
  }), p = {
    props: i.loadingProps,
    setup: function setup(e) {
      var t = i.context.id++,
        o = i.context.id++,
        s = i.context.id++,
        r = {
          outline: function outline() {
            var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "#4D80F0";
            return "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 42 42\"><defs><linearGradient x1=\"100%\" y1=\"0%\" x2=\"0%\" y2=\"0%\" id=\"".concat(t, "\"><stop stop-color=\"#FFF\" offset=\"0%\" stop-opacity=\"0\"/><stop stop-color=\"#FFF\" offset=\"100%\"/></linearGradient></defs><g fill=\"none\" fill-rule=\"evenodd\"><path d=\"M21 1c11.046 0 20 8.954 20 20s-8.954 20-20 20S1 32.046 1 21 9.954 1 21 1zm0 7C13.82 8 8 13.82 8 21s5.82 13 13 13 13-5.82 13-13S28.18 8 21 8z\" fill=\"").concat(e, "\"/><path d=\"M4.599 21c0 9.044 7.332 16.376 16.376 16.376 9.045 0 16.376-7.332 16.376-16.376\" stroke=\"url(#").concat(t, ") \" stroke-width=\"3.5\" stroke-linecap=\"round\"/></g></svg>");
          },
          ring: function ring() {
            var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "#4D80F0";
            var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "#a6bff7";
            return "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 200 200\"><linearGradient id=\"".concat(o, "\" gradientUnits=\"userSpaceOnUse\" x1=\"50\" x2=\"50\" y2=\"180\"><stop offset=\"0\" stop-color=\"").concat(e, "\"></stop> <stop offset=\"1\" stop-color=\"").concat(t, "\"></stop></linearGradient> <path fill=\"url(#").concat(o, ")\" d=\"M20 100c0-44.1 35.9-80 80-80V0C44.8 0 0 44.8 0 100s44.8 100 100 100v-20c-44.1 0-80-35.9-80-80z\"></path> <linearGradient id=\"").concat(s, "\" gradientUnits=\"userSpaceOnUse\" x1=\"150\" y1=\"20\" x2=\"150\" y2=\"180\"><stop offset=\"0\" stop-color=\"#fff\" stop-opacity=\"0\"></stop> <stop offset=\"1\" stop-color=\"").concat(t, "\"></stop></linearGradient> <path fill=\"url(#").concat(s, ")\" d=\"M100 0v20c44.1 0 80 35.9 80 80s-35.9 80-80 80v20c55.2 0 100-44.8 100-100S155.2 0 100 0z\"></path> <circle cx=\"100\" cy=\"10\" r=\"10\" fill=\"").concat(e, "\"></circle></svg>");
          }
        },
        n = e,
        a = i.ref(""),
        l = i.ref(""),
        c = i.ref("32px");
      i.watch(function () {
        return n.size;
      }, function (e) {
        c.value = i.addUnit(e);
      }, {
        deep: !0,
        immediate: !0
      }), i.watch(function () {
        return n.type;
      }, function () {
        f();
      }, {
        deep: !0,
        immediate: !0
      });
      var p = i.computed(function () {
          var e = {
            width: c.value,
            height: c.value
          };
          return "".concat(i.objToStyle(e), "; ").concat(n.customStyle);
        }),
        d = i.computed(function () {
          return "wd-loading  ".concat(n.customClass);
        });
      function f() {
        var e = n.type,
          t = n.color;
        var o = i.isDef(e) ? e : "ring";
        var s = "\"data:image/svg+xml;base64,".concat(i.encode("ring" === o ? r[o](t, l.value) : r[o](t)), "\"");
        a.value = s;
      }
      return i.onBeforeMount(function () {
        l.value = i.gradient(n.color, "#ffffff", 2)[1], f();
      }), function (e, t) {
        return {
          a: i.s("background-image: url(".concat(a.value, ");")),
          b: i.n(d.value),
          c: i.s(p.value)
        };
      };
    }
  }, t(c, o(p))));var c, p;var d = i._export_sfc(l, [["__scopeId", "data-v-eccc123e"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/node_modules/wot-design-uni/components/wd-loading/wd-loading.vue"]]);wx.createComponent(d);