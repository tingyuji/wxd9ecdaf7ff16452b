var _createForOfIteratorHelper2 = require("../../../../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  o = Object.defineProperties,
  t = Object.getOwnPropertyDescriptors,
  a = Object.getOwnPropertySymbols,
  l = Object.prototype.hasOwnProperty,
  n = Object.prototype.propertyIsEnumerable,
  s = function s(o, t, a) {
    return t in o ? e(o, t, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: a
    }) : o[t] = a;
  };var i = require("../../../../common/vendor.js");if (!Array) {
  (i.resolveComponent("wd-overlay") + i.resolveComponent("wd-loading") + i.resolveComponent("wd-transition"))();
}Math || (function () {
  return "../wd-overlay/wd-overlay.js";
} + function () {
  return "../wd-loading/wd-loading.js";
} + function () {
  return "../wd-transition/wd-transition.js";
})();var u = i.defineComponent((r = function (e, o) {
  for (var t in o || (o = {})) l.call(o, t) && s(e, t, o[t]);
  if (a) {
    var _iterator = _createForOfIteratorHelper2(a(o)),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var t = _step.value;
        n.call(o, t) && s(e, t, o[t]);
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
  }
  return e;
}({}, {
  name: "wd-toast",
  options: {
    addGlobalClass: !0,
    virtualHost: !0,
    styleIsolation: "shared"
  }
}), c = {
  props: i.toastProps,
  setup: function setup(e) {
    var o = e,
      t = i.ref(""),
      a = i.ref(!1),
      l = i.ref(""),
      n = i.ref("middle"),
      s = i.ref(!1),
      u = i.ref(100),
      r = i.ref("outline"),
      c = i.ref("#4D80F0"),
      v = i.ref(42),
      d = i.ref(""),
      p = i.ref(!1);
    var f = null,
      m = null;
    var w = o.selector ? i.toastDefaultOptionKey + o.selector : i.toastDefaultOptionKey,
      g = i.inject(w, i.ref(i.defaultOptions));
    i.watch(function () {
      return g.value;
    }, function (e) {
      var o;
      (o = e) && (s.value = !!i.isDef(o.show) && o.show, s.value && (t.value = i.isDef(o.iconName) ? o.iconName : "", a.value = !!i.isDef(o.customIcon) && o.customIcon, l.value = i.isDef(o.msg) ? o.msg : "", n.value = i.isDef(o.position) ? o.position : "middle", u.value = i.isDef(o.zIndex) ? o.zIndex : 100, r.value = i.isDef(o.loadingType) ? o.loadingType : "outline", c.value = i.isDef(o.loadingColor) ? o.loadingColor : "#4D80F0", v.value = i.isDef(o.iconSize) ? o.iconSize : 42, p.value = !!i.isDef(o.cover) && o.cover, m = i.isFunction(o.closed) ? o.closed : null, f = i.isFunction(o.opened) ? o.opened : null));
    }, {
      deep: !0,
      immediate: !0
    }), i.watch(function () {
      return t.value;
    }, function () {
      j();
    }, {
      deep: !0,
      immediate: !0
    });
    var y = i.computed(function () {
        var e = {
          "z-index": u.value,
          position: "fixed",
          top: "50%",
          left: 0,
          width: "100%",
          transform: "translate(0, -50%)",
          "text-align": "center"
        };
        return i.objToStyle(e);
      }),
      b = i.computed(function () {
        return i.objToStyle({
          display: "inline-block",
          "margin-right": "16px"
        });
      }),
      h = i.computed(function () {
        return "wd-toast ".concat(o.customClass, " wd-toast--").concat(n.value, " ").concat("loading" === t.value && !l.value || !t.value && !a.value ? "" : "wd-toast--with-icon", " ").concat("loading" !== t.value || l.value ? "" : "wd-toast--loading");
      });
    function D() {
      i.isFunction(f) && f();
    }
    function x() {
      i.isFunction(m) && m();
    }
    function j() {
      if ("success" !== t.value && "warning" !== t.value && "info" !== t.value && "error" !== t.value) return;
      var e = i.toastIcon[t.value](),
        o = "\"data:image/svg+xml;base64,".concat(i.encode(e), "\"");
      d.value = o;
    }
    return i.onBeforeMount(function () {
      j();
    }), function (e, o) {
      return i.e({
        a: p.value
      }, p.value ? {
        b: i.p({
          "z-index": u.value,
          "lock-scroll": !0,
          show: s.value,
          "custom-style": "background-color: transparent;pointer-events: auto;"
        })
      } : {}, {
        c: "loading" === t.value
      }, "loading" === t.value ? {
        d: i.p({
          type: r.value,
          color: c.value,
          "custom-class": "wd-toast__icon",
          customStyle: b.value
        })
      } : "success" === t.value || "warning" === t.value || "info" === t.value || "error" === t.value ? {
        f: i.s("background-image: url(".concat(d.value, "); width:").concat(v.value, "px; height:").concat(v.value, "px")),
        g: i.s("width:".concat(v.value, "px; height:").concat(v.value, "px"))
      } : (a.value, {}), {
        e: "success" === t.value || "warning" === t.value || "info" === t.value || "error" === t.value,
        h: a.value,
        i: l.value
      }, l.value ? {
        j: i.t(l.value)
      } : {}, {
        k: i.n(h.value),
        l: i.o(D),
        m: i.o(x),
        n: i.p({
          name: "fade",
          show: s.value,
          "custom-style": y.value
        })
      });
    };
  }
}, o(r, t(c))));var r, c;var v = i._export_sfc(u, [["__scopeId", "data-v-d1cace99"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/node_modules/wot-design-uni/components/wd-toast/wd-toast.vue"]]);wx.createComponent(v);