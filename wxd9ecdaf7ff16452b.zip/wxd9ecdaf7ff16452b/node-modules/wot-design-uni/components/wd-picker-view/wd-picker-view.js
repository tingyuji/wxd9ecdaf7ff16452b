var _createForOfIteratorHelper2 = require("../../../../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  n = Object.defineProperties,
  t = Object.getOwnPropertyDescriptors,
  l = Object.getOwnPropertySymbols,
  o = Object.prototype.hasOwnProperty,
  a = Object.prototype.propertyIsEnumerable,
  r = function r(n, t, l) {
    return t in n ? e(n, t, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: l
    }) : n[t] = l;
  };var u = require("../../../../common/vendor.js");if (!Array) {
  u.resolveComponent("wd-loading")();
}Math;var i = u.defineComponent((c = function (e, n) {
  for (var t in n || (n = {})) o.call(n, t) && r(e, t, n[t]);
  if (l) {
    var _iterator = _createForOfIteratorHelper2(l(n)),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var t = _step.value;
        a.call(n, t) && r(e, t, n[t]);
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
  }
  return e;
}({}, {
  name: "wd-picker-view",
  options: {
    virtualHost: !0,
    addGlobalClass: !0,
    styleIsolation: "shared"
  }
}), s = {
  props: u.pickerViewProps,
  emits: ["change", "pickstart", "pickend", "update:modelValue"],
  setup: function setup(e, _ref) {
    var n = _ref.expose,
      t = _ref.emit;
    var l = e,
      o = t,
      a = u.ref([]),
      r = u.ref(35),
      i = u.ref([]);
    u.watch([function () {
      return l.modelValue;
    }, function () {
      return l.columns;
    }], function (e, n) {
      u.isEqual(n[1], e[1]) || (a.value = u.formatArray(e[1], l.valueKey, l.labelKey)), !u.isEqual(n[0], e[0]) && u.isDef(e[0]) && function (e) {
        if (0 === a.value.length) return;
        ("" === e || !u.isDef(e) || u.isArray(e) && 0 === e.length) && (e = a.value.map(function (e) {
          return e[0][l.valueKey];
        }));
        var n = u.getType(e),
          t = ["string", "number", "boolean", "array"];
        -1 === t.indexOf(n) && console.error("value must be one of ".concat(t.toString())), e = (e = u.isArray(e) ? e : [e]).slice(0, a.value.length);
        var o = u.deepClone(i.value);
        e.forEach(function (e, n) {
          var t = a.value[n].findIndex(function (n) {
            return n[l.valueKey].toString() === e.toString();
          });
          t = -1 === t ? 0 : t, o = s(n, t, o);
        }), i.value = o.slice(0, e.length);
      }(e[0]);
    }, {
      deep: !0,
      immediate: !0
    });
    var _u$getCurrentInstance = u.getCurrentInstance(),
      c = _u$getCurrentInstance.proxy;
    function s(e, n, t) {
      var l = a.value[e];
      if (!l || !l[n]) throw Error("The value to select with Col:".concat(e, " Row:").concat(n, " is incorrect"));
      var o = u.deepClone(t);
      if (o[e] = n, l[n].disabled) {
        var _t = l.slice(0, n).reverse().findIndex(function (e) {
            return !e.disabled;
          }),
          _a = l.slice(n + 1).findIndex(function (e) {
            return !e.disabled;
          });
        -1 !== _t ? o[e] = n - 1 - _t : -1 !== _a ? o[e] = n + 1 + _a : void 0 === o[e] && (o[e] = 0);
      }
      return o;
    }
    function d(_ref2) {
      var e = _ref2.detail.value;
      var n = function (e) {
        e = e.slice(0, a.value.length);
        var n = u.deepClone(i.value);
        var t = u.deepClone(i.value);
        e.forEach(function (e, l) {
          (e = u.range(e, 0, a.value[l].length - 1)) !== n[l] && (t = s(l, e, t));
        });
        var l = function (e, n) {
          if (!e || !n) return -1;
          var t = e.findIndex(function (e, t) {
            return e !== n[t];
          });
          return t;
        }(t, n);
        if (-1 === l) return;
        var o = t[l];
        return 1 === t.length ? o : l;
      }(e = e.map(function (e) {
        return Number(e || 0);
      }));
      i.value = u.deepClone(e), u.nextTick$1(function () {
        i.value = function (e) {
          var n = u.deepClone(e);
          return e.forEach(function (e, t) {
            e = u.range(e, 0, a.value[t].length - 1), n = s(t, e, n);
          }), n;
        }(e), l.columnChange ? l.columnChange.length < 4 ? (l.columnChange(c.$.exposed, v(), n || 0, function () {}), p(n || 0)) : l.columnChange(c.$.exposed, v(), n || 0, function () {
          p(n || 0);
        }) : p(n || 0);
      });
    }
    function p(e) {
      var n = m();
      u.isEqual(n, l.modelValue) || (o("update:modelValue", n), setTimeout(function () {
        o("change", {
          picker: c.$.exposed,
          value: n,
          index: e
        });
      }, 0));
    }
    function v() {
      var e = i.value.map(function (e, n) {
        return a.value[n][e];
      });
      return 1 === e.length ? e[0] : e;
    }
    function m() {
      var e = l.valueKey,
        n = i.value.map(function (n, t) {
          return a.value[t][n][e];
        });
      return 1 === n.length ? n[0] : n;
    }
    function f() {
      o("pickstart");
    }
    function g() {
      o("pickend");
    }
    return n({
      getSelects: v,
      getValues: m,
      setColumnData: function setColumnData(e, n) {
        var t = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
        a.value[e] = u.formatArray(n, l.valueKey, l.labelKey).reduce(function (e, n) {
          return e.concat(n);
        }, []), i.value = s(e, t, i.value);
      },
      getColumnsData: function getColumnsData() {
        return u.deepClone(a.value);
      },
      getColumnData: function getColumnData(e) {
        return a.value[e];
      },
      getColumnIndex: function getColumnIndex(e) {
        return i.value[e];
      },
      getLabels: function getLabels() {
        var e = l.labelKey;
        return i.value.map(function (n, t) {
          return a.value[t][n][e];
        });
      },
      getSelectedIndex: function getSelectedIndex() {
        return i.value;
      }
    }), function (e, n) {
      return u.e({
        a: e.loading
      }, e.loading ? {
        b: u.p({
          color: e.loadingColor
        })
      } : {}, {
        c: u.f(a.value, function (n, t, l) {
          return {
            a: u.f(n, function (n, l, o) {
              return {
                a: u.t(n[e.labelKey]),
                b: l,
                c: u.n("wd-picker-view-column__item ".concat(n.disabled ? "wd-picker-view-column__item--disabled" : "", "  ").concat(i.value[t] == l ? "wd-picker-view-column__item--active" : ""))
              };
            }),
            b: t
          };
        }),
        d: u.s("line-height: ".concat(r.value, "px;")),
        e: "height: ".concat(r.value, "px;"),
        f: u.s("height: ".concat(e.columnsHeight - 20, "px;")),
        g: i.value,
        h: e.immediateChange,
        i: u.o(d),
        j: u.o(f),
        k: u.o(g),
        l: u.s("height: ".concat(e.columnsHeight - 20, "px;")),
        m: u.n("wd-picker-view ".concat(e.customClass)),
        n: u.s(e.customStyle)
      });
    };
  }
}, n(c, t(s))));var c, s;var d = u._export_sfc(i, [["__scopeId", "data-v-38683dd4"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/node_modules/wot-design-uni/components/wd-picker-view/wd-picker-view.vue"]]);wx.createComponent(d);