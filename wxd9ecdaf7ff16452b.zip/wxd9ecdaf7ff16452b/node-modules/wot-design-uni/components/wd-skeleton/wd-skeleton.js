var _toConsumableArray2 = require("../../../../@babel/runtime/helpers/toConsumableArray");var _defineProperty2 = require("../../../../@babel/runtime/helpers/defineProperty");var _createForOfIteratorHelper2 = require("../../../../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  t = Object.defineProperties,
  o = Object.getOwnPropertyDescriptors,
  r = Object.getOwnPropertySymbols,
  n = Object.prototype.hasOwnProperty,
  s = Object.prototype.propertyIsEnumerable,
  a = function a(t, o, r) {
    return o in t ? e(t, o, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: r
    }) : t[o] = r;
  },
  i = function i(e, t) {
    for (var o in t || (t = {})) n.call(t, o) && a(e, o, t[o]);
    if (r) {
      var _iterator = _createForOfIteratorHelper2(r(t)),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var o = _step.value;
          s.call(t, o) && a(e, o, t[o]);
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
    return e;
  },
  l = function l(e, r) {
    return t(e, o(r));
  };var c = require("../../../../common/vendor.js"),
  p = c.defineComponent(l(i({}, {
    options: {
      virtualHost: !0,
      addGlobalClass: !0,
      styleIsolation: "shared"
    }
  }), {
    __name: "wd-skeleton",
    props: c.skeletonProps,
    setup: function setup(e) {
      var t = {
          avatar: [{
            type: "circle",
            height: "64px",
            width: "64px"
          }],
          image: [{
            type: "rect",
            height: "64px",
            width: "64px"
          }],
          text: [1, [{
            width: "24%",
            height: "16px",
            marginRight: "16px"
          }, {
            width: "76%",
            height: "16px"
          }]],
          paragraph: [1, 1, 1, {
            width: "55%"
          }]
        },
        o = e,
        r = c.ref([]),
        n = c.computed(function () {
          return r.value.map(function (e) {
            if (c.isNumber(e)) return [{
              class: s({
                type: "text"
              }),
              style: {}
            }];
            if (Array.isArray(e)) return e.map(function (e) {
              return l(i({}, e), {
                class: s(e),
                style: a(e)
              });
            });
            var t = e;
            return [l(i({}, t), {
              class: s(t),
              style: a(t)
            })];
          });
        });
      function s(e) {
        return ["wd-skeleton__col", "wd-skeleton--type-".concat(e.type || "text"), _defineProperty2({}, "wd-skeleton--animation-".concat(o.animation), o.animation)];
      }
      function a(e) {
        var t = {},
          o = ["size", "width", "height", "margin", "background", "marginLeft", "marginRight", "borderRadius", "backgroundColor"];
        for (var _i = 0, _o = o; _i < _o.length; _i++) {
          var _r = _o[_i];
          if (Object.prototype.hasOwnProperty.call(e, _r)) {
            var _o2 = c.addUnit(e[_r]);
            "size" === _r ? (t.width = _o2, t.height = _o2) : t[_r] = _o2;
          }
        }
        return t;
      }
      c.watch(function () {
        return o.rowCol;
      }, function (e) {
        r.value = _toConsumableArray2(Array.isArray(e) && e.length ? o.rowCol : t[o.theme]);
      }, {
        immediate: !0
      });
      var p = c.computed(function () {
        return null == o.loading || !0 === o.loading;
      });
      return function (e, t) {
        return c.e({
          a: p.value
        }, p.value ? {
          b: c.f(n.value, function (e, t, o) {
            return {
              a: c.f(e, function (e, t, o) {
                return {
                  a: "col-".concat(t),
                  b: c.n(e.class),
                  c: c.s(e.style)
                };
              }),
              b: "row-".concat(t)
            };
          })
        } : {}, {
          c: c.n("wd-skeleton ".concat(e.customClass)),
          d: c.s(e.customStyle)
        });
      };
    }
  })),
  d = c._export_sfc(p, [["__scopeId", "data-v-f2d4e6d8"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/node_modules/wot-design-uni/components/wd-skeleton/wd-skeleton.vue"]]);wx.createComponent(d);