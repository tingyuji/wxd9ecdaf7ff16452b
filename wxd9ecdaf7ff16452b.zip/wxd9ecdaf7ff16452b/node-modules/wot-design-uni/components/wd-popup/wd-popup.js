var _createForOfIteratorHelper2 = require("../../../../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  t = Object.defineProperties,
  o = Object.getOwnPropertyDescriptors,
  a = Object.getOwnPropertySymbols,
  n = Object.prototype.hasOwnProperty,
  l = Object.prototype.propertyIsEnumerable,
  r = function r(t, o, a) {
    return o in t ? e(t, o, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: a
    }) : t[o] = a;
  };var s = require("../../../../common/vendor.js");if (!Array) {
  (s.resolveComponent("wd-overlay") + s.resolveComponent("wd-icon"))();
}Math || (function () {
  return "../wd-overlay/wd-overlay.js";
} + function () {
  return "../wd-icon/wd-icon.js";
})();var i = s.defineComponent((u = function (e, t) {
  for (var o in t || (t = {})) n.call(t, o) && r(e, o, t[o]);
  if (a) {
    var _iterator = _createForOfIteratorHelper2(a(t)),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var o = _step.value;
        l.call(t, o) && r(e, o, t[o]);
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
  }
  return e;
}({}, {
  name: "wd-popup",
  options: {
    virtualHost: !0,
    addGlobalClass: !0,
    styleIsolation: "shared"
  }
}), c = {
  props: s.popupProps,
  emits: ["update:modelValue", "before-enter", "enter", "before-leave", "leave", "after-leave", "after-enter", "click-modal", "close"],
  setup: function setup(e, _ref) {
    var t = _ref.emit;
    var o = e,
      a = t,
      n = function n(e) {
        return e ? {
          enter: "wd-".concat(e, "-enter wd-").concat(e, "-enter-active"),
          "enter-to": "wd-".concat(e, "-enter-to wd-").concat(e, "-enter-active"),
          leave: "wd-".concat(e, "-leave wd-").concat(e, "-leave-active"),
          "leave-to": "wd-".concat(e, "-leave-to wd-").concat(e, "-leave-active")
        } : {
          enter: "enter-class enter-active-class",
          "enter-to": "enter-to-class enter-active-class",
          leave: "leave-class leave-active-class",
          "leave-to": "leave-to-class leave-active-class"
        };
      },
      l = s.ref(!1),
      r = s.ref(!1),
      i = s.ref(""),
      u = s.ref(!1),
      c = s.ref(300),
      d = s.ref(""),
      v = s.ref(0),
      p = s.ref(""),
      m = s.computed(function () {
        return "z-index: ".concat(o.zIndex, "; padding-bottom: ").concat(v.value, "px; -webkit-transition-duration: ").concat(c.value, "ms; transition-duration: ").concat(c.value, "ms; ").concat(r.value || !o.hideWhenClose ? "" : "display: none;", " ").concat(o.customStyle);
      }),
      f = s.computed(function () {
        return "wd-popup wd-popup--".concat(o.position, " ").concat(o.customClass || "", " ").concat(d.value || "");
      });
    function w() {
      var e = n(o.transition || o.position),
        t = "none" === o.transition ? 0 : s.isObj(o.duration) ? o.duration.enter : o.duration;
      i.value = "enter", a("before-enter"), s.requestAnimationFrame(function () {
        a("enter"), d.value = e.enter, c.value = t, s.requestAnimationFrame(function () {
          l.value = !0, r.value = !0, s.requestAnimationFrame(function () {
            u.value = !1, d.value = e["enter-to"];
          });
        });
      });
    }
    function b() {
      u.value || (u.value = !0, "leave" === i.value ? a("after-leave") : "enter" === i.value && a("after-enter"), !o.modelValue && r.value && (r.value = !1));
    }
    function y() {
      var e = o.transition,
        t = o.position;
      p.value = e || t;
    }
    function $() {
      a("click-modal"), o.closeOnClickModal && j();
    }
    function j() {
      a("close"), a("update:modelValue", !1);
    }
    function O() {}
    return s.onBeforeMount(function () {
      if (y(), o.safeAreaInsetBottom) {
        var _s$index$getSystemInf = s.index.getSystemInfoSync(),
          _e = _s$index$getSystemInf.safeArea,
          _t = _s$index$getSystemInf.screenHeight,
          _o = _s$index$getSystemInf.safeAreaInsets;
        v.value = _e ? _t - (_e.bottom || 0) : 0;
      }
      o.modelValue && w();
    }), s.watch(function () {
      return o.modelValue;
    }, function (e) {
      e ? w() : function () {
        if (!r.value) return;
        var e = n(o.transition || o.position),
          t = "none" === o.transition ? 0 : s.isObj(o.duration) ? o.duration.leave : o.duration;
        i.value = "leave", a("before-leave"), s.requestAnimationFrame(function () {
          a("leave"), d.value = e.leave, c.value = t, s.requestAnimationFrame(function () {
            u.value = !1;
            var t = setTimeout(function () {
              b(), clearTimeout(t);
            }, c.value);
            d.value = e["leave-to"];
          });
        });
      }();
    }, {
      deep: !0,
      immediate: !0
    }), s.watch([function () {
      return o.position;
    }, function () {
      return o.transition;
    }], function () {
      y();
    }, {
      deep: !0,
      immediate: !0
    }), function (e, t) {
      return s.e({
        a: e.modal
      }, e.modal ? {
        b: s.o($),
        c: s.o(O),
        d: s.p({
          show: e.modelValue,
          "z-index": e.zIndex,
          "lock-scroll": e.lockScroll,
          duration: e.duration,
          "custom-style": e.modalStyle
        })
      } : {}, {
        e: !e.lazyRender || l.value
      }, !e.lazyRender || l.value ? s.e({
        f: e.closable
      }, e.closable ? {
        g: s.o(j),
        h: s.p({
          "custom-class": "wd-popup__close",
          name: "add"
        })
      } : {}, {
        i: s.n(f.value),
        j: s.s(m.value),
        k: s.o(b)
      }) : {});
    };
  }
}, t(u, o(c))));var u, c;var d = s._export_sfc(i, [["__scopeId", "data-v-82a7a455"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/node_modules/wot-design-uni/components/wd-popup/wd-popup.vue"]]);wx.createComponent(d);