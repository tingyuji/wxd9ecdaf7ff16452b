var _createForOfIteratorHelper2 = require("../../../../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  o = Object.defineProperties,
  t = Object.getOwnPropertyDescriptors,
  n = Object.getOwnPropertySymbols,
  a = Object.prototype.hasOwnProperty,
  i = Object.prototype.propertyIsEnumerable,
  s = function s(o, t, n) {
    return t in o ? e(o, t, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: n
    }) : o[t] = n;
  };var r = require("../../../../common/vendor.js");if (!Array) {
  r.resolveComponent("wd-icon")();
}Math;var l = r.defineComponent((c = function (e, o) {
  for (var t in o || (o = {})) a.call(o, t) && s(e, t, o[t]);
  if (n) {
    var _iterator = _createForOfIteratorHelper2(n(o)),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var t = _step.value;
        i.call(o, t) && s(e, t, o[t]);
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
  }
  return e;
}({}, {
  name: "wd-button",
  options: {
    addGlobalClass: !0,
    virtualHost: !0,
    styleIsolation: "shared"
  }
}), d = {
  props: r.buttonProps,
  emits: ["click", "getuserinfo", "contact", "getphonenumber", "error", "launchapp", "opensetting", "chooseavatar", "agreeprivacyauthorization"],
  setup: function setup(e, _ref) {
    var o = _ref.emit;
    var t = e,
      n = o,
      a = r.ref(20),
      i = r.ref(70),
      s = r.ref(""),
      l = r.computed(function () {
        return "background-image: url(".concat(s.value, ");");
      });
    function c(e) {
      t.disabled || t.loading || n("click", e.detail);
    }
    function d(e) {
      n("getuserinfo", e.detail);
    }
    function p(e) {
      n("contact", e.detail);
    }
    function u(e) {
      n("getphonenumber", e.detail);
    }
    function f(e) {
      n("error", e.detail);
    }
    function g(e) {
      n("launchapp", e.detail);
    }
    function m(e) {
      n("opensetting", e.detail);
    }
    function b(e) {
      n("chooseavatar", e.detail);
    }
    function v(e) {
      n("agreeprivacyauthorization", e.detail);
    }
    return r.watch(function () {
      return t.loading;
    }, function () {
      !function () {
        var e = t.loadingColor,
          o = t.type,
          n = t.plain;
        var a = e;
        if (!a) switch (o) {
          case "primary":
            a = "#4D80F0";
            break;
          case "success":
            a = "#34d19d";
            break;
          case "info":
          case "default":
            a = "#333";
            break;
          case "warning":
            a = "#f0883a";
            break;
          case "error":
            a = "#fa4350";
        }
        var i = function () {
          var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "#4D80F0";
          var o = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : !0;
          return "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 42 42\"><defs><linearGradient x1=\"100%\" y1=\"0%\" x2=\"0%\" y2=\"0%\" id=\"a\"><stop stop-color=\"".concat(o ? e : "#fff", "\" offset=\"0%\" stop-opacity=\"0\"/><stop stop-color=\"").concat(o ? e : "#fff", "\" offset=\"100%\"/></linearGradient></defs><g fill=\"none\" fill-rule=\"evenodd\"><path d=\"M21 1c11.046 0 20 8.954 20 20s-8.954 20-20 20S1 32.046 1 21 9.954 1 21 1zm0 7C13.82 8 8 13.82 8 21s5.82 13 13 13 13-5.82 13-13S28.18 8 21 8z\" fill=\"").concat(o ? "#fff" : e, "\"/><path d=\"M4.599 21c0 9.044 7.332 16.376 16.376 16.376 9.045 0 16.376-7.332 16.376-16.376\" stroke=\"url(#a)\" stroke-width=\"3.5\" stroke-linecap=\"round\"/></g></svg>");
        }(a, !n);
        s.value = "\"data:image/svg+xml;base64,".concat(r.encode(i), "\"");
      }();
    }, {
      deep: !0,
      immediate: !0
    }), function (e, o) {
      return r.e({
        a: e.loading
      }, e.loading ? {
        b: r.s(l.value)
      } : e.icon ? {
        d: r.p({
          "custom-class": "wd-button__icon",
          name: e.icon
        })
      } : {}, {
        c: e.icon,
        e: e.disabled || e.loading ? "" : "wd-button--active",
        f: r.s(e.customStyle),
        g: r.n("is-" + e.type),
        h: r.n("is-" + e.size),
        i: r.n(e.plain ? "is-plain" : ""),
        j: r.n(e.disabled ? "is-disabled" : ""),
        k: r.n(e.round ? "is-round" : ""),
        l: r.n(e.hairline ? "is-hairline" : ""),
        m: r.n(e.block ? "is-block" : ""),
        n: r.n(e.loading ? "is-loading" : ""),
        o: r.n(e.customClass),
        p: a.value,
        q: i.value,
        r: e.openType,
        s: e.sendMessageTitle,
        t: e.sendMessagePath,
        v: e.sendMessageImg,
        w: e.appParameter,
        x: e.showMessageCard,
        y: e.sessionFrom,
        z: e.lang,
        A: e.hoverStopPropagation,
        B: e.formType,
        C: r.o(c),
        D: r.o(d),
        E: r.o(p),
        F: r.o(u),
        G: r.o(f),
        H: r.o(g),
        I: r.o(m),
        J: r.o(b),
        K: r.o(v)
      });
    };
  }
}, o(c, t(d))));var c, d;var p = r._export_sfc(l, [["__scopeId", "data-v-aa3a6253"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/node_modules/wot-design-uni/components/wd-button/wd-button.vue"]]);wx.createComponent(p);