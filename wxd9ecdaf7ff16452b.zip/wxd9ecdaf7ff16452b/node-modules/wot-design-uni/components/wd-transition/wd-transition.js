var _regeneratorRuntime2 = require("../../../../@babel/runtime/helpers/regeneratorRuntime");var _createForOfIteratorHelper2 = require("../../../../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  a = Object.defineProperties,
  t = Object.getOwnPropertyDescriptors,
  l = Object.getOwnPropertySymbols,
  r = Object.prototype.hasOwnProperty,
  n = Object.prototype.propertyIsEnumerable,
  o = function o(a, t, l) {
    return t in a ? e(a, t, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: l
    }) : a[t] = l;
  },
  u = function u(e, a, t) {
    return new Promise(function (l, r) {
      var n = function n(e) {
          try {
            u(t.next(e));
          } catch (a) {
            r(a);
          }
        },
        o = function o(e) {
          try {
            u(t.throw(e));
          } catch (a) {
            r(a);
          }
        },
        u = function u(e) {
          return e.done ? l(e.value) : Promise.resolve(e.value).then(n, o);
        };
      u((t = t.apply(e, a)).next());
    });
  };var v = require("../../../../common/vendor.js"),
  i = v.defineComponent((s = function (e, a) {
    for (var t in a || (a = {})) r.call(a, t) && o(e, t, a[t]);
    if (l) {
      var _iterator = _createForOfIteratorHelper2(l(a)),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var t = _step.value;
          n.call(a, t) && o(e, t, a[t]);
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
    return e;
  }({}, {
    name: "wd-transition",
    options: {
      addGlobalClass: !0,
      virtualHost: !0,
      styleIsolation: "shared"
    }
  }), c = {
    props: v.transitionProps,
    emits: ["click", "before-enter", "enter", "before-leave", "leave", "after-leave", "after-enter"],
    setup: function setup(e, _ref) {
      var a = _ref.emit;
      var t = function t(e) {
          return e ? {
            enter: "wd-".concat(e, "-enter wd-").concat(e, "-enter-active"),
            "enter-to": "wd-".concat(e, "-enter-to wd-").concat(e, "-enter-active"),
            leave: "wd-".concat(e, "-leave wd-").concat(e, "-leave-active"),
            "leave-to": "wd-".concat(e, "-leave-to wd-").concat(e, "-leave-active")
          } : {
            enter: "".concat(l.enterClass, " ").concat(l.enterActiveClass),
            "enter-to": "".concat(l.enterToClass, " ").concat(l.enterActiveClass),
            leave: "".concat(l.leaveClass, " ").concat(l.leaveActiveClass),
            "leave-to": "".concat(l.leaveToClass, " ").concat(l.leaveActiveClass)
          };
        },
        l = e,
        r = a,
        n = v.ref(!1),
        o = v.ref(!1),
        i = v.ref(""),
        s = v.ref(!1),
        c = v.ref(300),
        d = v.ref(""),
        m = v.ref(null),
        f = v.ref(null),
        p = v.ref(null),
        w = v.computed(function () {
          return "-webkit-transition-duration:".concat(c.value, "ms;transition-duration:").concat(c.value, "ms;").concat(o.value ? "" : "display: none;").concat(l.customStyle);
        }),
        b = v.computed(function () {
          return "wd-transition ".concat(l.customClass, "  ").concat(d.value);
        });
      function y() {
        r("click");
      }
      function $() {
        var _this = this;
        m.value = new v.AbortablePromise(function (e) {
          return u(_this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
            var _a, _u;
            return _regeneratorRuntime2().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  _context.prev = 0;
                  _a = t(l.name), _u = v.isObj(l.duration) ? l.duration.enter : l.duration;
                  i.value = "enter";
                  r("before-enter");
                  f.value = v.requestAnimationFrame();
                  _context.next = 7;
                  return f.value;
                case 7:
                  r("enter");
                  d.value = _a.enter;
                  c.value = _u;
                  f.value = v.requestAnimationFrame();
                  _context.next = 13;
                  return f.value;
                case 13:
                  n.value = !0;
                  o.value = !0;
                  f.value = v.requestAnimationFrame();
                  _context.next = 18;
                  return f.value;
                case 18:
                  f.value = null;
                  s.value = !1;
                  d.value = _a["enter-to"];
                  e();
                  _context.next = 26;
                  break;
                case 24:
                  _context.prev = 24;
                  _context.t0 = _context["catch"](0);
                case 26:
                case "end":
                  return _context.stop();
              }
            }, _callee, null, [[0, 24]]);
          }));
        });
      }
      function h() {
        s.value || (s.value = !0, "leave" === i.value ? r("after-leave") : "enter" === i.value && r("after-enter"), !l.show && o.value && (o.value = !1));
      }
      return v.onBeforeMount(function () {
        l.show && $();
      }), v.watch(function () {
        return l.show;
      }, function (e) {
        e ? (v.isPromise(m.value) && m.value.abort(), v.isPromise(f.value) && f.value.abort(), v.isPromise(p.value) && p.value.abort(), m.value = null, f.value = null, p.value = null, $()) : function () {
          u(this, null, /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
            var _e, _a2;
            return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
              while (1) switch (_context2.prev = _context2.next) {
                case 0:
                  if (m.value) {
                    _context2.next = 2;
                    break;
                  }
                  return _context2.abrupt("return", (s.value = !1, h()));
                case 2:
                  _context2.prev = 2;
                  _context2.next = 5;
                  return m.value;
                case 5:
                  if (o.value) {
                    _context2.next = 7;
                    break;
                  }
                  return _context2.abrupt("return");
                case 7:
                  _e = t(l.name), _a2 = v.isObj(l.duration) ? l.duration.leave : l.duration;
                  i.value = "leave";
                  r("before-leave");
                  c.value = _a2;
                  p.value = v.requestAnimationFrame();
                  _context2.next = 14;
                  return p.value;
                case 14:
                  r("leave");
                  d.value = _e.leave;
                  p.value = v.requestAnimationFrame();
                  _context2.next = 19;
                  return p.value;
                case 19:
                  s.value = !1;
                  d.value = _e["leave-to"];
                  p.value = function (e) {
                    return new v.AbortablePromise(function (a) {
                      var t = setTimeout(function () {
                        clearTimeout(t), a();
                      }, e);
                    });
                  }(c.value);
                  _context2.next = 24;
                  return p.value;
                case 24:
                  p.value = null;
                  h();
                  m.value = null;
                  _context2.next = 31;
                  break;
                case 29:
                  _context2.prev = 29;
                  _context2.t0 = _context2["catch"](2);
                case 31:
                case "end":
                  return _context2.stop();
              }
            }, _callee2, null, [[2, 29]]);
          }));
        }();
      }, {
        deep: !0
      }), function (e, a) {
        return v.e({
          a: n.value
        }, n.value ? {
          b: v.n(b.value),
          c: v.s(w.value),
          d: v.o(h),
          e: v.o(y)
        } : {});
      };
    }
  }, a(s, t(c))));var s, c;var d = v._export_sfc(i, [["__scopeId", "data-v-2c25887e"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/node_modules/wot-design-uni/components/wd-transition/wd-transition.vue"]]);wx.createComponent(d);