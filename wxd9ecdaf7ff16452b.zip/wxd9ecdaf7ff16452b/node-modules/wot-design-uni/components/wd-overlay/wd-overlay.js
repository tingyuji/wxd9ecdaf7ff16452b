var _createForOfIteratorHelper2 = require("../../../../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  o = Object.defineProperties,
  t = Object.getOwnPropertyDescriptors,
  r = Object.getOwnPropertySymbols,
  n = Object.prototype.hasOwnProperty,
  s = Object.prototype.propertyIsEnumerable,
  a = function a(o, t, r) {
    return t in o ? e(o, t, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: r
    }) : o[t] = r;
  };var c = require("../../../../common/vendor.js");if (!Array) {
  c.resolveComponent("wd-transition")();
}Math;var l = c.defineComponent((i = function (e, o) {
  for (var t in o || (o = {})) n.call(o, t) && a(e, t, o[t]);
  if (r) {
    var _iterator = _createForOfIteratorHelper2(r(o)),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var t = _step.value;
        s.call(o, t) && a(e, t, o[t]);
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
  }
  return e;
}({}, {
  name: "wd-overlay",
  options: {
    virtualHost: !0,
    addGlobalClass: !0,
    styleIsolation: "shared"
  }
}), p = {
  props: c.overlayProps,
  emits: ["click"],
  setup: function setup(e, _ref) {
    var o = _ref.emit;
    var t = o;
    function r() {
      t("click");
    }
    function n() {}
    return function (e, o) {
      return {
        a: c.o(r),
        b: c.o(function (o) {
          return e.lockScroll ? n : "";
        }),
        c: c.p({
          show: e.show,
          name: "fade",
          "custom-class": "wd-overlay",
          duration: e.duration,
          "custom-style": "z-index: ".concat(e.zIndex, "; ").concat(e.customStyle)
        })
      };
    };
  }
}, o(i, t(p))));var i, p;var u = c._export_sfc(l, [["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/node_modules/wot-design-uni/components/wd-overlay/wd-overlay.vue"]]);wx.createComponent(u);