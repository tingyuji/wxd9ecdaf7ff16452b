var _createForOfIteratorHelper2 = require("../../../../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  o = Object.defineProperties,
  r = Object.getOwnPropertyDescriptors,
  t = Object.getOwnPropertySymbols,
  s = Object.prototype.hasOwnProperty,
  n = Object.prototype.propertyIsEnumerable,
  a = function a(o, r, t) {
    return r in o ? e(o, r, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: t
    }) : o[r] = t;
  };var d = require("../../../../common/vendor.js"),
  p = d.defineComponent((u = function (e, o) {
    for (var r in o || (o = {})) s.call(o, r) && a(e, r, o[r]);
    if (t) {
      var _iterator = _createForOfIteratorHelper2(t(o)),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var r = _step.value;
          n.call(o, r) && a(e, r, o[r]);
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
    return e;
  }({}, {
    name: "wd-password-input",
    options: {
      virtualHost: !0,
      addGlobalClass: !0,
      styleIsolation: "shared"
    }
  }), i = {
    props: d.passwordInputProps,
    emits: ["focus"],
    setup: function setup(e, _ref) {
      var o = _ref.emit;
      var r = o;
      function t(e) {
        r("focus", e);
      }
      return function (e, o) {
        return d.e({
          a: d.f(e.length, function (o, r, t) {
            return d.e({
              a: e.focused && r === e.modelValue.length
            }, e.focused && r === e.modelValue.length ? {} : d.e({
              b: e.mask && e.modelValue[r] ? "visible" : "hidden",
              c: !e.mask && e.modelValue[r]
            }, !e.mask && e.modelValue[r] ? {
              d: d.t(e.modelValue[r])
            } : {}, {
              e: d.n("wd-password-input__value")
            }), {
              f: r,
              g: 0 !== r && e.gutter ? d.unref(d.addUnit)(e.gutter) : 0
            });
          }),
          b: d.n("wd-password-input__item " + (e.gutter ? "" : "is-border")),
          c: d.o(t),
          d: e.info || e.errorInfo
        }, e.info || e.errorInfo ? {
          e: d.t(e.errorInfo || e.info),
          f: d.n("wd-password-input__info " + (e.errorInfo ? "is-error" : ""))
        } : {}, {
          g: d.n("wd-password-input ".concat(e.customClass)),
          h: d.s(e.customStyle)
        });
      };
    }
  }, o(u, r(i))));var u, i;var l = d._export_sfc(p, [["__scopeId", "data-v-d0f84bd1"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/node_modules/wot-design-uni/components/wd-password-input/wd-password-input.vue"]]);wx.createComponent(l);