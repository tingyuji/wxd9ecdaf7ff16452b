var _createForOfIteratorHelper2 = require("../../../../../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  t = Object.defineProperties,
  o = Object.getOwnPropertyDescriptors,
  r = Object.getOwnPropertySymbols,
  n = Object.prototype.hasOwnProperty,
  a = Object.prototype.propertyIsEnumerable,
  s = function s(t, o, r) {
    return o in t ? e(t, o, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: r
    }) : t[o] = r;
  };var l = require("../../../../../common/vendor.js");if (!Array) {
  (l.resolveComponent("wd-loading") + l.resolveComponent("wd-icon"))();
}Math || (function () {
  return "../../wd-loading/wd-loading.js";
} + function () {
  return "../../wd-icon/wd-icon.js";
})();var p = l.defineComponent((d = function (e, t) {
  for (var o in t || (t = {})) n.call(t, o) && s(e, o, t[o]);
  if (r) {
    var _iterator = _createForOfIteratorHelper2(r(t)),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var o = _step.value;
        a.call(t, o) && s(e, o, t[o]);
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
  }
  return e;
}({}, {
  name: "wd-key",
  options: {
    virtualHost: !0,
    addGlobalClass: !0,
    styleIsolation: "shared"
  }
}), i = {
  props: l.keyProps,
  emits: ["press"],
  setup: function setup(e, _ref) {
    var t = _ref.emit;
    var o = e,
      r = t,
      n = l.useTouch(),
      a = l.ref(!1),
      s = l.computed(function () {
        return "wd-key ".concat(o.large ? "wd-key--large" : "", " ").concat("delete" === o.type ? "wd-key--delete" : "", " ").concat("close" === o.type ? "wd-key--close" : "");
      });
    function p(e) {
      n.touchStart(e), a.value = !0;
    }
    function d(e) {
      n.touchMove(e), n.direction.value && (a.value = !1);
    }
    function i() {
      a.value && (a.value = !1, r("press", o.text, o.type));
    }
    return function (e, t) {
      return l.e({
        a: o.loading
      }, o.loading ? {
        b: l.p({
          "custom-class": "wd-key--loading-icon"
        })
      } : {}, {
        c: "delete" === e.type
      }, "delete" === e.type ? l.e({
        d: e.text
      }, e.text ? {
        e: l.t(e.text)
      } : {
        f: l.p({
          name: "keyboard-delete",
          size: "22px"
        })
      }) : "extra" === e.type ? l.e({
        h: e.text
      }, e.text ? {
        i: l.t(e.text)
      } : {
        j: l.p({
          name: "keyboard-collapse",
          size: "22px"
        })
      }) : {
        k: l.t(e.text)
      }, {
        g: "extra" === e.type,
        l: l.n(s.value),
        m: l.n("wd-key-wrapper " + (e.wider ? "wd-key-wrapper--wider" : "")),
        n: l.o(p),
        o: l.o(d),
        p: l.o(i)
      });
    };
  }
}, t(d, o(i))));var d, i;var c = l._export_sfc(p, [["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/node_modules/wot-design-uni/components/wd-number-keyboard/key/index.vue"]]);wx.createComponent(c);