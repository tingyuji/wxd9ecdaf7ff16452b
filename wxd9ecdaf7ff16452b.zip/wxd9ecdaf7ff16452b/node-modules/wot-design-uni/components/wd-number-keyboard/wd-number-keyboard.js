var _toConsumableArray2 = require("../../../../@babel/runtime/helpers/toConsumableArray");var _createForOfIteratorHelper2 = require("../../../../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  t = Object.defineProperties,
  o = Object.getOwnPropertyDescriptors,
  r = Object.getOwnPropertySymbols,
  l = Object.prototype.hasOwnProperty,
  a = Object.prototype.propertyIsEnumerable,
  n = function n(t, o, r) {
    return o in t ? e(t, o, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: r
    }) : t[o] = r;
  };var s = require("../../../../common/vendor.js");if (!Array) {
  s.resolveComponent("wd-popup")();
}Math || (d + function () {
  return "../wd-popup/wd-popup.js";
})();var d = function d() {
    return "./key/index.js";
  },
  u = s.defineComponent((p = function (e, t) {
    for (var o in t || (t = {})) l.call(t, o) && n(e, o, t[o]);
    if (r) {
      var _iterator = _createForOfIteratorHelper2(r(t)),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var o = _step.value;
          a.call(t, o) && n(e, o, t[o]);
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
    return e;
  }({}, {
    name: "wd-number-keyboard",
    options: {
      virtualHost: !0,
      addGlobalClass: !0,
      styleIsolation: "shared"
    }
  }), c = {
    props: s.numberKeyboardProps,
    emits: ["update:visible", "input", "close", "delete", "update:modelValue"],
    setup: function setup(e, _ref) {
      var t = _ref.emit;
      var o = e,
        r = t,
        l = s.ref(o.visible);
      s.watch(function () {
        return o.visible;
      }, function (e) {
        l.value = e;
      });
      var a = s.computed(function () {
          return "custom" === o.mode ? function () {
            var e = u(),
              t = Array.isArray(o.extraKey) ? o.extraKey : [o.extraKey];
            return 1 === t.length ? e.push({
              text: 0,
              wider: !0
            }, {
              text: t[0],
              type: "extra"
            }) : 2 === t.length && e.push({
              text: t[0],
              type: "extra"
            }, {
              text: 0
            }, {
              text: t[1],
              type: "extra"
            }), e;
          }() : [].concat(_toConsumableArray2(u()), [{
            text: o.extraKey,
            type: "extra"
          }, {
            text: 0
          }, {
            text: o.showDeleteKey ? o.deleteText : "",
            type: o.showDeleteKey ? "delete" : ""
          }]);
        }),
        n = s.computed(function () {
          return o.closeText && "default" === o.mode;
        }),
        d = s.computed(function () {
          return o.title || n.value;
        });
      function u() {
        var e = Array.from({
          length: 9
        }, function (e, t) {
          return {
            text: t + 1
          };
        });
        return o.randomKeyOrder ? function (e) {
          var t = _toConsumableArray2(e);
          for (var _o = t.length - 1; _o > 0; _o--) {
            var _e = Math.floor(Math.random() * (_o + 1));
            var _ref2 = [t[_e], t[_o]];
            t[_o] = _ref2[0];
            t[_e] = _ref2[1];
          }
          return t;
        }(e) : e;
      }
      var p = function p() {
          r("close"), r("update:visible", !1);
        },
        c = function c(e, t) {
          if ("" === e && "extra" === t) return p();
          var l = o.modelValue;
          "delete" === t ? (r("delete"), r("update:modelValue", l.slice(0, l.length - 1))) : "close" === t ? p() : l.length < +o.maxlength && (r("input", e), r("update:modelValue", l + e));
        };
      return function (e, t) {
        return s.e({
          a: d.value
        }, d.value ? s.e({
          b: s.t(e.title),
          c: n.value
        }, n.value ? {
          d: s.t(e.closeText),
          e: s.o(p)
        } : {}) : {}, {
          f: s.f(a.value, function (e, t, o) {
            return {
              a: e.text,
              b: s.o(c, e.text),
              c: "51f8022a-1-" + o + ",51f8022a-0",
              d: s.p({
                text: e.text,
                type: e.type,
                wider: e.wider
              })
            };
          }),
          g: "custom" === e.mode
        }, "custom" === e.mode ? s.e({
          h: e.showDeleteKey
        }, e.showDeleteKey ? {
          i: s.o(c),
          j: s.p({
            large: !0,
            text: e.deleteText,
            type: "delete"
          })
        } : {}, {
          k: s.o(c),
          l: s.p({
            large: !0,
            text: e.closeText,
            type: "close",
            loading: e.closeButtonLoading
          })
        }) : {}, {
          m: s.n("wd-number-keyboard ".concat(e.customClass)),
          n: s.s(e.customStyle),
          o: s.o(p),
          p: s.o(function (e) {
            return l.value = e;
          }),
          q: s.p({
            position: "bottom",
            "z-index": e.zIndex,
            "safe-area-inset-bottom": e.safeAreaInsetBottom,
            "modal-style": e.modal ? "" : "opacity: 0;",
            modal: e.hideOnClickOutside,
            lockScroll: e.lockScroll,
            modelValue: l.value
          })
        });
      };
    }
  }, t(p, o(c))));var p, c;var i = s._export_sfc(u, [["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/node_modules/wot-design-uni/components/wd-number-keyboard/wd-number-keyboard.vue"]]);wx.createComponent(i);