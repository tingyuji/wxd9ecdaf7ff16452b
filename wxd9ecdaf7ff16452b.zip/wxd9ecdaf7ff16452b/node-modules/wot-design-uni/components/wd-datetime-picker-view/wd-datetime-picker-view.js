var _defineProperty2 = require("../../../../@babel/runtime/helpers/defineProperty");var _slicedToArray2 = require("../../../../@babel/runtime/helpers/slicedToArray");var _createForOfIteratorHelper2 = require("../../../../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  t = Object.defineProperties,
  n = Object.getOwnPropertyDescriptors,
  r = Object.getOwnPropertySymbols,
  a = Object.prototype.hasOwnProperty,
  o = Object.prototype.propertyIsEnumerable,
  u = function u(t, n, r) {
    return n in t ? e(t, n, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: r
    }) : t[n] = r;
  },
  i = function i(e, t) {
    for (var n in t || (t = {})) a.call(t, n) && u(e, n, t[n]);
    if (r) {
      var _iterator = _createForOfIteratorHelper2(r(t)),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var n = _step.value;
          o.call(t, n) && u(e, n, t[n]);
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
    return e;
  };var m = require("../../../../common/vendor.js");if (!Array) {
  m.resolveComponent("wd-picker-view")();
}Math;var l = m.defineComponent((c = i({}, {
  name: "wd-datetime-picker-view",
  virtualHost: !0,
  addGlobalClass: !0,
  styleIsolation: "shared"
}), s = {
  props: m.datetimePickerViewProps,
  emits: ["change", "pickstart", "pickend", "update:modelValue"],
  setup: function setup(e, _ref) {
    var t = _ref.expose,
      n = _ref.emit;
    var r = function r(e, t) {
        return 32 - new Date(e, t - 1, 32).getDate();
      },
      a = e,
      o = n,
      u = m.ref(),
      l = m.ref(null),
      c = m.ref([]),
      s = m.ref([]),
      p = m.ref(!1),
      _m$getCurrentInstance = m.getCurrentInstance(),
      d = _m$getCurrentInstance.proxy;
    t(i({
      updateColumns: f,
      setColumns: function setColumns(e) {
        c.value = e;
      },
      getSelects: function getSelects() {
        var e;
        var t = null == (e = u.value) ? void 0 : e.getSelects();
        return null == t ? void 0 : m.isArray(t) ? t : [t];
      },
      correctValue: h,
      getPickerValue: m.getPickerValue,
      getOriginColumns: v
    }, a));
    var g = m.debounce(function () {
      if (!p.value) return;
      var e = h(a.modelValue);
      e === l.value ? c.value = f() : w(e);
    }, 50);
    function y(_ref2) {
      var e = _ref2.value;
      s.value = e;
      var t = function () {
        var e;
        var t = a.type;
        var n = "";
        var o = (null == (e = u.value) ? void 0 : e.getValues()) || [],
          i = m.isArray(o) ? o : [o];
        if ("time" === t) return n = "".concat(m.padZero(i[0]), ":").concat(m.padZero(i[1])), n;
        var l = i[0] && parseInt(i[0]),
          c = "year" === t ? 1 : i[1] && parseInt(i[1]),
          s = r(Number(l), Number(c));
        var p = 1;
        "year-month" !== t && "year" !== t && (p = (Number(i[2]) && parseInt(String(i[2]))) > s ? s : i[2] && parseInt(String(i[2])));
        var d = 0,
          g = 0;
        "datetime" === t && (d = Number(i[3]) && parseInt(i[3]), g = Number(i[4]) && parseInt(i[4]));
        var y = new Date(Number(l), Number(c) - 1, Number(p), d, g).getTime();
        return n = h(y), n;
      }();
      o("update:modelValue", t), o("change", {
        value: t,
        picker: d.$.exposed
      });
    }
    function f() {
      var e = a.formatter,
        t = a.columnFormatter;
      return t ? t(d.$.exposed) : v().map(function (t) {
        return t.values.map(function (n) {
          return {
            label: e ? e(t.type, m.padZero(n)) : m.padZero(n),
            value: n
          };
        });
      });
    }
    function v() {
      var e = a.filter;
      return function () {
        if ("time" === a.type) return [{
          type: "hour",
          range: [a.minHour, a.maxHour]
        }, {
          type: "minute",
          range: [a.minMinute, a.maxMinute]
        }];
        var _b = b("max", l.value),
          e = _b.maxYear,
          t = _b.maxDate,
          n = _b.maxMonth,
          r = _b.maxHour,
          o = _b.maxMinute,
          _b2 = b("min", l.value),
          u = _b2.minYear,
          i = _b2.minDate,
          m = _b2.minMonth,
          c = _b2.minHour,
          s = _b2.minMinute,
          p = [{
            type: "year",
            range: [u, e]
          }, {
            type: "month",
            range: [m, n]
          }, {
            type: "date",
            range: [i, t]
          }, {
            type: "hour",
            range: [c, r]
          }, {
            type: "minute",
            range: [s, o]
          }];
        return "date" === a.type && p.splice(3, 2), "year-month" === a.type && p.splice(2, 3), "year" === a.type && p.splice(1, 4), p;
      }().map(function (_ref3) {
        var t = _ref3.type,
          n = _ref3.range;
        var r = function (e, t) {
          var n = -1;
          var r = Array(e < 0 ? 0 : e);
          for (; ++n < e;) r[n] = t(n);
          return r;
        }(n[1] - n[0] + 1, function (e) {
          return n[0] + e;
        });
        return e && (r = e(t, r)), {
          type: t,
          values: r
        };
      });
    }
    function h(e) {
      var t = "time" !== a.type;
      var n;
      if (t && (n = e, !m.isDef(n) || Number.isNaN(n)) ? e = a.minDate : t || e || (e = "".concat(m.padZero(a.minHour), ":00")), !t) {
        var _e$split = e.split(":"),
          _e$split2 = _slicedToArray2(_e$split, 2),
          _t = _e$split2[0],
          _n = _e$split2[1];
        return _t = m.padZero(m.range(Number(_t), a.minHour, a.maxHour)), _n = m.padZero(m.range(Number(_n), a.minMinute, a.maxMinute)), "".concat(_t, ":").concat(_n);
      }
      return e = Math.min(Math.max(Number(e), a.minDate), a.maxDate);
    }
    function b(e, t) {
      var n = new Date(t),
        o = new Date(a["".concat(e, "Date")]),
        u = o.getFullYear();
      var i = 1,
        m = 1,
        l = 0,
        c = 0;
      return "max" === e && (i = 12, m = r(n.getFullYear(), n.getMonth() + 1), l = 23, c = 59), n.getFullYear() === u && (i = o.getMonth() + 1, n.getMonth() + 1 === i && (m = o.getDate(), n.getDate() === m && (l = o.getHours(), n.getHours() === l && (c = o.getMinutes())))), _defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2({}, "".concat(e, "Year"), u), "".concat(e, "Month"), i), "".concat(e, "Date"), m), "".concat(e, "Hour"), l), "".concat(e, "Minute"), c);
    }
    function w(e) {
      var t = m.getPickerValue(e, a.type);
      a.modelValue !== e && (o("update:modelValue", e), o("change", {
        value: e,
        picker: d.$.exposed
      })), l.value = e, c.value = f(), s.value = t;
    }
    function x(e) {
      if ("time" === a.type || "year-month" === a.type || "year" === a.type) return;
      var t = e.getValues(),
        n = Number(t[0]),
        o = Number(t[1]),
        u = r(n, o);
      var i = Number(t[2]);
      i = i > u ? u : i;
      var m = 0,
        c = 0;
      "datetime" === a.type && (m = Number(t[3]), c = Number(t[4]));
      var s = new Date(n, o - 1, i, m, c).getTime();
      l.value = h(s);
      var p = f(),
        d = e.getSelectedIndex().slice(0);
      p.forEach(function (t, n) {
        var r = n + 1,
          a = p[r];
        r > p.length - 1 || e.setColumnData(r, a, d[r] <= a.length - 1 ? d[r] : 0);
      });
    }
    function D() {
      o("pickstart");
    }
    function M() {
      o("pickend");
    }
    return m.watch(function () {
      return a.modelValue;
    }, function (e, t) {
      e !== t && w(h(e));
    }, {
      deep: !0,
      immediate: !0
    }), m.watch(function () {
      return a.type;
    }, function (e) {
      var t = ["date", "year-month", "time", "datetime", "year"];
      -1 === t.indexOf(e) && console.error("type must be one of ".concat(t)), g();
    }, {
      deep: !0,
      immediate: !0
    }), m.watch(function () {
      return a.filter;
    }, function (e) {
      e && !m.isFunction(e) && console.error("The type of filter must be Function"), g();
    }, {
      deep: !0,
      immediate: !0
    }), m.watch(function () {
      return a.formatter;
    }, function (e) {
      e && !m.isFunction(e) && console.error("The type of formatter must be Function"), g();
    }, {
      deep: !0,
      immediate: !0
    }), m.watch(function () {
      return a.columnFormatter;
    }, function (e) {
      e && !m.isFunction(e) && console.error("The type of columnFormatter must be Function"), g();
    }, {
      deep: !0,
      immediate: !0
    }), m.watch([function () {
      return a.minDate;
    }, function () {
      return a.maxDate;
    }, function () {
      return a.minHour;
    }, function () {
      return a.maxHour;
    }, function () {
      return a.minMinute;
    }, function () {
      return a.minMinute;
    }, function () {
      return a.maxMinute;
    }], function () {
      g();
    }, {
      deep: !0,
      immediate: !0
    }), m.onBeforeMount(function () {
      p.value = !0, w(h(a.modelValue));
    }), function (e, t) {
      return {
        a: m.sr(u, "22b0a973-0", {
          k: "datePickerview"
        }),
        b: m.o(y),
        c: m.o(D),
        d: m.o(M),
        e: m.o(function (e) {
          return s.value = e;
        }),
        f: m.p({
          "custom-class": e.customClass,
          "custom-style": e.customStyle,
          "immediate-change": e.immediateChange,
          columns: c.value,
          "columns-height": e.columnsHeight,
          columnChange: x,
          loading: e.loading,
          "loading-color": e.loadingColor,
          modelValue: s.value
        })
      };
    };
  }
}, t(c, n(s))));var c, s;var p = m._export_sfc(l, [["__scopeId", "data-v-22b0a973"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/node_modules/wot-design-uni/components/wd-datetime-picker-view/wd-datetime-picker-view.vue"]]);wx.createComponent(p);