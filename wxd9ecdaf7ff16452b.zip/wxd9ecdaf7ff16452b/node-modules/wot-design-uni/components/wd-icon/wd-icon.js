var _createForOfIteratorHelper2 = require("../../../../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  o = Object.defineProperties,
  t = Object.getOwnPropertyDescriptors,
  r = Object.getOwnPropertySymbols,
  n = Object.prototype.hasOwnProperty,
  s = Object.prototype.propertyIsEnumerable,
  c = function c(o, t, r) {
    return t in o ? e(o, t, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: r
    }) : o[t] = r;
  };var a = require("../../../../common/vendor.js"),
  i = a.defineComponent((l = function (e, o) {
    for (var t in o || (o = {})) n.call(o, t) && c(e, t, o[t]);
    if (r) {
      var _iterator = _createForOfIteratorHelper2(r(o)),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var t = _step.value;
          s.call(o, t) && c(e, t, o[t]);
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
    return e;
  }({}, {
    name: "wd-icon",
    options: {
      virtualHost: !0,
      addGlobalClass: !0,
      styleIsolation: "shared"
    }
  }), p = {
    props: a.iconProps,
    emits: ["click"],
    setup: function setup(e, _ref) {
      var o = _ref.emit;
      var t = e,
        r = o,
        n = a.ref(!1);
      a.watch(function () {
        return t.name;
      }, function (e) {
        n.value = e.indexOf("/") > -1;
      }, {
        deep: !0,
        immediate: !0
      });
      var s = a.computed(function () {
          var e = t.classPrefix;
          return "".concat(e, " ").concat(t.customClass, " ").concat(n.value ? "wd-icon--image" : e + "-" + t.name);
        }),
        c = a.computed(function () {
          var e = {};
          return t.color && (e.color = t.color), t.size && (e["font-size"] = t.size), "".concat(a.objToStyle(e), "; ").concat(t.customStyle);
        });
      function i(e) {
        r("click", e);
      }
      return function (e, o) {
        return a.e({
          a: n.value
        }, n.value ? {
          b: e.name
        } : {}, {
          c: a.o(i),
          d: a.n(s.value),
          e: a.s(c.value)
        });
      };
    }
  }, o(l, t(p))));var l, p;var u = a._export_sfc(i, [["__scopeId", "data-v-d4a8410a"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/node_modules/wot-design-uni/components/wd-icon/wd-icon.vue"]]);wx.createComponent(u);