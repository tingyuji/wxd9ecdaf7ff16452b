var _createForOfIteratorHelper2 = require("../../../../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  o = Object.defineProperties,
  l = Object.getOwnPropertyDescriptors,
  a = Object.getOwnPropertySymbols,
  n = Object.prototype.hasOwnProperty,
  t = Object.prototype.propertyIsEnumerable,
  r = function r(o, l, a) {
    return l in o ? e(o, l, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: a
    }) : o[l] = a;
  };var u = require("../../../../common/vendor.js");if (!Array) {
  u.resolveComponent("wd-icon")();
}Math;var i = u.defineComponent((s = function (e, o) {
  for (var l in o || (o = {})) n.call(o, l) && r(e, l, o[l]);
  if (a) {
    var _iterator = _createForOfIteratorHelper2(a(o)),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var l = _step.value;
        t.call(o, l) && r(e, l, o[l]);
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
  }
  return e;
}({}, {
  name: "wd-input",
  options: {
    virtualHost: !0,
    addGlobalClass: !0,
    styleIsolation: "shared"
  }
}), c = {
  props: u.inputProps,
  emits: ["update:modelValue", "clear", "change", "blur", "focus", "input", "keyboardheightchange", "confirm", "linechange", "clicksuffixicon", "clickprefixicon", "click"],
  setup: function setup(e, _ref) {
    var o = _ref.emit;
    var l = e,
      a = o,
      _u$useTranslate = u.useTranslate("input"),
      n = _u$useTranslate.translate,
      t = u.ref(!1),
      r = u.ref(!1),
      i = u.ref(!1),
      s = u.ref(!1),
      c = u.ref(!1),
      d = u.ref(""),
      p = u.useCell();
    u.watch(function () {
      return l.focus;
    }, function (e) {
      c.value = e;
    }, {
      immediate: !0,
      deep: !0
    }), u.watch(function () {
      return l.modelValue;
    }, function (e) {
      var o = l.disabled,
        a = l.readonly,
        n = l.clearable;
      void 0 === e && (e = "", console.warn("[wot-design] warning(wd-input): value can not be undefined.")), d.value = e, t.value = Boolean(n && !o && !a && e);
    }, {
      immediate: !0,
      deep: !0
    });
    var _u$useParent = u.useParent(u.FORM_KEY),
      f = _u$useParent.parent,
      v = u.computed(function () {
        return f && l.prop && f.errorMessages && f.errorMessages[l.prop] ? f.errorMessages[l.prop] : "";
      }),
      m = u.computed(function () {
        var e = !1;
        if (f && f.props.rules) {
          var _o = f.props.rules;
          for (var _a in _o) Object.prototype.hasOwnProperty.call(_o, _a) && _a === l.prop && Array.isArray(_o[_a]) && (e = _o[_a].some(function (e) {
            return e.required;
          }));
        }
        return l.required || l.rules.some(function (e) {
          return e.required;
        }) || e;
      }),
      b = u.computed(function () {
        return "wd-input  ".concat(l.label || l.useLabelSlot ? "is-cell" : "", " ").concat(l.center ? "is-center" : "", " ").concat(p.border.value ? "is-border" : "", " ").concat(l.size ? "is-" + l.size : "", " ").concat(l.error ? "is-error" : "", " ").concat(l.disabled ? "is-disabled" : "", "  ").concat(d.value && String(d.value).length > 0 ? "is-not-empty" : "", "  ").concat(l.noBorder ? "is-no-border" : "", " ").concat(l.customClass);
      }),
      h = u.computed(function () {
        return "wd-input__label ".concat(l.customLabelClass, " ").concat(m.value ? "is-required" : "");
      }),
      w = u.computed(function () {
        return "wd-input__placeholder  ".concat(l.placeholderClass);
      }),
      g = u.computed(function () {
        return l.labelWidth ? u.objToStyle({
          "min-width": l.labelWidth,
          "max-width": l.labelWidth
        }) : "";
      });
    function x() {
      i.value = !i.value;
    }
    function y() {
      d.value = "", u.requestAnimationFrame().then(function () {
        return u.requestAnimationFrame();
      }).then(function () {
        return u.requestAnimationFrame();
      }).then(function () {
        c.value = !0, a("change", {
          value: ""
        }), a("update:modelValue", d.value), a("clear");
      });
    }
    function _() {
      c.value = !1, a("change", {
        value: d.value
      }), a("update:modelValue", d.value), a("blur", {
        value: d.value
      });
    }
    function S(_ref2) {
      var e = _ref2.detail;
      s.value ? s.value = !1 : (c.value = !0, a("focus", e));
    }
    function I() {
      a("update:modelValue", d.value), a("input", d.value);
    }
    function P(e) {
      a("keyboardheightchange", e.detail);
    }
    function O(_ref3) {
      var e = _ref3.detail;
      a("confirm", e);
    }
    function j() {
      a("clicksuffixicon");
    }
    function $() {
      a("clickprefixicon");
    }
    function k(e) {
      a("click", e);
    }
    return u.onBeforeMount(function () {
      !function () {
        var e = l.disabled,
          o = l.readonly,
          n = l.clearable,
          u = l.maxlength,
          i = l.showWordLimit;
        var s = "";
        i && u && d.value.toString().length > u && (s = d.value.toString().substring(0, u)), t.value = Boolean(!e && !o && n && d.value), r.value = Boolean(!e && !o && u && i), d.value = s || d.value, a("update:modelValue", d.value);
      }();
    }), function (e, o) {
      return u.e({
        a: e.label || e.useLabelSlot
      }, e.label || e.useLabelSlot ? u.e({
        b: e.prefixIcon || e.usePrefixSlot
      }, e.prefixIcon || e.usePrefixSlot ? u.e({
        c: e.prefixIcon && !e.usePrefixSlot
      }, e.prefixIcon && !e.usePrefixSlot ? {
        d: u.o($),
        e: u.p({
          "custom-class": "wd-input__icon",
          name: e.prefixIcon
        })
      } : {}) : {}, {
        f: e.label
      }, e.label ? {
        g: u.t(e.label)
      } : {}, {
        h: u.n(h.value),
        i: u.s(g.value)
      }) : {}, {
        j: (e.prefixIcon || e.usePrefixSlot) && !e.label
      }, !e.prefixIcon && !e.usePrefixSlot || e.label ? {} : u.e({
        k: e.prefixIcon
      }, e.prefixIcon ? {
        l: u.o($),
        m: u.p({
          "custom-class": "wd-input__icon",
          name: e.prefixIcon
        })
      } : {}), {
        n: u.n(e.prefixIcon ? "wd-input__inner--prefix" : ""),
        o: u.n(r.value ? "wd-input__inner--count" : ""),
        p: u.n(e.alignRight ? "is-align-right" : ""),
        q: u.n(e.customInputClass),
        r: e.type,
        s: e.showPassword && !i.value,
        t: e.placeholder || u.unref(n)("placeholder"),
        v: e.disabled,
        w: e.maxlength,
        x: c.value,
        y: e.confirmType,
        z: e.confirmHold,
        A: e.cursor,
        B: e.cursorSpacing,
        C: e.placeholderStyle,
        D: e.selectionStart,
        E: e.selectionEnd,
        F: e.adjustPosition,
        G: e.holdKeyboard,
        H: e.alwaysEmbed,
        I: w.value,
        J: u.o([function (e) {
          return d.value = e.detail.value;
        }, I]),
        K: u.o(S),
        L: u.o(_),
        M: u.o(O),
        N: u.o(P),
        O: d.value,
        P: e.readonly
      }, (e.readonly, {}), {
        Q: t.value || e.showPassword || e.suffixIcon || r.value || e.useSuffixSlot
      }, t.value || e.showPassword || e.suffixIcon || r.value || e.useSuffixSlot ? u.e({
        R: t.value
      }, t.value ? {
        S: u.o(y),
        T: u.p({
          "custom-class": "wd-input__clear",
          name: "error-fill"
        })
      } : {}, {
        U: e.showPassword
      }, e.showPassword ? {
        V: u.o(x),
        W: u.p({
          "custom-class": "wd-input__icon",
          name: i.value ? "view" : "eye-close"
        })
      } : {}, {
        X: r.value
      }, r.value ? {
        Y: u.t(String(d.value).length),
        Z: u.n(d.value && String(d.value).length > 0 ? "wd-input__count-current" : ""),
        aa: u.n(String(d.value).length > e.maxlength ? "is-error" : ""),
        ab: u.t(e.maxlength)
      } : {}, {
        ac: e.suffixIcon
      }, e.suffixIcon ? {
        ad: u.o(j),
        ae: u.p({
          "custom-class": "wd-input__icon",
          name: e.suffixIcon
        })
      } : {}) : {}, {
        af: v.value
      }, v.value ? {
        ag: u.t(v.value)
      } : {}, {
        ah: u.n(b.value),
        ai: u.s(e.customStyle),
        aj: u.o(k)
      });
    };
  }
}, o(s, l(c))));var s, c;var d = u._export_sfc(i, [["__scopeId", "data-v-7397cfb5"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/node_modules/wot-design-uni/components/wd-input/wd-input.vue"]]);wx.createComponent(d);