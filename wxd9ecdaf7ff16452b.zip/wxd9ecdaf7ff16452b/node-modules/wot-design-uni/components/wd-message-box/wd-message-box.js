var _createForOfIteratorHelper2 = require("../../../../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  a = Object.defineProperties,
  o = Object.getOwnPropertyDescriptors,
  t = Object.getOwnPropertySymbols,
  l = Object.prototype.hasOwnProperty,
  n = Object.prototype.propertyIsEnumerable,
  u = function u(a, o, t) {
    return o in a ? e(a, o, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: t
    }) : a[o] = t;
  };var r = require("../../../../common/vendor.js");if (!Array) {
  (r.resolveComponent("wd-input") + r.resolveComponent("wd-button") + r.resolveComponent("wd-popup"))();
}Math || (function () {
  return "../wd-input/wd-input.js";
} + function () {
  return "../wd-button/wd-button.js";
} + function () {
  return "../wd-popup/wd-popup.js";
})();var s = r.defineComponent((i = function (e, a) {
  for (var o in a || (a = {})) l.call(a, o) && u(e, o, a[o]);
  if (t) {
    var _iterator = _createForOfIteratorHelper2(t(a)),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var o = _step.value;
        n.call(a, o) && u(e, o, a[o]);
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
  }
  return e;
}({}, {
  name: "wd-message-box",
  options: {
    virtualHost: !0,
    addGlobalClass: !0,
    styleIsolation: "shared"
  }
}), c = {
  props: r.messageBoxProps,
  setup: function setup(e) {
    var a = e,
      _r$useTranslate = r.useTranslate("message-box"),
      o = _r$useTranslate.translate,
      t = r.computed(function () {
        return "wd-message-box__container ".concat(a.customClass);
      }),
      l = r.computed(function () {
        return "wd-message-box__body ".concat(m.value ? "" : "is-no-title", " ").concat("prompt" === g.value ? "is-prompt" : "");
      }),
      n = a.selector ? r.messageDefaultOptionKey + a.selector : r.messageDefaultOptionKey,
      u = r.inject(n, r.ref(r.defaultOptions$1)),
      s = r.ref("");
    var i = null,
      c = null,
      v = null;
    var p = r.ref(!1),
      m = r.ref(""),
      d = r.ref(!1),
      f = r.ref(!0),
      w = r.ref(""),
      b = r.ref(""),
      g = r.ref("alert"),
      x = r.ref("text"),
      y = r.ref(""),
      _ = r.ref(""),
      h = r.ref();
    var C = null;
    var O = r.ref(""),
      j = r.ref(!1),
      k = r.ref(99),
      P = r.ref(!0);
    function z(e) {
      if (("modal" !== e || f.value) && ("prompt" !== g.value || "confirm" !== e || (h.value && !h.value.test(String(y.value)) ? (j.value = !0, 0) : "function" != typeof C || C(y.value) ? (j.value = !1, 1) : (j.value = !0, 0)))) switch (e) {
        case "confirm":
          v ? v({
            resolve: function resolve(a) {
              a && D({
                action: e,
                value: y.value
              });
            }
          }) : D({
            action: e,
            value: y.value
          });
          break;
        case "cancel":
          B({
            action: e
          });
          break;
        default:
          B({
            action: "modal"
          });
      }
    }
    function D(e) {
      p.value = !1, r.isFunction(i) && i(e);
    }
    function B(e) {
      p.value = !1, r.isFunction(c) && c(e);
    }
    function V(e) {
      "" !== e ? y.value = e : j.value = !1;
    }
    return r.watch(function () {
      return u.value;
    }, function (e) {
      var a;
      (a = e) && (m.value = r.isDef(a.title) ? a.title : "", d.value = !!r.isDef(a.showCancelButton) && a.showCancelButton, p.value = a.show, f.value = a.closeOnClickModal, w.value = a.confirmButtonText, b.value = a.cancelButtonText, s.value = a.msg, g.value = a.type, x.value = a.inputType, y.value = a.inputValue, _.value = a.inputPlaceholder, h.value = a.inputPattern, C = a.inputValidate, i = a.onConfirm, c = a.onCancel, v = a.beforeConfirm, O.value = a.inputError, j.value = a.showErr, k.value = a.zIndex, P.value = a.lazyRender);
    }, {
      deep: !0,
      immediate: !0
    }), r.watch(function () {
      return p.value;
    }, function (e) {
      !1 === e && (j.value = !1);
    }, {
      deep: !0,
      immediate: !0
    }), function (e, a) {
      return r.e({
        a: m.value
      }, m.value ? {
        b: r.t(m.value)
      } : {}, {
        c: "prompt" === g.value
      }, "prompt" === g.value ? r.e({
        d: r.o(V),
        e: r.o(function (e) {
          return y.value = e;
        }),
        f: r.p({
          type: x.value,
          size: "large",
          placeholder: _.value || "请输入",
          modelValue: y.value
        }),
        g: j.value
      }, j.value ? {
        h: r.t(O.value || r.unref(o)("inputNoValidate"))
      } : {}) : {}, {
        i: r.t(s.value),
        j: r.n(l.value),
        k: d.value
      }, d.value ? {
        l: r.t(b.value || r.unref(o)("cancel")),
        m: r.o(function (e) {
          return z("cancel");
        }),
        n: r.p({
          type: "info",
          block: !0,
          "custom-style": "margin-right: 16px;"
        })
      } : {}, {
        o: r.t(w.value || r.unref(o)("confirm")),
        p: r.o(function (e) {
          return z("confirm");
        }),
        q: r.p({
          block: !0
        }),
        r: r.n("wd-message-box__actions " + (d.value ? "wd-message-box__flex" : "wd-message-box__block")),
        s: r.n(t.value),
        t: r.o(function (e) {
          return z("modal");
        }),
        v: r.o(function (e) {
          return p.value = e;
        }),
        w: r.p({
          transition: "zoom-in",
          "close-on-click-modal": f.value,
          "lazy-render": P.value,
          "custom-class": "wd-message-box",
          "z-index": k.value,
          duration: 200,
          modelValue: p.value
        })
      });
    };
  }
}, a(i, o(c))));var i, c;var v = r._export_sfc(s, [["__scopeId", "data-v-6a12ec76"], ["__file", "/Users/zpw/Documents/leansocket/flowers-wxmp/node_modules/wot-design-uni/components/wd-message-box/wd-message-box.vue"]]);wx.createComponent(v);