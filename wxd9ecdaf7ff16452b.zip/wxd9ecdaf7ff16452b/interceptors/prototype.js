var t = {
  install: function install() {
    "function" != typeof Array.prototype.at && (Array.prototype.at = function (t) {
      return t < 0 ? this[this.length + t] : t >= this.length ? void 0 : this[t];
    });
  }
};exports.prototypeInterceptor = t;