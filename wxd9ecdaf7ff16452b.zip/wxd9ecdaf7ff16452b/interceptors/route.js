require("../@babel/runtime/helpers/Arrayincludes");var e = require("../common/vendor.js");require("../store/index.js");var o = require("../utils/index.js"),
  n = require("../store/user.js"),
  r = {
    invoke: function invoke(_ref) {
      var r = _ref.url;
      console.log("进入路由拦截器");
      var t = r.split("?")[0];
      var s = [];
      console.log("调用了"), s = o.getNeedLoginPages();
      var i = s.includes(t);
      if (console.log("isNeedLogin", i), !i) return !0;
      var c = n.useUserStore().accessToken;
      if (console.log("hasLogin", c), c) return !0;
      var d = "/pages/login/login?redirect=".concat(encodeURIComponent(r));
      return e.index.navigateTo({
        url: d
      }), !1;
    }
  },
  t = {
    install: function install() {
      e.index.addInterceptor("navigateTo", r), e.index.addInterceptor("reLaunch", r), e.index.addInterceptor("redirectTo", r), e.index.addInterceptor("switchTab", r);
    }
  };exports.routeInterceptor = t;