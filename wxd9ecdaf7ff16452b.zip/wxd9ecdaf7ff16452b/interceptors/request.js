var _createForOfIteratorHelper2 = require("../@babel/runtime/helpers/createForOfIteratorHelper");var e = Object.defineProperty,
  r = Object.defineProperties,
  t = Object.getOwnPropertyDescriptors,
  s = Object.getOwnPropertySymbols,
  o = Object.prototype.hasOwnProperty,
  i = Object.prototype.propertyIsEnumerable,
  n = function n(r, t, s) {
    return t in r ? e(r, t, {
      enumerable: !0,
      configurable: !0,
      writable: !0,
      value: s
    }) : r[t] = s;
  },
  a = function a(e, r) {
    for (var t in r || (r = {})) o.call(r, t) && n(e, t, r[t]);
    if (s) {
      var _iterator = _createForOfIteratorHelper2(s(r)),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var t = _step.value;
          i.call(r, t) && n(e, t, r[t]);
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
    return e;
  },
  u = function u(e, s) {
    return r(e, t(s));
  };var l = require("../common/vendor.js");require("../store/index.js");var c = require("../utils/platform.js"),
  p = require("../utils/secret.js"),
  d = require("../utils/sign.js"),
  f = require("../store/user.js"),
  j = {
    invoke: function invoke(e) {
      if (e.query) {
        var _r = l.qs.stringify(e.query);
        e.url.includes("?") ? e.url += "&".concat(_r) : e.url += "?".concat(_r);
      }
      e.url.startsWith("http") || (e.url = "https://api.easegram.tech" + e.url), e.timeout = 1e4, e.header = a({
        platform: c.platform
      }, e.header);
      var r = f.useUserStore(),
        t = p.APP_ID,
        s = r.accessToken;
      var o;
      s ? (o = d.sign(u(a({}, e.data), {
        $_invoker: t,
        $_token: s
      }), p.APP_SECRET), e.data = a({
        $_sign: o,
        $_invoker: t,
        $_token: s
      }, e.data)) : (o = d.sign(u(a({}, e.data), {
        $_invoker: t
      }), p.APP_SECRET), e.data = a({
        $_sign: o,
        $_invoker: t
      }, e.data));
    }
  },
  b = {
    install: function install() {
      l.index.addInterceptor("request", j), l.index.addInterceptor("uploadFile", j);
    }
  };exports.requestInterceptor = b;